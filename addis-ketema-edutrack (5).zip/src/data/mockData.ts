/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Student, Teacher, SubjectGrade, AppNotification, SystemLog, CourseProgram, SubjectDefinition, Announcement } from '../types';

// Grading helper
export function calculateGradeDetails(assignments: number, quizzes: number, exams: number, creditHours: number): Omit<SubjectGrade, 'subjectCode' | 'subjectName' | 'instructorName' | 'progress'> {
  const totalMark = Math.min(100, Math.max(0, parseFloat((assignments + quizzes + exams).toFixed(1))));
  
  let letterGrade = 'F';
  let gpaPoint = 0.0;
  let status: 'Excellent' | 'Good' | 'Average' | 'At Risk' = 'At Risk';

  if (totalMark >= 90) {
    letterGrade = 'A+';
    gpaPoint = 4.0;
    status = 'Excellent';
  } else if (totalMark >= 80) {
    letterGrade = 'A';
    gpaPoint = 4.0;
    status = 'Excellent';
  } else if (totalMark >= 75) {
    letterGrade = 'B+';
    gpaPoint = 3.5;
    status = 'Good';
  } else if (totalMark >= 65) {
    letterGrade = 'B';
    gpaPoint = 3.0;
    status = 'Good';
  } else if (totalMark >= 55) {
    letterGrade = 'C+';
    gpaPoint = 2.5;
    status = 'Average';
  } else if (totalMark >= 50) {
    letterGrade = 'C';
    gpaPoint = 2.0;
    status = 'Average';
  } else if (totalMark >= 40) {
    letterGrade = 'D';
    gpaPoint = 1.0;
    status = 'At Risk';
  } else {
    letterGrade = 'F';
    gpaPoint = 0.0;
    status = 'At Risk';
  }

  return {
    assignments,
    quizzes,
    exams,
    totalMark,
    creditHours,
    gpaPoint,
    letterGrade,
    status
  };
}

export function calculateGPA(grades: Record<string, SubjectGrade>): { gpa: number; rating: string; totalCredits: number; passedCredits: number; atRiskCount: number } {
  let weightedPointsSum = 0;
  let totalCredits = 0;
  let passedCredits = 0;
  let atRiskCount = 0;

  Object.values(grades).forEach((g) => {
    totalCredits += g.creditHours;
    weightedPointsSum += g.gpaPoint * g.creditHours;
    
    if (g.totalMark >= 50) {
      passedCredits += g.creditHours;
    }
    if (g.status === 'At Risk') {
      atRiskCount++;
    }
  });

  const gpa = totalCredits > 0 ? parseFloat((weightedPointsSum / totalCredits).toFixed(2)) : 0.0;
  
  let rating = 'Excellent';
  if (gpa >= 3.6) rating = 'Excellent Academic Standing';
  else if (gpa >= 3.0) rating = 'Very Good Standing';
  else if (gpa >= 2.0) rating = 'Satisfactory Progress';
  else rating = 'Academic Probation (At Risk)';

  return { gpa, rating, totalCredits, passedCredits, atRiskCount };
}

// Initial Subjects templates
const INSTRUCTORS: Record<string, { name: string; course: string; credit: number; progress: number }> = {
  'ENG-101': { name: 'Dr. Elizabeth Ward', course: 'English Literature & Composition', credit: 3, progress: 95 },
  'MAT-102': { name: 'Prof. Martha Alazar', course: 'Advanced Mathematics & Calculus', credit: 4, progress: 92 },
  'CHE-103': { name: 'Dr. Teklehaimanot G.', course: 'General Chemistry', credit: 3, progress: 88 },
  'BIO-104': { name: 'Sister Helen Desta', course: 'Biology & Environmental Systems', credit: 3, progress: 90 },
  'PHY-105': { name: 'Dr. Yonas Kassahun', course: 'Fundamentals of Physics', credit: 4, progress: 85 },
  'AGR-106': { name: 'Mekonnen Wolde', course: 'Modern Agricultural Science', credit: 2, progress: 96 },
  'IT-107': { name: 'Ato Solomon Kebede', course: 'Information Technology & Databases', credit: 3, progress: 98 },
  'WEB-108': { name: 'W/ro Kidist Abebe', course: 'Full-Stack Web Development', credit: 4, progress: 94 },
};

// Seed student Abebe Kebede
function createInitialGradesForAbebe(): Record<string, SubjectGrade> {
  const grades: Record<string, SubjectGrade> = {};
  
  // High performing overall, but physics is "at risk" to demonstrate orange/red alerts
  const sampleMarks: Record<string, { ass: number; qz: number; ex: number }> = {
    'ENG-101': { ass: 26, qz: 18, ex: 44 }, // 88 - A (4.0)
    'MAT-102': { ass: 28, qz: 19, ex: 46 }, // 93 - A+ (4.0)
    'CHE-103': { ass: 23, qz: 15, ex: 38 }, // 76 - B+ (3.5)
    'BIO-104': { ass: 24, qz: 16, ex: 37 }, // 77 - B+ (3.5)
    'PHY-105': { ass: 12, qz: 8, ex: 22 },  // 42 - D (1.0) - At Risk!
    'AGR-106': { ass: 22, qz: 14, ex: 33 }, // 69 - B (3.0)
    'IT-107': { ass: 27, qz: 18, ex: 45 }, // 90 - A+ (4.0)
    'WEB-108': { ass: 29, qz: 20, ex: 48 }, // 97 - A+ (4.0)
  };

  Object.entries(INSTRUCTORS).forEach(([code, data]) => {
    const marks = sampleMarks[code];
    const details = calculateGradeDetails(marks.ass, marks.qz, marks.ex, data.credit);
    grades[code] = {
      subjectCode: code,
      subjectName: data.course,
      instructorName: data.name,
      progress: data.progress,
      ...details
    };
  });

  return grades;
}

export function createDefaultGradesForAllSubjects(): Record<string, SubjectGrade> {
  const grades: Record<string, SubjectGrade> = {};
  Object.entries(INSTRUCTORS).forEach(([code, data]) => {
    // Generate varied demo marks for different subjects based on code
    const subjectSalt = code.split('-')[1] ? parseInt(code.split('-')[1]) : 0;
    const assignments = 15 + (subjectSalt % 10); // 15-24
    const quizzes = 8 + (subjectSalt % 8);      // 8-15
    const exams = 25 + (subjectSalt % 20);      // 25-44
    
    const details = calculateGradeDetails(assignments, quizzes, exams, data.credit);
    grades[code] = {
      subjectCode: code,
      subjectName: data.course,
      instructorName: data.name,
      progress: data.progress,
      ...details
    };
  });
  return grades;
}

// Seed second student for multiple record simulation
function createInitialGradesForSelam(): Record<string, SubjectGrade> {
  const grades: Record<string, SubjectGrade> = {};
  
  const sampleMarks: Record<string, { ass: number; qz: number; ex: number }> = {
    'ENG-101': { ass: 24, qz: 15, ex: 38 }, // 77 - B+ (3.5)
    'MAT-102': { ass: 22, qz: 14, ex: 34 }, // 70 - B (3.0)
    'CHE-103': { ass: 25, qz: 17, ex: 40 }, // 82 - A (4.0)
    'BIO-104': { ass: 28, qz: 18, ex: 45 }, // 91 - A+ (4.0)
    'PHY-105': { ass: 20, qz: 13, ex: 32 }, // 65 - B (3.0)
    'AGR-106': { ass: 25, qz: 16, ex: 38 }, // 79 - B+ (3.5)
    'IT-107': { ass: 26, qz: 17, ex: 42 }, // 85 - A (4.0)
    'WEB-108': { ass: 24, qz: 14, ex: 35 }, // 73 - B (3.0)
  };

  Object.entries(INSTRUCTORS).forEach(([code, data]) => {
    const marks = sampleMarks[code];
    const details = calculateGradeDetails(marks.ass, marks.qz, marks.ex, data.credit);
    grades[code] = {
      subjectCode: code,
      subjectName: data.course,
      instructorName: data.name,
      progress: data.progress,
      ...details
    };
  });

  return grades;
}

const DEFAULT_STUDENTS: Student[] = [
  {
    id: 'student-1',
    name: 'Abebe Kebede',
    email: 'student@edutrack.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200&h=200',
    studentId: 'AK/2026/0842',
    academicLevel: 'Grade 12 - Senior Academy',
    semester: 'Grade 12, Semester 2',
    parentName: 'Kebede Alazar',
    parentContact: '+251-911-23-45-67',
    joinedDate: 'Oct 2024',
    grades: createInitialGradesForAbebe(),
    attendance: 94.5
  },
  {
    id: 'student-2',
    name: 'Selam Tesfaye',
    email: 'selam@edutrack.com',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200&h=200',
    studentId: 'AK/2026/0115',
    academicLevel: 'Grade 11 - Pre-University',
    semester: 'Grade 11, Semester 2',
    parentName: 'Tesfaye Wolde',
    parentContact: '+251-912-44-55-66',
    joinedDate: 'Sep 2025',
    grades: createInitialGradesForSelam(),
    attendance: 88.2
  }
];

const DEFAULT_TEACHERS: Teacher[] = [
  {
    id: 'teacher-1',
    name: 'Prof. Martha Alazar',
    email: 'teacher@edutrack.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200',
    teacherId: 'AK/STAFF/M102',
    subjectCode: 'MAT-102',
    subjectName: 'Advanced Mathematics & Calculus',
    classes: ['Grade 12 - Senior Academy', 'Grade 11 - Pre-University']
  },
  {
    id: 'teacher-2',
    name: 'W/ro Kidist Abebe',
    email: 'kidist@edutrack.com',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200&h=200',
    teacherId: 'AK/STAFF/W108',
    subjectCode: 'WEB-108',
    subjectName: 'Full-Stack Web Development',
    classes: ['Grade 12 - Senior Academy']
  }
];

const DEFAULT_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'n-1',
    title: 'Grade Release: Web Development',
    message: 'W/ro Kidist Abebe published final exam grades for WEB-108. Total Mark: 97 (A+).',
    type: 'grade',
    date: '2 hours ago',
    unread: true
  },
  {
    id: 'n-2',
    title: 'Flag Alert: Physics Performance',
    message: 'Your Physics (PHY-105) score is 42% (D), placing you at Academic Risk. Contact Dr. Yonas.',
    type: 'alert',
    date: '1 day ago',
    unread: true
  },
  {
    id: 'n-3',
    title: 'Official Announcement: Exam Schedule',
    message: 'Second Semester Final Transcript verification runs from June 5 to June 10, 2026.',
    type: 'announce',
    date: '3 days ago',
    unread: false
  }
];

const DEFAULT_LOGS: SystemLog[] = [
  {
    id: 'log-1',
    actor: 'Prof. Martha Alazar',
    action: 'Verified Grades',
    subject: 'MAT-102',
    timestamp: 'May 30, 2026, 02:24 PM'
  },
  {
    id: 'log-2',
    actor: 'W/ro Kidist Abebe',
    action: 'Updated Exam Mark',
    subject: 'WEB-108',
    timestamp: 'May 30, 2026, 01:10 PM'
  },
  {
    id: 'log-3',
    actor: 'Administrator (System)',
    action: 'Initialized Term Backends',
    subject: 'Term 2',
    timestamp: 'May 28, 2026, 09:00 AM'
  }
];

// LocalStorage helpers with automatic seeding
export function getStoredStudents(): Student[] {
  const data = localStorage.getItem('ak_edutrack_students');
  if (!data) {
    localStorage.setItem('ak_edutrack_students', JSON.stringify(DEFAULT_STUDENTS));
    return DEFAULT_STUDENTS;
  }
  return JSON.parse(data);
}

export function saveStoredStudents(students: Student[]) {
  localStorage.setItem('ak_edutrack_students', JSON.stringify(students));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('localDataUpdated'));
    window.dispatchEvent(new Event('ak_db_updated'));
  }
}

export function getStoredTeachers(): Teacher[] {
  const data = localStorage.getItem('ak_edutrack_teachers');
  if (!data) {
    localStorage.setItem('ak_edutrack_teachers', JSON.stringify(DEFAULT_TEACHERS));
    return DEFAULT_TEACHERS;
  }
  return JSON.parse(data);
}

export function saveStoredTeachers(teachers: Teacher[]) {
  localStorage.setItem('ak_edutrack_teachers', JSON.stringify(teachers));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('localDataUpdated'));
    window.dispatchEvent(new Event('ak_db_updated'));
  }
}

export function updateTeacherAndSync(updatedTeacher: Teacher) {
  const teachers = getStoredTeachers();
  const index = teachers.findIndex(t => t.id === updatedTeacher.id);
  if (index !== -1) {
    teachers[index] = updatedTeacher;
    saveStoredTeachers(teachers);

    // Sync in student records if the instructor name changed for their subject
    const students = getStoredStudents();
    const updatedStudents = students.map(s => {
      const updatedGrades = { ...s.grades };
      let changed = false;
      if (updatedGrades[updatedTeacher.subjectCode]) {
         if (updatedGrades[updatedTeacher.subjectCode].instructorName !== updatedTeacher.name) {
             updatedGrades[updatedTeacher.subjectCode] = {
               ...updatedGrades[updatedTeacher.subjectCode],
               instructorName: updatedTeacher.name
             };
             changed = true;
         }
      }
      return changed ? { ...s, grades: updatedGrades } : s;
    });
    saveStoredStudents(updatedStudents);
  }
}

export function getStoredNotifications(): AppNotification[] {
  const data = localStorage.getItem('ak_edutrack_notifications');
  if (!data) {
    localStorage.setItem('ak_edutrack_notifications', JSON.stringify(DEFAULT_NOTIFICATIONS));
    return DEFAULT_NOTIFICATIONS;
  }
  return JSON.parse(data);
}

export function saveStoredNotifications(notifs: AppNotification[]) {
  localStorage.setItem('ak_edutrack_notifications', JSON.stringify(notifs));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('localDataUpdated'));
  }
}

export function getStoredLogs(): SystemLog[] {
  const data = localStorage.getItem('ak_edutrack_logs');
  if (!data) {
    localStorage.setItem('ak_edutrack_logs', JSON.stringify(DEFAULT_LOGS));
    return DEFAULT_LOGS;
  }
  return JSON.parse(data);
}

export function addStoredLog(actor: string, action: string, subject: string) {
  const logs = getStoredLogs();
  const formatTime = () => {
    const d = new Date();
    return d.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };
  const newLog: SystemLog = {
    id: `log-${Date.now()}`,
    actor,
    action,
    subject,
    timestamp: formatTime()
  };
  localStorage.setItem('ak_edutrack_logs', JSON.stringify([newLog, ...logs].slice(0, 50)));
}

// Global active user credentials checker for Demo
export function loginDemo(email: string, roleSelected: 'Admin' | 'Teacher' | 'Student'): { success: boolean; user?: any; error?: string } {
  const students = getStoredStudents();
  const teachers = getStoredTeachers();

  if (roleSelected === 'Admin') {
    // Check if there is a custom admin registered matching this email
    const customAdminsStr = localStorage.getItem('ak_edutrack_custom_admins');
    if (customAdminsStr) {
      try {
        const customAdmins = JSON.parse(customAdminsStr);
        const matched = customAdmins.find((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (matched) {
          return { success: true, user: { ...matched, role: 'Admin' } };
        }
      } catch (e) {
        console.error("Custom admins parse error:", e);
      }
    }

    // Fallback default admin detail
    return {
      success: true,
      user: {
        id: 'admin-1',
        name: 'Dean Abraham Hailu',
        email: email || 'admin@edutrack.com',
        avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200&h=200',
        role: 'Admin',
        title: 'Academic Director'
      }
    };
  } else if (roleSelected === 'Teacher') {
    // Look if teacher email matches
    const matched = teachers.find(t => t.email.toLowerCase() === email.toLowerCase());
    if (matched) {
      return { success: true, user: { ...matched, role: 'Teacher' } };
    }
    // Fallback default teacher for user ease
    return {
      success: true,
      user: {
        ...teachers[0],
        email: email,
        role: 'Teacher'
      }
    };
  } else {
    // Student
    const matched = students.find(s => s.email.toLowerCase() === email.toLowerCase());
    if (matched) {
      return { success: true, user: { ...matched, role: 'Student' } };
    }
    // Fallback default student Abebe
    return {
      success: true,
      user: {
        ...students[0],
        email: email,
        role: 'Student'
      }
    };
  }
}

// Academic Program Seeding and Management
const DEFAULT_PROGRAMS: CourseProgram[] = [
  { id: 'prog-1', name: 'Associate of Science in Biology', department: 'Biology', subjectsCount: 3, totalCredits: 12, description: 'Core study of botanical, zoological, and genetic cellular principles.', studentsCount: 22, status: 'Active' },
  { id: 'prog-2', name: 'Bachelor of Science in Chemistry', department: 'Chemistry', subjectsCount: 2, totalCredits: 8, description: 'In-depth chemical structure analysis, stoichiometry, and kinetics.', studentsCount: 15, status: 'Active' },
  { id: 'prog-3', name: 'Bachelor of Science in Physics', department: 'Physics', subjectsCount: 2, totalCredits: 8, description: 'Electromagnetic mechanics, kinematics, and quantum observations.', studentsCount: 18, status: 'Active' },
  { id: 'prog-4', name: 'Diploma in Modern Agriculture', department: 'Agriculture', subjectsCount: 1, totalCredits: 4, description: 'Agricultural crop yields, soil biology, and modern farming tech.', studentsCount: 10, status: 'Active' },
  { id: 'prog-5', name: 'Certification in Web Development', department: 'Web Development', subjectsCount: 1, totalCredits: 4, description: 'Web architectures, ECMAScript, responsive CSS, design frameworks.', studentsCount: 35, status: 'Active' },
  { id: 'prog-6', name: 'Bachelor of Science in Information Technology', department: 'Information Technology', subjectsCount: 1, totalCredits: 3, description: 'Database query design, network topologies, and data storage security.', studentsCount: 29, status: 'Active' },
  { id: 'prog-7', name: 'Associate of Arts in English Literature', department: 'English', subjectsCount: 1, totalCredits: 3, description: 'Classical and modern critical review of global literary collections.', studentsCount: 12, status: 'Active' },
  { id: 'prog-8', name: 'Advanced Certification in Mathematics', department: 'Mathematics', subjectsCount: 1, totalCredits: 4, description: 'Higher level mathematical formulas, calculus integrations, and theorems.', studentsCount: 31, status: 'Active' }
];

const DEFAULT_SUBJECT_DEFINITIONS: SubjectDefinition[] = [
  { id: 'sub-1', name: 'English Literature & Composition', code: 'ENG-101', credits: 3, department: 'English', semester: 'Semester 1', instructorName: 'Dr. Elizabeth Ward', status: 'Active' },
  { id: 'sub-2', name: 'Advanced Mathematics & Calculus', code: 'MAT-102', credits: 4, department: 'Mathematics', semester: 'Semester 2', instructorName: 'Prof. Martha Alazar', status: 'Active' },
  { id: 'sub-3', name: 'General Chemistry', code: 'CHE-103', credits: 3, department: 'Chemistry', semester: 'Semester 1', instructorName: 'Dr. Teklehaimanot G.', status: 'Active' },
  { id: 'sub-4', name: 'Biology & Environmental Systems', code: 'BIO-104', credits: 3, department: 'Biology', semester: 'Semester 2', instructorName: 'Sister Helen Desta', status: 'Active' },
  { id: 'sub-5', name: 'Fundamentals of Physics', code: 'PHY-105', credits: 4, department: 'Physics', semester: 'Semester 1', instructorName: 'Dr. Yonas Kassahun', status: 'Active' },
  { id: 'sub-6', name: 'Modern Agricultural Science', code: 'AGR-106', credits: 2, department: 'Agriculture', semester: 'Semester 2', instructorName: 'Mekonnen Wolde', status: 'Active' },
  { id: 'sub-7', name: 'Information Technology & Databases', code: 'IT-107', credits: 3, department: 'Information Technology', semester: 'Semester 1', instructorName: 'Ato Solomon Kebede', status: 'Active' },
  { id: 'sub-8', name: 'Full-Stack Web Development', code: 'WEB-108', credits: 4, department: 'Web Development', semester: 'Semester 2', instructorName: 'W/ro Kidist Abebe', status: 'Active' }
];

const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  { id: 'ann-1', title: 'Second Semester Final Exams Schedule', description: 'The second semester academic transcript verification and final audits are scheduled to run from June 5 to June 10, 2026.', publishDate: 'May 30, 2026', priority: 'Academic' },
  { id: 'ann-2', title: 'System Grade Verification Required', description: 'All instructors must review and finalize their classroom grade databases before June 4 for automatic parent alerts.', publishDate: 'May 28, 2026', priority: 'Emergency' },
  { id: 'ann-3', title: 'New Computer Lab Equipment Installed', description: 'The Addis Ketema engineering department is excited to announce the installation of 50 new high-performance systems in Lab B.', publishDate: 'May 25, 2026', priority: 'General' }
];

export function getStoredPrograms(): CourseProgram[] {
  const data = localStorage.getItem('ak_edutrack_programs');
  if (!data) {
    localStorage.setItem('ak_edutrack_programs', JSON.stringify(DEFAULT_PROGRAMS));
    return DEFAULT_PROGRAMS;
  }
  return JSON.parse(data);
}

export function saveStoredPrograms(progs: CourseProgram[]) {
  localStorage.setItem('ak_edutrack_programs', JSON.stringify(progs));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('localDataUpdated'));
  }
}

export function getStoredSubjects(): SubjectDefinition[] {
  const data = localStorage.getItem('ak_edutrack_subjects');
  if (!data) {
    localStorage.setItem('ak_edutrack_subjects', JSON.stringify(DEFAULT_SUBJECT_DEFINITIONS));
    return DEFAULT_SUBJECT_DEFINITIONS;
  }
  return JSON.parse(data);
}

export function saveStoredSubjects(subs: SubjectDefinition[]) {
  localStorage.setItem('ak_edutrack_subjects', JSON.stringify(subs));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('localDataUpdated'));
  }
}

export function getStoredAnnouncements(): Announcement[] {
  const data = localStorage.getItem('ak_edutrack_announcements');
  if (!data) {
    localStorage.setItem('ak_edutrack_announcements', JSON.stringify(DEFAULT_ANNOUNCEMENTS));
    return DEFAULT_ANNOUNCEMENTS;
  }
  return JSON.parse(data);
}

export function saveStoredAnnouncements(ann: Announcement[]) {
  localStorage.setItem('ak_edutrack_announcements', JSON.stringify(ann));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('localDataUpdated'));
  }
}

