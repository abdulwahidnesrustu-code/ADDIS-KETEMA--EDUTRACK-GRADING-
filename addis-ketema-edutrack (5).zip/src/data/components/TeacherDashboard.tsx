/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useTransition } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  FileSpreadsheet, 
  UserCog, 
  BookOpen, 
  Search, 
  CheckCircle, 
  PlusCircle, 
  Layers, 
  ChevronRight, 
  Calendar,
  LogOut,
  Sliders,
  ChevronDown,
  Percent,
  Check,
  Award,
  AlertCircle,
  TrendingUp,
  Printer,
  Send,
  Bell,
  Sparkles,
  FileText,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  ChevronUp,
  RefreshCw,
  Mail,
  User,
  Trash2,
  Lock,
  Download,
  Terminal,
  Activity,
  Sun,
  Moon,
  Camera
} from 'lucide-react';
import { Teacher, Student, SubjectGrade, AppNotification } from '../types';
import AvatarCameraModal from './AvatarCameraModal';
import AttendanceTracking from './AttendanceTracking';
import { 
  getStoredStudents, 
  saveStoredStudents, 
  addStoredLog,
  getStoredNotifications,
  saveStoredNotifications,
  getStoredTeachers,
  saveStoredTeachers,
  calculateGradeDetails
} from '../data/mockData';
import crestLogo from '../assets/images/addis_ketema_logo_1780404658947.png';

interface TeacherDashboardProps {
  teacher: Teacher;
  onLogout: () => void;
  onProfileUpdate: (updatedTeacher: Teacher) => void;
  onUpdateStudent: (student: Student) => void;
}

interface CalculatedGrade {
  totalMark: number;
  gpaPoint: number;
  letterGrade: string;
  status: 'Excellent' | 'Good' | 'Average' | 'Needs Support';
}

// Inline score calculator according to specifications:
// Total = assignment (max 40) + quiz (max 20) + exam (max 40)
function calculateLocalGrade(assignment: number, quiz: number, exam: number): CalculatedGrade {
  const totalMark = Math.min(100, Math.max(0, parseFloat((assignment + quiz + exam).toFixed(1))));
  
  let gpaPoint = 0.0;
  let letterGrade = 'F';
  let status: 'Excellent' | 'Good' | 'Average' | 'Needs Support' = 'Needs Support';

  // GPA mapping
  if (totalMark >= 90) {
    gpaPoint = 4.0;
  } else if (totalMark >= 85) {
    gpaPoint = 3.7;
  } else if (totalMark >= 80) {
    gpaPoint = 3.3;
  } else if (totalMark >= 75) {
    gpaPoint = 3.0;
  } else if (totalMark >= 70) {
    gpaPoint = 2.7;
  } else if (totalMark >= 65) {
    gpaPoint = 2.3;
  } else if (totalMark >= 60) {
    gpaPoint = 2.0;
  } else if (totalMark >= 50) {
    gpaPoint = 1.0;
  } else {
    gpaPoint = 0.0;
  }

  // Letter Grade mapping
  if (totalMark >= 90) {
    letterGrade = 'A';
    status = 'Excellent';
  } else if (totalMark >= 80) {
    letterGrade = 'B';
    status = 'Good';
  } else if (totalMark >= 70) {
    letterGrade = 'C';
    status = 'Average';
  } else if (totalMark >= 60) {
    letterGrade = 'D';
    status = 'Needs Support';
  } else {
    letterGrade = 'F';
    status = 'Needs Support';
  }

  return { totalMark, gpaPoint, letterGrade, status };
}

export default function TeacherDashboard({ teacher, onLogout, onProfileUpdate, onUpdateStudent }: TeacherDashboardProps) {
  const [isDarkTheme, setIsDarkTheme] = useState(() => localStorage.getItem('ak_theme_dark') === 'true');

  useEffect(() => {
    localStorage.setItem('ak_theme_dark', isDarkTheme ? 'true' : 'false');
  }, [isDarkTheme]);

  // Navigation: Primary workspace selector
  const [activeWorkspace, setActiveWorkspace] = useState<'Dashboard' | 'Grades'>('Dashboard');
  
  // Grade Entry spreadsheet subset navigation
  const [activeGradeTab, setActiveGradeTab] = useState<'Entry' | 'Analysis' | 'Failed' | 'Attendance'>('Entry');
  
  // Storage source reactive states
  const [students, setStudents] = useState<Student[]>([]);
  const [activeClass, setActiveClass] = useState<string>(teacher.classes[0]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Profile settings state (Teacher info)
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [profName, setProfName] = useState(teacher.name);
  const [profEmail, setProfEmail] = useState(teacher.email);
  const [profId, setProfId] = useState(teacher.teacherId);
  const [profAvatar, setProfAvatar] = useState(teacher.avatar);
  const [profDept, setProfDept] = useState(teacher.subjectName);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  // Auto-Save notification states
  const [autoSaveState, setAutoSaveState] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [lastSavedTime, setLastSavedTime] = useState<string>('Just now');
  
  // Publications trigger state
  const [publishStatus, setPublishStatus] = useState<'Unpublished' | 'Publishing' | 'Published'>('Published');
  const [publishProgress, setPublishProgress] = useState(0);
  const [publicationLogs, setPublicationLogs] = useState<Array<{ id: string; subject: string; date: string; time: string; teacherName: string; status: string }>>([
    { id: 'PUB-4091', subject: teacher.subjectCode, date: 'May 30, 2026', time: '12:30 PM', teacherName: teacher.name, status: 'Released' },
    { id: 'PUB-3920', subject: teacher.subjectCode, date: 'May 15, 2026', time: '09:15 AM', teacherName: teacher.name, status: 'Overwritten' }
  ]);

  // Comment & Warning note modal details
  const [selectedStudentForNote, setSelectedStudentForNote] = useState<Student | null>(null);
  const [studentComments, setStudentComments] = useState<Record<string, string[]>>({
    'student-1': ['Requires focus on core mathematics derivatives.', 'Showing steady exam progress (+2%).'],
    'student-2': ['Outstanding class participation and teamwork.']
  });
  const [newCommentText, setNewCommentText] = useState('');
  const [noteSuccess, setNoteSuccess] = useState<string | null>(null);

  // Intervention program list for Failed students
  const [interventions, setInterventions] = useState<Array<{ id: string; studentName: string; action: string; date: string; risk: string }>>([
    { id: 'INT-901', studentName: 'Abebe Kebede', action: 'Assigned Senior Tutoring Group', date: 'May 30, 2026', risk: 'High' }
  ]);

  // Filter criteria for Advanced search options
  const [gpaRangeFilter, setGpaRangeFilter] = useState<'All' | 'High' | 'Mid' | 'Low'>('All');
  const [sortField, setSortField] = useState<'name' | 'gpa' | 'total'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Sparkline generator helper
  const generateSparkline = (values: number[], width = 100, height = 30) => {
    if (values.length <= 1) return '';
    const maxVal = Math.max(...values, 4);
    const minVal = Math.min(...values, 0);
    const range = maxVal - minVal || 1;
    return values.map((val, idx) => {
      const x = (idx / (values.length - 1)) * width;
      const y = height - ((val - minVal) / range) * (height - 4) - 2;
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  };

  // Student Profile state (view details + edit all grades across subjects)
  const [selectedStudentProfile, setSelectedStudentProfile] = useState<Student | null>(null);
  const [localTeacher, setLocalTeacher] = useState<Teacher>(teacher);

  // Score modification handler specifically for student profile card view
  const handleProfileScoreEdit = (subjectCode: string, field: 'assignments' | 'quizzes' | 'exams', value: number) => {
    if (!selectedStudentProfile) return;
    const studentId = selectedStudentProfile.id;
    setAutoSaveState('saving');

    const updatedStudents = students.map(st => {
      if (st.id === studentId) {
        const rawGrade = st.grades[subjectCode];
        if (!rawGrade) return st;

        let assignments = rawGrade.assignments;
        let quizzes = rawGrade.quizzes;
        let exams = rawGrade.exams;

        if (subjectCode === teacher.subjectCode) {
          // Local teacher scaling standard (Max: Assignment 40, Quiz 20, Exam 40 scaled to Exam 50 in db)
          let localAssignment = rawGrade.assignments; 
          let localQuiz = rawGrade.quizzes; 
          let localExam = Math.round((rawGrade.exams / 50) * 40); 

          if (field === 'assignments') localAssignment = Math.min(45, Math.max(0, value)); // buffer limit
          if (field === 'quizzes') localQuiz = Math.min(25, Math.max(0, value));
          if (field === 'exams') localExam = Math.min(45, Math.max(0, value));

          const computed = calculateLocalGrade(localAssignment, localQuiz, localExam);
          return {
            ...st,
            grades: {
              ...st.grades,
              [subjectCode]: {
                ...rawGrade,
                assignments: localAssignment,
                quizzes: localQuiz,
                exams: Math.round((localExam / 40) * 50),
                totalMark: computed.totalMark,
                gpaPoint: computed.gpaPoint,
                letterGrade: computed.letterGrade,
                status: computed.status === 'Needs Support' ? 'At Risk' : computed.status,
              }
            }
          };
        } else {
          // General subjects: Assignments (out of 30), Quizzes (out of 20), Exams (out of 50)
          if (field === 'assignments') assignments = Math.min(30, Math.max(0, value));
          if (field === 'quizzes') quizzes = Math.min(20, Math.max(0, value));
          if (field === 'exams') exams = Math.min(50, Math.max(0, value));

          const computed = calculateGradeDetails(assignments, quizzes, exams, rawGrade.creditHours);
          const rawDetails = {
            ...rawGrade,
            assignments,
            quizzes,
            exams,
            totalMark: computed.totalMark,
            gpaPoint: computed.gpaPoint,
            letterGrade: computed.letterGrade,
            status: computed.status === 'At Risk' ? 'At Risk' : computed.status as any
          };

          return {
            ...st,
            grades: {
              ...st.grades,
              [subjectCode]: rawDetails
            }
          };
        }
      }
      return st;
    });

    setStudents(updatedStudents);
    saveStoredStudents(updatedStudents);

    // Dispatch sync events across any other workspace dashboards
    window.dispatchEvent(new Event('localDataUpdated'));
    window.dispatchEvent(new Event('ak_db_updated'));

    setTimeout(() => {
      setAutoSaveState('saved');
      const now = new Date();
      setLastSavedTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 550);
  };

  const handleProfileAttendanceEdit = (value: number) => {
    if (!selectedStudentProfile) return;
    const studentId = selectedStudentProfile.id;
    setAutoSaveState('saving');

    const cleanValue = Math.min(100, Math.max(0, value));

    const updatedStudents = students.map(st => {
      if (st.id === studentId) {
        return {
          ...st,
          attendance: cleanValue
        };
      }
      return st;
    });

    setStudents(updatedStudents);
    saveStoredStudents(updatedStudents);

    // Dispatch sync events across any other workspace dashboards
    window.dispatchEvent(new Event('localDataUpdated'));
    window.dispatchEvent(new Event('ak_db_updated'));

    setTimeout(() => {
      setAutoSaveState('saved');
      const now = new Date();
      setLastSavedTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 550);
  };

  // Load state
  useEffect(() => {
    const handleSync = () => {
      setStudents(getStoredStudents());
      // Refresh teacher data
      const teachers = getStoredTeachers();
      const updatedTeacher = teachers.find(t => t.id === teacher.id);
      if (updatedTeacher) {
        // We need to trigger an update on the parent or handle it internally if possible.
        // Since it's passed as prop, we might need a local state for teacher here.
        setLocalTeacher(updatedTeacher);
      }
    };
    setStudents(getStoredStudents());
    const initPublish = localStorage.getItem(`ak_pubStatus_${teacher.subjectCode}`);
    if (initPublish) {
      setPublishStatus(initPublish as any);
    }
    window.addEventListener('storage', handleSync);
    window.addEventListener('localDataUpdated', handleSync);
    window.addEventListener('ak_db_updated', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('localDataUpdated', handleSync);
      window.removeEventListener('ak_db_updated', handleSync);
    };
  }, [teacher.id, teacher.subjectCode]);

  // Compute calculated values automatically from activeClass students
  const classStudents = students.filter(s => s.academicLevel === activeClass);

  // Extract individual grade parameters for the current subject
  const mappedGrades = classStudents.map(st => {
    const rawGrade = st.grades[teacher.subjectCode];
    
    // Scale or adjust existing rawGrade marks into inline 40/20/40 configuration
    // Fallback defaults: assignment out of 40, quiz out of 20, exam out of 40
    const assignment = rawGrade ? rawGrade.assignments : 20;
    const quiz = rawGrade ? rawGrade.quizzes : 12;
    // Scale exam out of 50 to fit 40 scale cleanly
    const exam = rawGrade ? Math.round((rawGrade.exams / 50) * 40) : 25;
    
    const computed = calculateLocalGrade(assignment, quiz, exam);
    return {
      student: st,
      assignment,
      quiz,
      exam,
      total: computed.totalMark,
      gpa: computed.gpaPoint,
      gradeLetter: computed.letterGrade,
      status: computed.status,
      credit: rawGrade ? rawGrade.creditHours : 3,
      progress: rawGrade ? rawGrade.progress : 90
    };
  });

  // Calculate dynamic average GPA
  const averageGPA = mappedGrades.length > 0 
    ? parseFloat((mappedGrades.reduce((sum, item) => sum + item.gpa, 0) / mappedGrades.length).toFixed(2))
    : 0.00;

  // Calculate pass percentage dynamically (Total mark >= 50%)
  const passedStudentsCount = mappedGrades.filter(item => item.total >= 50).length;
  const passRate = mappedGrades.length > 0 
    ? parseFloat(((passedStudentsCount / mappedGrades.length) * 100).toFixed(1))
    : 0.0;

  // Track failed Count (Total < 50% / 'F' grade)
  const failedCount = mappedGrades.filter(item => item.total < 50).length;

  // Dynamic Leaderboard list - Ranks top students in real-time
  const sortedPerformerList = [...mappedGrades]
    .sort((a, b) => b.gpa - a.gpa || b.total - a.total);

  const highestGPAStudent = sortedPerformerList[0] || null;

  // Sort and filter the candidate list within Grade table
  const filteredAndSortedGrades = mappedGrades.filter(item => {
    const matchesSearch = item.student.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.student.studentId.toLowerCase().includes(searchQuery.toLowerCase());
    
    // GPA range filter matches
    let matchesGPA = true;
    if (gpaRangeFilter === 'High') matchesGPA = item.gpa >= 3.3;
    else if (gpaRangeFilter === 'Mid') matchesGPA = item.gpa >= 2.0 && item.gpa < 3.3;
    else if (gpaRangeFilter === 'Low') matchesGPA = item.gpa < 2.0;

    // Roster specific tab restriction
    let matchesTab = true;
    if (activeGradeTab === 'Failed') matchesTab = item.total < 50;

    return matchesSearch && matchesGPA && matchesTab;
  }).sort((a, b) => {
    let scalarA: any = a.student.name;
    let scalarB: any = b.student.name;

    if (sortField === 'gpa') {
      scalarA = a.gpa;
      scalarB = b.gpa;
    } else if (sortField === 'total') {
      scalarA = a.total;
      scalarB = b.total;
    }

    if (scalarA < scalarB) return sortOrder === 'asc' ? -1 : 1;
    if (scalarA > scalarB) return sortOrder === 'asc' ? 1 : -1;
    return 0;
  });

  // Action: update individual cell score
  const handleScoreEdit = (studentId: string, flag: 'assignment' | 'quiz' | 'exam', value: number, targetSubjectCode?: string) => {
    setAutoSaveState('saving');
    
    // Use targetSubjectCode if provided (for special permissions) or default to teacher.subjectCode
    const subjectToEdit = targetSubjectCode || teacher.subjectCode;

    // Update locally stored students roster
    let studentToUpdate: Student | undefined;
    const updatedStudents = students.map(st => {
      if (st.id === studentId) {
        const rawGrade = st.grades[subjectToEdit];
        
        let assignments = rawGrade ? rawGrade.assignments : 20;
        let quizzes = rawGrade ? rawGrade.quizzes : 12;
        let exams = rawGrade ? Math.round((rawGrade.exams / 50) * 40) : 25;

        if (flag === 'assignment') assignments = Math.min(40, Math.max(0, value));
        if (flag === 'quiz') quizzes = Math.min(20, Math.max(0, value));
        if (flag === 'exam') exams = Math.min(40, Math.max(0, value));

        const computed = calculateLocalGrade(assignments, quizzes, exams);
        
        const updatedSt = {
          ...st,
          grades: {
            ...st.grades,
            [subjectToEdit]: {
              subjectCode: subjectToEdit,
              subjectName: rawGrade ? rawGrade.subjectName : 'Unknown',
              instructorName: teacher.name,
              assignments,
              quizzes,
              exams: Math.round((exams / 40) * 50),
              totalMark: computed.totalMark,
              creditHours: rawGrade ? rawGrade.creditHours : 3,
              gpaPoint: computed.gpaPoint,
              letterGrade: computed.letterGrade,
              status: computed.status === 'Needs Support' ? 'At Risk' : computed.status,
              progress: rawGrade ? rawGrade.progress : 92
            }
          }
        };
        studentToUpdate = updatedSt;
        return updatedSt;
      }
      return st;
    });

    setStudents(updatedStudents);
    saveStoredStudents(updatedStudents);
    if (onUpdateStudent && studentToUpdate) {
      onUpdateStudent(studentToUpdate);
    }

    window.dispatchEvent(new Event('ak_db_updated'));

    // Auto-save feedback loop
    setTimeout(() => {
      setAutoSaveState('saved');
      const now = new Date();
      setLastSavedTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 500);
  };

  const handleAttendanceEdit = (studentId: string, value: number) => {
    setAutoSaveState('saving');

    const updatedStudents = students.map(st => {
      if (st.id === studentId) {
        return {
          ...st,
          attendance: Math.min(100, Math.max(0, value))
        };
      }
      return st;
    });

    setStudents(updatedStudents);
    saveStoredStudents(updatedStudents);

    window.dispatchEvent(new Event('ak_db_updated'));

    setTimeout(() => {
      setAutoSaveState('saved');
      const now = new Date();
      setLastSavedTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 500);
  };

  // Action: Publish Results system
  const handlePublishToggle = () => {
    // If already published, unpublish back or confirm
    if (publishStatus === 'Published') {
      if (window.confirm("Are you sure you want to retract published scores code sheet? Candidates won't see updated results anymore.")) {
        setPublishStatus('Unpublished');
        localStorage.setItem(`ak_pubStatus_${teacher.subjectCode}`, 'Unpublished');
        addStoredLog(teacher.name, "Retracted public grade composition", teacher.subjectCode);
      }
      return;
    }

    // Check missing mark fields (warning checks)
    const hasZeroScores = mappedGrades.some(g => g.assignment === 0 || g.quiz === 0 || g.exam === 0);
    if (hasZeroScores) {
      if (!window.confirm("Warning: Some candidates have missing / unassigned score values. Do you still wish to release grades?")) {
        return;
      }
    }

    setPublishStatus('Publishing');
    setPublishProgress(0);

    const interval = setInterval(() => {
      setPublishProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setPublishStatus('Published');
          localStorage.setItem(`ak_pubStatus_${teacher.subjectCode}`, 'Published');
          
          // Add publication audit logs
          const now = new Date();
          const auditEntry = {
            id: `PUB-${Math.floor(1000 + Math.random() * 9000)}`,
            subject: teacher.subjectCode,
            date: now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
            time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
            teacherName: teacher.name,
            status: 'Released'
          };
          setPublicationLogs(prevLogs => [auditEntry, ...prevLogs]);

          // Push notifications trigger for students
          const prevNotifs = getStoredNotifications();
          const releaseNotif: AppNotification = {
            id: `notif-${Date.now()}`,
            title: `Mathematics Transcript Published: ${teacher.subjectCode}`,
            message: `${teacher.name} has released authorized final grades sheet for ${teacher.subjectName}. Verify in academic transcript panel.`,
            type: 'grade',
            date: 'Today',
            unread: true
          };
          saveStoredNotifications([releaseNotif, ...prevNotifs]);

          addStoredLog(teacher.name, `Released public grades database to registry`, teacher.subjectCode);
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  // Action: Submit teacher profile edits
  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profName || !profEmail) return;

    const updatedTeacherObj: Teacher = {
      ...teacher,
      name: profName,
      email: profEmail,
      teacherId: profId,
      avatar: profAvatar,
      subjectName: profDept
    };

    onProfileUpdate(updatedTeacherObj);
    setLocalTeacher(updatedTeacherObj); // Sync local state
    setProfileMsg("Faculty identity credentials consolidated successfully.");
    addStoredLog(profName, "Modified administrative staff profile info", "FACULTY");

    setTimeout(() => {
      setProfileMsg(null);
      setShowProfileModal(false);
    }, 1800);
  };

  // Action: Add note feedback to student record
  const handleAddNoteFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentForNote || !newCommentText.trim()) return;

    const studentId = selectedStudentForNote.id;
    const currentNotes = studentComments[studentId] || [];
    const updatedNotes = [newCommentText.trim(), ...currentNotes];

    setStudentComments({
      ...studentComments,
      [studentId]: updatedNotes
    });

    setNewCommentText('');
    setNoteSuccess(`Feedback note registered for ${selectedStudentForNote.name}!`);
    addStoredLog(teacher.name, `Logged academic counseling advisory note for ${selectedStudentForNote.name}`, teacher.subjectCode);

    setTimeout(() => {
      setNoteSuccess(null);
    }, 2000);
  };

  // Action: Schedule tutoring / intervention warning
  const scheduleIntervention = (studentName: string, actionType: string, riskLevel: string) => {
    const freshInt = {
      id: `INT-${Math.floor(100 + Math.random() * 900)}`,
      studentName,
      action: actionType,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      risk: riskLevel
    };

    setInterventions([freshInt, ...interventions]);
    addStoredLog(teacher.name, `Scheduled academic intervention [${actionType}] for candidate ${studentName}`, "INTERVENTION");

    // Push notification to students notify bucket
    const prevNotifs = getStoredNotifications();
    const alertNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: `Urgent Counseling: Academic Support Plan`,
      message: `${teacher.name} scheduled academic tracking tutoring program: '${actionType}'. Please report back to faculty office immediately.`,
      type: 'alert',
      date: 'Today',
      unread: true
    };
    saveStoredNotifications([alertNotif, ...prevNotifs]);

    alert(`Successfully registered intervention support program: ${actionType} for student ${studentName}. Notification alert dispatched.`);
  };

  // Formatted CSV export trigger
  const handleExportCSV = () => {
    const fileHeader = "Student Name,Student ID,Course Code,Assignment Score,Quiz Score,Exam Score,Total Marks,Calculated GPA,Letter Grade,Status\n";
    const dataContent = mappedGrades.map(item => (
      `"${item.student.name}","${item.student.studentId}","${teacher.subjectCode}",${item.assignment},${item.quiz},${item.exam},${item.total},${item.gpa},"${item.gradeLetter}","${item.status}"`
    )).join("\n");

    const blob = new Blob([fileHeader + dataContent], { type: 'text/csv;charset=utf-8;' });
    const downloadLink = document.createElement("a");
    const blobUrl = URL.createObjectURL(blob);
    downloadLink.href = blobUrl;
    downloadLink.setAttribute("download", `GradeSheet_${teacher.subjectCode}_${(activeClass || 'Class').replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(blobUrl);
  };

  // Structured Grade Sheet Print trigger
  const handlePrintSummary = () => {
    window.print();
  };

  // Pre-configured historical benchmark array for stats
  const aggregateHistGPAs = classStudents.length > 0 
    ? mappedGrades.map(m => m.gpa)
    : [3.4, 2.8, 3.8, 2.0, 3.1];

  return (
    <div id="teacher-dashboard-node" className={`min-h-screen flex flex-col md:flex-row transition-all duration-300 ${isDarkTheme ? 'dark bg-[#0f172a] text-slate-100' : 'bg-[#f1f5f9] text-[#0f172a]'}`}>
      
      {/* SIDEBAR */}
      <aside className={`w-full md:w-64 shrink-0 transition-all duration-300 ${isDarkTheme ? 'bg-[#1e293b]/90 border-slate-800' : 'bg-white/85 border-slate-200/60'} backdrop-blur-md border-b md:border-b-0 md:border-r px-4 py-6 flex flex-col justify-between z-20 print:hidden relative`}>
        <div className="space-y-7">
          {/* Brand logo & portal ID */}
          <div className="flex flex-col items-center justify-center text-center gap-2.5 px-1 pb-5 border-b border-slate-200/40 dark:border-slate-800/80">
            <div className="w-24 h-24 rounded-2xl bg-white p-1 flex items-center justify-center border border-blue-100 shadow-md">
              <img src={crestLogo} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-850 dark:text-blue-400 tracking-tight leading-none uppercase">Addis Ketema</h3>
              <span className="text-[9px] font-extrabold text-blue-600 tracking-[0.2em] block mt-1">EDUTRACK STAFF</span>
            </div>
          </div>

          {/* Teacher Profile Box (Editable Profile) */}
          <div className="relative overflow-hidden p-4 rounded-[1.8rem] bg-gradient-to-br from-blue-500/10 via-blue-500/[0.03] to-white border border-slate-200 shadow-sm space-y-3 group hover:border-blue-300 transition-all duration-300">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img 
                  src={localTeacher.avatar} 
                  alt={localTeacher.name} 
                  className="w-12 h-12 rounded-full object-cover border-2 border-blue-400" 
                  referrerPolicy="no-referrer" 
                />
                <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-black text-slate-800 truncate leading-tight">{localTeacher.name}</h4>
                <p className="text-[9.5px] text-slate-500 font-bold block mt-0.5">{localTeacher.teacherId}</p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200/50 flex justify-between items-center">
              <div>
                <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-bold">DEPARTMENT</span>
                <span className="text-[10.5px] font-black text-slate-800 truncate max-w-[130px] block mt-0.5">{localTeacher.subjectCode}</span>
              </div>

              {/* Edit Profile Action button */}
              <button
                onClick={() => setShowProfileModal(true)}
                className="p-1.5 rounded-xl bg-white hover:bg-blue-50/50 border border-slate-200 text-blue-600 transition-all cursor-pointer shadow-sm hover:scale-105"
                title="Edit Teacher profile credentials"
              >
                <UserCog className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Primary Navigation sidebar selector */}
          <nav className="space-y-1.5">
            <span className="text-[9px] uppercase tracking-widest font-black text-slate-400 block px-2">Workspaces</span>
            
            <button
              onClick={() => setActiveWorkspace('Dashboard')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-extrabold tracking-wide transition-all ${
                activeWorkspace === 'Dashboard'
                  ? 'bg-gradient-to-r from-blue-500/10 to-transparent border-l-4 border-blue-600 text-blue-700 dark:text-blue-450'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <LayoutDashboard className={`w-4 h-4 ${activeWorkspace === 'Dashboard' ? 'text-blue-600' : 'text-slate-400'}`} />
                <span>Dashboard</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 opacity-40" />
            </button>

            <button
              onClick={() => setActiveWorkspace('Grades')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-extrabold tracking-wide transition-all ${
                activeWorkspace === 'Grades'
                  ? 'bg-gradient-to-r from-blue-500/10 to-transparent border-l-4 border-blue-600 text-blue-700 dark:text-blue-450'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className={`w-4 h-4 ${activeWorkspace === 'Grades' ? 'text-blue-600' : 'text-slate-400'}`} />
                <span>Grade Management</span>
              </div>
              {failedCount > 0 && (
                <span className="bg-red-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full">
                  {failedCount}
                </span>
              )}
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 opacity-40" />
            </button>
          </nav>
        </div>

        {/* Action Logout */}
        <div className="pt-6 border-t border-slate-200 space-y-4">
          <div className="text-[9.5px] text-slate-400 font-bold px-1 space-y-1">
            <span className="block">Addis Ketema Academic Core</span>
            <span className="block font-mono">Build 2026.V2.4 • Active Session</span>
          </div>

          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 text-xs font-black text-red-600 hover:bg-red-50 border border-red-200/20 hover:border-red-500/40 rounded-2xl transition-all cursor-pointer shadow-sm shadow-red-500/[0.04]"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Session</span>
          </button>
        </div>
      </aside>

      {/* MAIN SCREEN WORKSPACE COMPONENT */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto space-y-6 relative print:p-0 print:bg-white print:text-black">
        
        {/* TOP STATUS HEADER WITH COMPACT PREVIEW CONTROLS */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 print:hidden">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[9px] tracking-widest font-black uppercase text-blue-600 select-none">FACULTY LEDGER ACCESS TERMINAL</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-slate-850 mt-1">Instructor Work Center</h1>
            <p className="text-xs text-slate-500 font-semibold mt-0.5">Faculty subject: <strong className="text-blue-600">{teacher.subjectName}</strong> ({teacher.subjectCode})</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Dark Theme toggle */}
            <button
              onClick={() => setIsDarkTheme(!isDarkTheme)}
              className="p-1.5 rounded-full hover:bg-blue-500/10 cursor-pointer text-blue-600 dark:text-blue-450 bg-white/75 dark:bg-[#1e293b]/80 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-center w-9 h-9"
              title="Toggle Dark Mode"
            >
              {isDarkTheme ? <Sun className="w-4 h-4 text-amber-500 animate-spin-halo" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            {/* ACTIVE ASSIGNED CLASS SELECTOR - Real logic affects calculations dynamically! */}
            <div className="flex flex-wrap items-center gap-2 bg-white/70 p-1.5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[10px] text-blue-700 font-extrabold px-3 uppercase">Academic Class:</span>
              {teacher.classes.map((cls) => (
                <button
                  key={cls}
                  onClick={() => setActiveClass(cls)}
                  className={`px-3.5 py-1.5 rounded-xl text-[10.5px] font-black cursor-pointer transition-all ${
                    activeClass === cls
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-800/10'
                      : 'bg-white/80 hover:bg-blue-50 text-slate-800 border border-slate-200'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>
          </div>
        </header>

        {/* WORKSPACE 1: INSIGHTS & ANALYTICS OVERVIEW */}
        {activeWorkspace === 'Dashboard' && (
          <div className="space-y-6">
            
            {/* INFORMATIVE BLOCKS / GLASSMORPHISM CARDS (4 cards) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              
              {/* Card 1: Total Students */}
              <div className="glass-panel p-5 bg-white/70 hover:translate-y-[-2px] transition-all duration-300 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-10 font-bold text-6xl pointer-events-none select-none text-slate-800">
                  <User className="w-12 h-12" />
                </div>
                <div className="flex justify-between items-start">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Active Students</span>
                  <span className="text-[9px] font-extrabold bg-[#059669]/10 text-emerald-800 px-1.5 py-0.5 rounded-full">
                    +12 this semester
                  </span>
                </div>
                <h3 className="text-3xl font-black text-slate-800 mt-1.5">{classStudents.length} Students</h3>
                
                {/* Dynamic sparkline path */}
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 font-semibold">Active grade headcount</span>
                  <svg className="w-16 h-6 text-blue-600 shrink-0" viewBox="0 0 100 30">
                    <path d={generateSparkline([2, 5, 8, 12, classStudents.length])} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
              </div>

              {/* Card 2: Average GPA */}
              <div className="glass-panel p-5 bg-white/70 hover:translate-y-[-2px] transition-all duration-300 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-3 opacity-10 font-bold text-6xl pointer-events-none select-none text-slate-800">
                  <TrendingUp className="w-12 h-12" />
                </div>
                <div className="flex justify-between items-start">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Subject Class GPA</span>
                  <span className="text-[9px] font-extrabold bg-blue-500/10 text-blue-700 px-1.5 py-0.5 rounded-full">
                    +4% GPA improvement
                  </span>
                </div>
                <h3 className="text-3xl font-black text-slate-800 mt-1.5">{averageGPA.toFixed(2)} GP</h3>
                
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 font-semibold">Real-time composite</span>
                  <svg className="w-16 h-6 text-blue-600 shrink-0" viewBox="0 0 100 30">
                    <path d={generateSparkline(aggregateHistGPAs)} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
              </div>

              {/* Card 3: Published Subjects (Gradient colored card - EXACT VALUE AS PORTED) */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-blue-600 to-blue-700 hover:translate-y-[-2px] transition-all duration-300 relative overflow-hidden shadow-md text-white">
                <div className="absolute top-0 right-0 p-2 opacity-15">
                  <Award className="w-16 h-16" />
                </div>
                <div className="flex justify-between items-start">
                  <span className="text-[9px] font-black uppercase tracking-widest text-blue-100">Subjects Published</span>
                  <span className="text-[10px] font-extrabold bg-white/15 text-white py-0.5 px-2 rounded-full flex items-center gap-1">
                    <Check className="w-2.5 h-2.5 text-emerald-300 stroke-[5px]" />
                    <span>100% complete</span>
                  </span>
                </div>
                <h3 className="text-3.5xl font-black mt-2">5/5</h3>

                <div className="mt-4 space-y-1.5">
                  <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400 rounded-full" style={{ width: '100%' }} />
                  </div>
                  <span className="text-[9.5px] text-blue-100 font-semibold block">All academic divisions finalized and uploaded.</span>
                </div>
              </div>

              {/* Card 4: Pass Rate (Green gradient card - CIRCULAR CHART - DYNAMICALLY COMPUTED) */}
              <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 hover:translate-y-[-2px] transition-all duration-300 relative overflow-hidden shadow-md text-white">
                <div className="absolute top-0 right-[-10px] p-2 opacity-15">
                  <Percent className="w-16 h-16" />
                </div>
                
                <div className="flex justify-between items-start">
                  <span className="text-[9px] font-black uppercase tracking-widest text-emerald-100">Pass Rate</span>
                  <span className="text-[9.5px] font-bold text-emerald-250 bg-emerald-800/30 px-2 py-0.5 rounded-full">
                    +5% vs last month
                  </span>
                </div>

                <div className="mt-2.5 flex items-center justify-between gap-2">
                  <div>
                    <h3 className="text-3xl font-black">{passRate}%</h3>
                    <p className="text-[9.5px] text-emerald-100/80 font-medium mt-1 leading-snug">
                      Passed students: <strong className="text-white">{passedStudentsCount}</strong> / {classStudents.length} total.
                    </p>
                  </div>

                  {/* Circular visual progress chart representing dynamic pass rate */}
                  <div className="relative w-14 h-14 shrink-0 flex items-center justify-center bg-emerald-800/20 rounded-full">
                    <svg className="w-12 h-12 transform -rotate-90">
                      <circle cx="24" cy="24" r="18" fill="transparent" stroke="rgba(255,255,255,0.15)" strokeWidth="3.5" />
                      <circle 
                        cx="24" 
                        cy="24" 
                        r="18" 
                        fill="transparent" 
                        stroke="#a7f3d0" 
                        strokeWidth="3.5" 
                        strokeDasharray={2 * Math.PI * 18}
                        strokeDashoffset={2 * Math.PI * 18 * (1 - passRate / 100)}
                        className="transition-all duration-700 ease-out"
                      />
                    </svg>
                    <span className="absolute text-[8.5px] font-black">{Math.round(passRate)}%</span>
                  </div>
                </div>
              </div>

            </div>            {/* PERFORMANCE INSIGHTS BENTO ROW (Leaderboards & GPA interactive chart) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Top Students Card (Leaderboard) */}
              <div className="lg:col-span-4 bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <div>
                    <h2 className="text-xs font-black tracking-wider text-slate-800 uppercase font-display">Top Students Leaderboard</h2>
                    <p className="text-[10px] text-slate-500 font-semibold">Ranked by calculated GPA</p>
                  </div>
                  <Award className="w-5 h-5 text-blue-500" />
                </div>

                <div className="space-y-4 pt-1">
                  {sortedPerformerList.slice(0, 3).map((item, idx) => {
                    const rankMedal = idx === 0 
                      ? { icon: '🥇', label: 'Gold Badge', style: 'bg-yellow-50 text-yellow-800 border-yellow-250 ring-yellow-400' }
                      : idx === 1 
                      ? { icon: '🥈', label: 'Silver Badge', style: 'bg-zinc-50 text-zinc-800 border-zinc-250 ring-zinc-300' }
                      : { icon: '🥉', label: 'Bronze Badge', style: 'bg-slate-50 text-blue-700 border-slate-200 ring-amber-400' };

                    return (
                      <div 
                        key={item.student.id} 
                        onClick={() => setSelectedStudentProfile(item.student)}
                        className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-amber-500/[0.01] to-amber-500/[0.03] border border-slate-200 hover:border-amber-300 cursor-pointer hover:translate-x-0.5 transition-all"
                        title="Click to view full Academic Profile & Edit Marks"
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-xl">{rankMedal.icon}</span>
                          <div className="relative">
                            <img src={item.student.avatar} alt="Avatar" className="w-9 h-9 rounded-full object-cover border border-slate-200" referrerPolicy="no-referrer" />
                            <span className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center text-[8px] font-black text-slate-800 border border-slate-200">
                              {idx + 1}
                            </span>
                          </div>
                          <div>
                            <h4 className="text-xs font-black text-slate-800">{item.student.name}</h4>
                            <span className="text-[9px] text-slate-500 uppercase block mt-0.5 tracking-wide">
                              Top Performer • DUX
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-black font-mono text-slate-800">{item.gpa.toFixed(2)} GP</span>
                          <span className="text-[8.5px] font-extrabold text-emerald-700 flex items-center gap-0.5 mt-0.5 justify-end">
                            <ArrowUpRight className="w-2.5 h-2.5" />
                            <span>1st Rank</span>
                          </span>
                        </div>
                      </div>
                    );
                  })}

                  {sortedPerformerList.length === 0 && (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      No active student averages generated.
                    </div>
                  )}
                </div>
              </div>

              {/* GPA Trend Chart container (Scatter or Line chart plotting all student GPAs) */}
              <div className="lg:col-span-8 bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <div>
                    <h2 className="text-xs font-black tracking-wider text-slate-800 uppercase font-display">Student Performance GPA Distribution</h2>
                    <p className="text-[10px] text-slate-500 font-semibold">Real-time 0.0 - 4.0 tracker scale for {activeClass}</p>
                  </div>

                  <div className="flex items-center gap-1 bg-blue-50/70 text-blue-800 text-[10px] font-bold px-2 py-1 rounded-xl">
                    <Activity className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
                    <span>Live Tracker Code</span>
                  </div>
                </div>

                {/* HIGH-END INTERACTIVE SVG CHART */}
                <div className="h-64 relative flex flex-col justify-end pt-5 select-none">
                  
                  {/* Grid Lines scale */}
                  <div className="absolute inset-0 flex flex-col justify-between text-[9px] font-mono text-slate-400 pointer-events-none pb-7 pt-4">
                    <div className="border-b border-slate-200/50 w-full pb-0.5">4.0 GPA - Excellent</div>
                    <div className="border-b border-slate-200/50 w-full pb-0.5">3.0 GPA - Good</div>
                    <div className="border-b border-slate-200/50 w-full pb-0.5">2.0 GPA - Satisfactory</div>
                    <div className="border-b border-slate-200/50 w-full pb-0.5">1.0 GPA - Academic Probation</div>
                    <div className="border-b border-slate-200/50 w-full pb-0.5">0.0 GPA - At Risk</div>
                  </div>

                  {/* SVG Line / Bar plot layout */}
                  <div className="h-44 w-full relative z-10 flex items-end justify-around px-4">
                    {mappedGrades.map((item, idx) => {
                      const heightPercent = (item.gpa / 4.0) * 100;
                      return (
                        <div key={item.student.id} className="relative flex flex-col items-center group w-full max-w-[50px]">
                          
                          {/* Tooltip on Hover */}
                          <div className="absolute bottom-full mb-2 bg-slate-900 text-slate-100 text-[9.5px] p-2 rounded-xl opacity-0 pointer-events-none group-hover:opacity-100 transition-all duration-200 shadow-xl border border-slate-850 z-30 min-w-[120px] text-center">
                            <p className="font-extrabold">{item.student.name}</p>
                            <p className="font-mono text-blue-400 mt-0.5">{item.total}% ({item.gpa.toFixed(2)} GPA)</p>
                            <p className="text-[8px] text-white/50">{item.gradeLetter} ({item.status})</p>
                          </div>

                          {/* SVG Bar */}
                          <div className="w-4 rounded-t-md relative overflow-hidden transition-all duration-500" style={{ height: `${heightPercent}%` }}>
                            {/* Color mapping */}
                            <div className={`h-full w-full ${
                              item.total >= 80 
                                ? 'bg-gradient-to-t from-blue-600 to-blue-400' 
                                : item.total >= 50 
                                ? 'bg-gradient-to-t from-blue-500 to-blue-300' 
                                : 'bg-gradient-to-t from-red-600 to-red-400'
                            }`} />
                          </div>

                          {/* Target identifier */}
                          <span className="text-[8.5px] font-black font-mono text-slate-600 mt-2 block w-full truncate text-center">
                            {item.student.name.split(' ')[0]}
                          </span>
                        </div>
                      );
                    })}

                    {mappedGrades.length === 0 && (
                      <div className="text-slate-400 text-xs py-10">
                        Select an academic class with student records to plot dynamic charts.
                      </div>
                    )}
                  </div>

                </div>
              </div>

            </div>

            {/* HIGH-FIDELITY SUBJECT STUDENT ROSTER TABLE (CLASS ROSTER SYSTEM) */}
            <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h2 className="text-xs font-black tracking-wider text-slate-800 uppercase font-display flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    📖 Subject Class Roster Tracker
                  </h2>
                  <p className="text-[10px] text-slate-500 font-semibold">
                    Complete institutional performance roster for {teacher.subjectName} ({activeClass})
                  </p>
                </div>
                
                <div className="text-[10px] font-bold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 shadow-sm">
                  Active enrolled students: <span className="font-mono font-black text-slate-800">{mappedGrades.length}</span>
                </div>
              </div>

              {/* Roster responsive table container */}
              <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
                <table className="w-full text-left text-xs border-collapse font-bold text-[#0f172a]">
                  <thead>
                    <tr className="bg-slate-50 text-slate-800 border-b border-slate-200 uppercase text-[9.5px] font-black tracking-wider select-none">
                      <th className="py-3 px-4">Student Profile & ID</th>
                      <th className="py-3 px-3 text-center">Division</th>
                      <th className="py-3 px-3 text-center">Assignment (40)</th>
                      <th className="py-3 px-3 text-center">Quiz (20)</th>
                      <th className="py-3 px-3 text-center">Exam (40)</th>
                      <th className="py-3 px-4 text-center">Total Score (100)</th>
                      <th className="py-3 px-3 text-center">Weighted GPA</th>
                      <th className="py-3 px-3 text-center">Letter Grade</th>
                      <th className="py-3 px-3 text-center">Performance Status</th>
                      <th className="py-3 px-3 text-center">Attendance %</th>
                      <th className="py-3 px-4 text-center">Action Profile</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {mappedGrades.map((item) => {
                      const isStudentFailing = item.total < 50;
                      return (
                        <tr 
                          key={item.student.id} 
                          className={`hover:bg-amber-500/[0.02]/30 transition-colors duration-150 ${
                            isStudentFailing ? 'bg-red-500/[0.02]' : ''
                          }`}
                        >
                          
                          {/* Student Details - Clickable */}
                          <td className="py-3.5 px-4">
                            <div 
                              onClick={() => setSelectedStudentProfile(item.student)}
                              className="flex items-center gap-3 cursor-pointer group"
                              title="Click to view full student file"
                            >
                              <div className="shrink-0 relative group-hover:scale-105 transition-transform duration-200">
                                {item.student.avatar ? (
                                  <img 
                                    src={item.student.avatar} 
                                    alt={item.student.name} 
                                    className="w-9 h-9 rounded-full object-cover border border-slate-200 shadow-sm" 
                                    referrerPolicy="no-referrer" 
                                  />
                                ) : (
                                  <div className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center font-black uppercase text-slate-600 border shadow-sm">
                                    {item.student.name.substring(0, 1)}
                                  </div>
                                )}
                                {isStudentFailing && (
                                  <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-650 rounded-full border-2 border-white animate-pulse" />
                                )}
                              </div>
                              <div className="min-w-0">
                                <h4 className="font-extrabold text-[#7c4d1d] group-hover:text-amber-805 group-hover:underline truncate text-sm">
                                  {item.student.name}
                                </h4>
                                <span className="text-[10px] font-mono text-slate-500 block mt-0.5">
                                  {item.student.studentId}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Level */}
                          <td className="py-3.5 px-3 text-center">
                            <span className="px-2 py-1 rounded-lg bg-slate-100 text-slate-600 text-[10px] font-bold border border-slate-200/50">
                              {activeClass}
                            </span>
                          </td>

                          {/* Scores summary indicators */}
                          <td className="py-3.5 px-3 text-center text-slate-700 font-mono">
                            {item.assignment} pts
                          </td>
                          <td className="py-3.5 px-3 text-center text-slate-700 font-mono">
                            {item.quiz} pts
                          </td>
                          <td className="py-3.5 px-3 text-center text-slate-700 font-mono">
                            {item.exam} pts
                          </td>

                          {/* Progress Total Bar */}
                          <td className="py-3.5 px-4 text-center">
                            <div className="space-y-1 w-full max-w-[110px] mx-auto">
                              <div className="flex justify-between items-center text-[10px] font-extrabold font-mono">
                                <span className={isStudentFailing ? 'text-red-600' : 'text-slate-800'}>{item.total}%</span>
                                <span className="text-[8px] text-slate-405 font-bold uppercase">Mark</span>
                              </div>
                              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    item.total >= 80 ? 'bg-emerald-500' : item.total >= 50 ? 'bg-blue-500' : 'bg-red-500'
                                  }`}
                                  style={{ width: `${item.total}%` }} 
                                />
                              </div>
                            </div>
                          </td>

                          {/* GPA Code */}
                          <td className="py-3.5 px-3 text-center font-mono">
                            <span className={`px-2 py-0.5 rounded text-xs font-black ${
                              item.gpa >= 3.3 ? 'text-emerald-850 bg-emerald-50' : item.gpa >= 2.0 ? 'text-blue-800 bg-blue-50' : 'text-red-750 bg-red-50'
                            }`}>
                              {item.gpa.toFixed(2)} GP
                            </span>
                          </td>

                          {/* Mark Grade badge */}
                          <td className="py-3.5 px-3 text-center">
                            <span className={`px-2.5 py-1 rounded-md font-black text-xs inline-block ${
                              item.gradeLetter === 'A' 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : item.gradeLetter === 'B' 
                                ? 'bg-blue-100 text-blue-800' 
                                : item.gradeLetter === 'C' 
                                ? 'bg-blue-50 text-blue-700' 
                                : item.gradeLetter === 'D' 
                                ? 'bg-orange-100 text-orange-810' 
                                : 'bg-red-100 text-red-700'
                            }`}>
                              {item.gradeLetter}
                            </span>
                          </td>

                          {/* Performance tag */}
                          <td className="py-3.5 px-3 text-center">
                            <span className={`text-[10px] font-black uppercase tracking-wider block ${
                              item.status === 'Excellent' 
                                ? 'text-emerald-700' 
                                : item.status === 'Good' 
                                ? 'text-blue-700' 
                                : item.status === 'Average' 
                                ? 'text-slate-500' 
                                : 'text-red-650'
                            }`}>
                              {item.status}
                            </span>
                          </td>

                          {/* Attendance percentage progress bar */}
                          <td className="py-3.5 px-3 text-center">
                            <div className="space-y-1 w-full max-w-[90px] mx-auto">
                              <div className="flex justify-between items-center text-[10px] font-extrabold font-mono">
                                <span className={(item.student.attendance ?? 95.0) < 85 ? 'text-red-600 font-black' : 'text-slate-800'}>
                                  {(item.student.attendance ?? 95.0).toFixed(1)}%
                                </span>
                                <span className={`text-[8px] font-bold uppercase ${(item.student.attendance ?? 95.0) < 85 ? 'text-red-500' : 'text-slate-400'}`}>
                                  {(item.student.attendance ?? 95.0) < 85 ? 'LOW ⚠️' : 'OK ✓'}
                                </span>
                              </div>
                              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    (item.student.attendance ?? 95.0) >= 90 
                                      ? 'bg-emerald-500' 
                                      : (item.student.attendance ?? 95.0) >= 85 
                                      ? 'bg-amber-500' 
                                      : 'bg-red-500 animate-pulse'
                                  }`}
                                  style={{ width: `${Math.min(100, item.student.attendance ?? 95.0)}%` }} 
                                />
                              </div>
                            </div>
                          </td>

                          {/* View card profiles trigger */}
                          <td className="py-3.5 px-4 text-center">
                            <button
                              onClick={() => setSelectedStudentProfile(item.student)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200/50 hover:border-blue-300 text-blue-700 hover:text-blue-850 rounded-xl text-[10.5px] font-extrabold transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95"
                            >
                              📋 Student File
                            </button>
                          </td>

                        </tr>
                      );
                    })}

                    {mappedGrades.length === 0 && (
                      <tr>
                        <td colSpan={10} className="py-12 text-center text-slate-400 font-bold">
                          No enrolled students in class {activeClass} subject records roster.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold pt-1">
                <span>⚡ Tip: Click any student's row profile to review comprehensive transcript records and edit grades.</span>
                <span className="font-mono">{mappedGrades.length} rows loaded</span>
              </div>
            </div>

            {/* LOWER PORTION: RELEASE REGISTRY & INTERVENTION CENTER */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Published Results card */}
              <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <div>
                    <h2 className="text-xs font-black tracking-wider text-slate-800 uppercase font-display">Published Academic Records</h2>
                    <p className="text-[10px] text-slate-500 font-semibold">{publicationLogs.length} published results available online</p>
                  </div>

                  <button
                    onClick={handlePrintSummary}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-blue-50/50 text-blue-600 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Ledger Sheet</span>
                  </button>
                  <button
                    onClick={handleExportCSV}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-emerald-50/50 text-emerald-600 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download CSV Results</span>
                  </button>
                </div>

                <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                  {publicationLogs.map((log) => (
                    <div key={log.id} className="p-3 bg-slate-50/60 rounded-2xl border border-slate-200/50 flex items-center justify-between text-xs">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-slate-800 font-mono">{log.id}</span>
                          <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[8px] font-black uppercase">
                            {log.status}
                          </span>
                        </div>
                        <p className="font-semibold text-slate-600">
                          {log.subject} Transcript • Verified by {log.teacherName}
                        </p>
                      </div>

                      <div className="text-right text-slate-500">
                        <p className="font-mono">{log.date}</p>
                        <p className="text-[9px] mt-0.5 font-bold">{log.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* FAILED STUDENTS INTERVENTION CENTER */}
              <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <div>
                    <h2 className="text-xs font-black tracking-wider text-slate-800 uppercase font-display">Intervention Program Registry</h2>
                    <p className="text-[10px] text-slate-500 font-semibold">Active help scheduled for struggling candidates</p>
                  </div>

                  <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-[9px] font-black">
                    {failedCount} at critical risk
                  </span>
                </div>

                <div className="divide-y divide-slate-100 max-h-[220px] overflow-y-auto">
                  {mappedGrades.filter(g => g.total < 50).map(g => (
                    <div key={g.student.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5">
                        <img src={g.student.avatar} alt="Avatar" className="w-8 h-8 rounded-full object-cover border border-slate-200" referrerPolicy="no-referrer" />
                        <div>
                          <h4 className="font-black text-slate-800">{g.student.name}</h4>
                          <span className="text-[9.5px] font-mono text-red-600 block mt-0.5">
                            Grade: {g.gradeLetter} • Total Score: {g.total}%
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1.5">
                        <button
                          onClick={() => scheduleIntervention(g.student.name, 'Assigned Mandatory Tutoring', 'High')}
                          className="px-2 py-1 rounded bg-blue-500/10 text-blue-800 hover:bg-blue-500/20 text-[9.5px] font-black cursor-pointer "
                        >
                          + Tutoring
                        </button>
                        <button
                          onClick={() => scheduleIntervention(g.student.name, 'Issued Parent Counseling Plan', 'Critical')}
                          className="px-2 py-1 rounded bg-red-100 text-red-705 hover:bg-red-200 text-[9.5px] font-black cursor-pointer text-red-705"
                        >
                          + Contact Parent
                        </button>
                      </div>
                    </div>
                  ))}

                  {mappedGrades.filter(g => g.total < 50).length === 0 && (
                    <div className="py-10 text-center text-slate-400 text-xs font-semibold">
                      🎉 Awesome! There are no failing students (Score &lt; 50) inside active class roster.
                    </div>
                  )}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* WORKSPACE 2: ADVANCED SPREADSHEET SHEET & GRADE ENTERING */}
        {activeWorkspace === 'Grades' && (
          <div className="space-y-6">
            
            {/* GRADE PANEL CONSOLE HEADER AREA */}
            <div className="p-6 rounded-[2rem] bg-white border border-slate-200 shadow-sm space-y-4">
              
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                
                {/* Title and subtitle */}
                <div className="space-y-1">
                  <h2 className="text-sm font-black text-slate-850 uppercase tracking-widest font-display">Grade Entry & Analysis</h2>
                  <p className="text-xs text-slate-500 font-semibold">
                    Edit scores inline — saved automatically in real time
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  {/* AUTO SAVE INDICATOR */}
                  <div className="flex items-center gap-2 px-3  py-1.5 bg-blue-50/50 border border-slate-200 rounded-xl text-[11px] font-extrabold select-none">
                    {autoSaveState === 'saving' ? (
                      <>
                        <RefreshCw className="w-3 h-3 text-blue-600 animate-spin" />
                        <span className="text-blue-800">Saving...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-3 h-3 text-emerald-600" />
                        <span className="text-emerald-800">Saved Successfully • <span className="font-mono">{lastSavedTime}</span></span>
                      </>
                    )}
                  </div>

                  {/* PUBLISH RESULTS PILL TRIGGER */}
                  <button
                    onClick={handlePublishToggle}
                    disabled={publishStatus === 'Publishing'}
                    className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-black cursor-pointer transition-all ${
                      publishStatus === 'Published'
                        ? 'bg-emerald-500 text-white shadow-sm'
                        : publishStatus === 'Publishing'
                        ? 'bg-blue-105 bg-blue-100 text-blue-800 font-bold'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200'
                    }`}
                  >
                    {publishStatus === 'Publishing' ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Publishing ({publishProgress}%)</span>
                      </>
                    ) : publishStatus === 'Published' ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[3px]" />
                        <span>Published</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Publish Results</span>
                      </>
                    )}
                  </button>

                  {/* EXPORT DATA BUTTON */}
                  <button
                    onClick={handleExportCSV}
                    className="p-2 border border-slate-200 bg-white hover:bg-blue-50 text-blue-600 rounded-xl transition-all cursor-pointer shadow-sm hover:scale-105"
                    title="Export academic records to CSV Spreadsheet"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>

              </div>

              {/* TABS SEGMENT SELECTOR (Entry, Distribution analysis, Failed candidates) */}
              <div className="flex justify-between items-center pt-3 border-t border-slate-200 gap-3">
                
                {/* Segment Controls list */}
                <div className="flex gap-1.5 p-1 bg-blue-500/5 rounded-2xl border border-slate-250 border-slate-200 shrink-0">
                  <button
                    onClick={() => setActiveGradeTab('Entry')}
                    className={`px-4.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      activeGradeTab === 'Entry'
                        ? 'bg-blue-600 text-white shadow shadow-blue-800/10'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Grade Entry
                  </button>
                  <button
                    onClick={() => setActiveGradeTab('Analysis')}
                    className={`px-4.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      activeGradeTab === 'Analysis'
                        ? 'bg-blue-600 text-white shadow shadow-blue-800/10'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Analysis
                  </button>
                  <button
                    onClick={() => setActiveGradeTab('Failed')}
                    className={`relative px-4.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      activeGradeTab === 'Failed'
                        ? 'bg-blue-600 text-white shadow shadow-blue-800/10'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span>Failed Candidates</span>
                    {failedCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[8.5px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center animate-bounce">
                        {failedCount}
                      </span>
                    )}
                  </button>
                  <button
                    onClick={() => setActiveGradeTab('Attendance')}
                    className={`px-4.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      activeGradeTab === 'Attendance'
                        ? 'bg-blue-600 text-white shadow shadow-blue-800/10'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Attendance
                  </button>
                </div>

                {/* ADVANCED MULTI-FIELDS FILTER OPTIONS */}
                <div className="flex flex-wrap items-center gap-3">
                  
                  {/* GPA Filter scale */}
                  <div className="relative text-xs">
                    <select
                      value={gpaRangeFilter}
                      onChange={(e) => setGpaRangeFilter(e.target.value as any)}
                      className="bg-white border border-slate-200 py-1.5 pl-2.5 pr-8 rounded-xl font-bold focus:outline-none focus:border-blue-500 text-slate-800"
                    >
                      <option value="All">All GPAs</option>
                      <option value="High">&ge; 3.3 (High)</option>
                      <option value="Mid">2.0 - 3.2 (Mid)</option>
                      <option value="Low">&lt; 2.0 (Low)</option>
                    </select>
                  </div>

                  {/* Search filter bar */}
                  <div className="relative w-full sm:w-48">
                    <span className="absolute inset-y-0 left-2.5 flex items-center text-slate-400 pointer-events-none">
                      <Search className="w-3.5 h-3.5" />
                    </span>
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search students..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-1.5 pl-8 pr-3 text-xs font-semibold focus:outline-none focus:bg-white focus:border-blue-500 text-slate-800"
                    />
                  </div>

                </div>

              </div>
              
            </div>

            {/* TAB PANELS RENDERER */}
            {activeGradeTab === 'Entry' && (
              <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden p-6 space-y-4">
                
                {/* Spreadsheet responsive table container */}
                <div className="hidden md:block overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left text-xs border-collapse font-bold text-[#0f172a]">
                    <thead>
                      <tr className="bg-slate-50 text-slate-800 border-b border-slate-200/80 uppercase text-[9.5px] font-black select-none tracking-wider">
                        <th className="py-3 px-4 min-w-[200px]">Student Profile</th>
                        <th className="py-3 px-3 text-center">Division Code</th>
                        <th className="py-3 px-3 text-center min-w-[110px]">Assignment / 40</th>
                        <th className="py-3 px-3 text-center min-w-[110px]">Quiz / 20</th>
                        <th className="py-3 px-3 text-center min-w-[110px]">Exam / 40</th>
                        <th className="py-3 px-4 text-center min-w-[140px]">Total Score (100)</th>
                        <th className="py-3 px-3 text-center">Calculated GPA</th>
                        <th className="py-3 px-3 text-center">Grade Badge</th>
                        <th className="py-3 px-3 text-center">Status</th>
                        <th className="py-3 px-4 text-center">Advisory Note</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredAndSortedGrades.map((item) => {
                        const isStudentFailing = item.total < 50;
                        return (
                          <tr 
                            key={item.student.id} 
                            className={`transition-colors duration-200 ${
                              isStudentFailing ? 'bg-red-500/[0.04] hover:bg-red-100/20' : 'hover:bg-slate-50'
                            }`}
                          >
                            
                            {/* Student section */}
                            <td className="py-3 px-4">
                              <div 
                                onClick={() => setSelectedStudentProfile(item.student)}
                                className="flex items-center gap-3 cursor-pointer group"
                                title="Click to view full Academic Profile & Edit Marks"
                              >
                                <div className="shrink-0 relative group-hover:scale-110 transition-transform">
                                  {item.student.avatar ? (
                                    <img 
                                      src={item.student.avatar} 
                                      alt={item.student.name} 
                                      className="w-10 h-10 rounded-full object-cover border border-slate-205" 
                                      referrerPolicy="no-referrer" 
                                    />
                                  ) : (
                                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-black uppercase text-slate-700 border">
                                      {item.student.name.substring(0, 1)}
                                    </div>
                                  )}
                                  {isStudentFailing && (
                                    <span className="absolute top-0 right-0 w-3 h-3 bg-red-650 rounded-full border-2 border-white animate-pulse" title="Academic Intervention required" />
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <h4 className="font-extrabold text-[#7c4d1d] group-hover:text-amber-800 group-hover:underline truncate text-sm">{item.student.name}</h4>
                                  <span className="text-[10px] font-mono text-slate-500 block mt-0.5 group-hover:text-slate-700">{item.student.studentId} • Profile 📋</span>
                                </div>
                              </div>
                            </td>

                            {/* Class/Subject code badge */}
                            <td className="py-3 px-3 text-center">
                              <span className="px-2 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-[10px] font-black border border-blue-100">
                                {teacher.subjectCode}
                              </span>
                            </td>

                            {/* SPREADSHEET ELEMENT: Assignments Out of 40 inputs */}
                            <td className="py-3 px-3 text-center">
                              <input
                                type="number"
                                min="0"
                                max="40"
                                value={item.assignment}
                                onChange={(e) => handleScoreEdit(item.student.id, 'assignment', parseFloat(e.target.value) || 0)}
                                className="w-16 bg-slate-50 border border-slate-200 rounded-xl py-2 px-1 text-center font-bold text-xs uppercase focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent transition-all"
                              />
                            </td>

                            {/* SPREADSHEET ELEMENT: Quizzes Out of 20 inputs */}
                            <td className="py-3 px-3 text-center">
                              <input
                                type="number"
                                min="0"
                                max="20"
                                value={item.quiz}
                                onChange={(e) => handleScoreEdit(item.student.id, 'quiz', parseFloat(e.target.value) || 0)}
                                className="w-16 bg-slate-50 border border-slate-200 rounded-xl py-2 px-1 text-center font-bold text-xs uppercase focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent transition-all"
                              />
                            </td>

                            {/* SPREADSHEET ELEMENT: Exams Out of 40 inputs */}
                            <td className="py-3 px-3 text-center">
                              <input
                                type="number"
                                min="0"
                                max="40"
                                value={item.exam}
                                onChange={(e) => handleScoreEdit(item.student.id, 'exam', parseFloat(e.target.value) || 0)}
                                className="w-16 bg-slate-50 border border-slate-200 rounded-xl py-2 px-1 text-center font-bold text-xs uppercase focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white focus:border-transparent transition-all"
                              />
                            </td>

                            {/* Calculated Total score column */}
                            <td className="py-3 px-4 text-center">
                              <div className="space-y-1 w-full max-w-[120px] mx-auto">
                                <div className="flex justify-between items-center text-[11px] font-black font-mono">
                                  <span className={isStudentFailing ? 'text-red-600' : 'text-slate-800'}>{item.total}%</span>
                                  <span className="text-[9px] text-slate-400 uppercase font-bold">Accumulated</span>
                                </div>
                                <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                  <div 
                                    className={`h-full rounded-full transition-all duration-300 ${
                                      item.total >= 80 ? 'bg-emerald-600' : item.total >= 50 ? 'bg-blue-600' : 'bg-red-500'
                                    }`}
                                    style={{ width: `${item.total}%` }} 
                                  />
                                </div>
                              </div>
                            </td>

                            {/* Computed GPA column */}
                            <td className="py-3 px-3 text-center font-mono">
                              <span className={`px-2 py-0.5 rounded text-xs font-black ${
                                item.gpa >= 3.3 ? 'text-emerald-850 bg-emerald-50' : item.gpa >= 2.0 ? 'text-blue-800 bg-blue-50' : 'text-red-750 bg-red-50'
                              }`}>
                                {item.gpa.toFixed(2)}
                              </span>
                            </td>

                            {/* Calculated Grade Badge */}
                            <td className="py-3 px-3 text-center">
                              <span className={`px-2.5 py-1 rounded-md font-black text-xs inline-block ${
                                item.gradeLetter === 'A' 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : item.gradeLetter === 'B' 
                                  ? 'bg-blue-100 text-blue-800' 
                                  : item.gradeLetter === 'C' 
                                  ? 'bg-blue-50/70 text-blue-700' 
                                  : item.gradeLetter === 'D' 
                                  ? 'bg-orange-100 text-orange-800' 
                                  : 'bg-red-100 text-red-700 font-extrabold'
                              }`}>
                                {item.gradeLetter}
                              </span>
                            </td>

                            {/* Academic Performance Status */}
                            <td className="py-3 px-3 text-center">
                              <span className={`text-[10px] font-black uppercase tracking-wider block ${
                                item.status === 'Excellent' 
                                  ? 'text-emerald-700' 
                                  : item.status === 'Good' 
                                  ? 'text-blue-700' 
                                  : item.status === 'Average' 
                                  ? 'text-slate-500' 
                                  : 'text-red-600'
                              }`}>
                                {item.status === 'Needs Support' ? 'Needs Support' : item.status}
                              </span>
                            </td>

                            {/* Actions notes panel selection */}
                            <td className="py-3 px-4 text-center">
                              <button
                                onClick={() => setSelectedStudentForNote(item.student)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-slate-705 text-[10.5px] font-black transition-all cursor-pointer border border-transparent hover:border-slate-200"
                              >
                                <PlusCircle className="w-3.5 h-3.5" />
                                <span>+ Note</span>
                              </button>
                            </td>

                          </tr>
                        );
                      })}

                      {filteredAndSortedGrades.length === 0 && (
                        <tr>
                          <td colSpan={10} className="py-12 text-center text-slate-400 font-bold">
                            No study candidates match filters inside {activeClass}.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Mobile screen card-based list */}
                <div className="grid grid-cols-1 gap-4 md:hidden">
                  {filteredAndSortedGrades.map((item) => {
                    const isStudentFailing = item.total < 50;
                    return (
                      <div 
                        key={item.student.id} 
                        className={`p-4 rounded-2xl border transition-all duration-200 ${
                          isStudentFailing 
                            ? 'bg-red-500/[0.02] border-red-200 shadow-sm shadow-red-500/5' 
                            : 'bg-[#fafbfc] border-slate-200/80 hover:border-slate-300 shadow-sm'
                        }`}
                      >
                        {/* Student Profile & Badge */}
                        <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
                          <div 
                            onClick={() => setSelectedStudentProfile(item.student)}
                            className="flex items-center gap-3 cursor-pointer group"
                            title="Click to view full Academic Profile & Edit Marks"
                          >
                            <div className="relative shrink-0 group-hover:scale-105 transition-transform">
                              {item.student.avatar ? (
                                <img 
                                  src={item.student.avatar} 
                                  alt={item.student.name} 
                                  className="w-10 h-10 rounded-full object-cover border border-slate-200" 
                                  referrerPolicy="no-referrer" 
                                />
                              ) : (
                                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-black uppercase text-slate-700 border border-slate-200">
                                  {item.student.name.substring(0, 1)}
                                </div>
                              )}
                              {isStudentFailing && (
                                <span className="absolute top-0 right-0 w-3 h-3 bg-red-650 rounded-full border-2 border-white animate-pulse" />
                              )}
                            </div>
                            <div className="min-w-0">
                              <h4 className="font-extrabold text-[#7c4d1d] group-hover:text-amber-805 group-hover:underline truncate text-sm">{item.student.name}</h4>
                              <span className="text-[10px] font-mono text-slate-500 block mt-0.5">{item.student.studentId} • Profile 📋</span>
                            </div>
                          </div>
                          
                          <span className="px-2.5 py-1 rounded-md font-black text-xs shrink-0 bg-blue-50 text-blue-700 border border-blue-105">
                            {teacher.subjectCode}
                          </span>
                        </div>

                        {/* Interactive spreadsheet inputs */}
                        <div className="py-3.5 grid grid-cols-3 gap-3 border-b border-slate-100">
                          <div className="text-center space-y-1">
                            <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-tight">Assign/40</label>
                            <input
                              type="number"
                              min="0"
                              max="40"
                              value={item.assignment}
                              onChange={(e) => handleScoreEdit(item.student.id, 'assignment', parseFloat(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-205 rounded-xl py-1.5 px-1 text-center font-bold text-xs uppercase focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm"
                            />
                          </div>
                          <div className="text-center space-y-1">
                            <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-tight">Quiz/20</label>
                            <input
                              type="number"
                              min="0"
                              max="20"
                              value={item.quiz}
                              onChange={(e) => handleScoreEdit(item.student.id, 'quiz', parseFloat(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-205 rounded-xl py-1.5 px-1 text-center font-bold text-xs uppercase focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm"
                            />
                          </div>
                          <div className="text-center space-y-1">
                            <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-tight">Exam/40</label>
                            <input
                              type="number"
                              min="0"
                              max="40"
                              value={item.exam}
                              onChange={(e) => handleScoreEdit(item.student.id, 'exam', parseFloat(e.target.value) || 0)}
                              className="w-full bg-white border border-slate-205 rounded-xl py-1.5 px-1 text-center font-bold text-xs uppercase focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm"
                            />
                          </div>
                        </div>

                        {/* Metrics, calculations & status indicators */}
                        <div className="pt-3.5 flex flex-col gap-3">
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center text-xs font-black font-mono">
                              <span className="text-slate-450 uppercase text-[9px] font-bold">Accumulated Mark Score:</span>
                              <span className={isStudentFailing ? 'text-red-600' : 'text-slate-800'}>{item.total}%</span>
                            </div>
                            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all duration-300 ${
                                  item.total >= 80 ? 'bg-emerald-600' : item.total >= 50 ? 'bg-blue-600' : 'bg-red-500'
                                }`}
                                style={{ width: `${item.total}%` }} 
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-2 py-0.5 bg-slate-50/70 border border-slate-150 rounded-xl p-2.5">
                            <div className="text-center">
                              <span className="text-[9px] text-slate-400 block font-extrabold uppercase">GPA</span>
                              <span className={`text-[11px] font-extrabold font-mono inline-block mt-0.5 px-1.5 py-0.5 rounded ${
                                item.gpa >= 3.3 ? 'text-emerald-800 bg-emerald-50' : item.gpa >= 2.0 ? 'text-blue-800 bg-blue-50' : 'text-red-700 bg-red-50'
                              }`}>
                                {item.gpa.toFixed(2)}
                              </span>
                            </div>
                            <div className="text-center">
                              <span className="text-[9px] text-slate-400 block font-extrabold uppercase">Grade</span>
                              <span className={`text-[11px] font-extrabold inline-block mt-1 px-1.5 py-0.5 rounded ${
                                item.gradeLetter === 'A' 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : item.gradeLetter === 'B' 
                                  ? 'bg-blue-100 text-blue-800' 
                                  : item.gradeLetter === 'C' 
                                  ? 'bg-blue-50/70 text-blue-700' 
                                  : 'bg-red-100 text-red-700'
                              }`}>
                                {item.gradeLetter}
                              </span>
                            </div>
                            <div className="text-center">
                              <span className="text-[9px] text-slate-400 block font-extrabold uppercase">Status</span>
                              <span className={`text-[10px] font-black uppercase tracking-wide block mt-1.5 ${
                                item.status === 'Excellent' 
                                  ? 'text-emerald-700' 
                                  : item.status === 'Good' 
                                  ? 'text-blue-700' 
                                  : item.status === 'Average' 
                                  ? 'text-slate-500' 
                                  : 'text-red-600'
                              }`}>
                                {item.status === 'Needs Support' ? 'Needs Support' : item.status}
                              </span>
                            </div>
                          </div>

                          <div className="flex justify-end pt-1">
                            <button
                              onClick={() => setSelectedStudentForNote(item.student)}
                              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-slate-700 text-xs font-black transition-all cursor-pointer border border-slate-200"
                            >
                              <PlusCircle className="w-3.5 h-3.5 text-slate-400" />
                              <span>+ Advisory Note</span>
                            </button>
                          </div>
                        </div>

                      </div>
                    );
                  })}

                  {filteredAndSortedGrades.length === 0 && (
                    <div className="py-12 text-center text-slate-400 font-bold text-xs bg-slate-50 rounded-2xl border border-dashed border-slate-205">
                      No study candidates match filters inside {activeClass}.
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* TAB PANELS: DISTRIBUTION ANALYSIS GRIDS */}
            {activeGradeTab === 'Analysis' && (
              <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-6">
                
                <h3 className="text-xs font-black uppercase tracking-widest text-[#a1713e]">Division grade analysis breakdown</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  {['A', 'B', 'C', 'D', 'F'].map(letter => {
                    const count = classStudents.filter(st => {
                      const computed = calculateLocalGrade(
                        st.grades[teacher.subjectCode]?.assignments || 20,
                        st.grades[teacher.subjectCode]?.quizzes || 12,
                        Math.round(((st.grades[teacher.subjectCode]?.exams || 30) / 50) * 40)
                      );
                      return computed.letterGrade === letter;
                    }).length;

                    const percentOfTotal = classStudents.length > 0 
                      ? Math.round((count / classStudents.length) * 100)
                      : 0;

                    return (
                      <div key={letter} className="p-5 rounded-2xl bg-[#fcf8f2] border border-slate-200/40 text-center space-y-2">
                        <span className="text-[10px] font-black text-slate-700 block">Grade Division Code</span>
                        <h4 className="text-4xl font-extrabold text-slate-800 font-display">{letter}</h4>
                        <div className="space-y-1">
                          <span className="text-xs font-extrabold text-blue-600 block">{count} Students</span>
                          <span className="text-[10px] text-slate-500/50 font-bold block">{percentOfTotal}% of total</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Additional metrics */}
                <div className="p-4.5 rounded-2xl bg-slate-50/50 border border-slate-200 flex flex-wrap justify-between items-center gap-4 text-xs">
                  <div>
                    <span className="text-[9.5px] tracking-wide font-black text-[#966b3f] uppercase block">Benchmark Metrics</span>
                    <p className="font-extrabold text-slate-600 mt-0.5">Highest Mark Score: <strong className="text-slate-700">{Math.max(...mappedGrades.map(g => g.total), 0)}%</strong></p>
                  </div>
                  <div>
                    <span className="text-[9.5px] tracking-wide font-black text-[#966b3f] uppercase block">Benchmark Metrics</span>
                    <p className="font-extrabold text-slate-600 mt-0.5">Lowest Mark Score: <strong className="text-slate-700">{Math.min(...mappedGrades.map(g => g.total), 0)}%</strong></p>
                  </div>
                  <div>
                    <span className="text-[9.5px] tracking-wide font-black text-[#966b3f] uppercase block">Benchmark Metrics</span>
                    <p className="font-extrabold text-slate-600 mt-0.5">Class Average: <strong className="text-slate-700">{parseFloat((mappedGrades.reduce((sum, g) => sum + g.total, 0) / (mappedGrades.length || 1)).toFixed(1))}%</strong></p>
                  </div>
                </div>

              </div>
            )}

            {/* TAB PANELS: FAILED CANDIDATES VIEW */}
            {activeGradeTab === 'Failed' && (
              <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-widest text-red-600">Failed Candidates Intervention Board</h3>
                    <p className="text-[10.5px] text-[#aa7a41]/60 font-semibold mt-0.5">Inline highlights for candidates scoring &lt; 50%</p>
                  </div>
                  
                  <span className="text-xs font-bold text-[#b14949] bg-red-100 px-3 py-1 rounded-full px-2">
                    {failedCount} alert flags triggered
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  {mappedGrades.filter(g => g.total < 50).map(g => (
                    <div key={g.student.id} className="p-4 rounded-2xl bg-red-500/[0.03] border border-red-200/40 space-y-3">
                      <div className="flex items-center gap-3">
                        <img src={g.student.avatar} alt="Student" className="w-10 h-10 rounded-full object-cover border-2 border-red-250 animate-pulse" referrerPolicy="no-referrer" />
                        <div>
                          <h4 className="font-extrabold text-red-950">{g.student.name}</h4>
                          <p className="text-[10px] font-mono text-red-700/60 block mt-0.5">{g.student.studentId}</p>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-red-100/50 flex justify-between text-xs font-bold text-red-900">
                        <span>Total Score: {g.total}%</span>
                        <span>Grade Inferred: F</span>
                        <span className="px-2 py-0.5 rounded bg-red-101 text-[9.5px] font-black uppercase tracking-wider">
                          CRITICAL RISK
                        </span>
                      </div>

                      {/* Intervention action triggers */}
                      <div className="pt-2 flex gap-2">
                        <button
                          onClick={() => scheduleIntervention(g.student.name, 'Tutoring Assigned', 'High')}
                          className="flex-1 py-1 px-2 rounded bg-blue-50 hover:bg-blue-100/60 text-blue-600 text-[10px] font-black cursor-pointer text-center"
                        >
                          Schedule Tutoring
                        </button>
                        <button
                          onClick={() => scheduleIntervention(g.student.name, 'Dispatched Parent warning', 'Critical')}
                          className="flex-1 py-1 px-2 rounded bg-red-500/15 hover:bg-red-500/25 text-red-800 text-[10px] font-black cursor-pointer text-center"
                        >
                          Send Parental Warning
                        </button>
                      </div>
                    </div>
                  ))}

                  {mappedGrades.filter(g => g.total < 50).length === 0 && (
                    <div className="md:col-span-2 py-12 text-center text-emerald-800/60 font-semibold bg-emerald-500/5 border border-emerald-100 rounded-2xl">
                      🎉 Absolute pristine logs! All candidates are passing academic criteria.
                    </div>
                  )}
                </div>

              </div>
            )}

            {activeGradeTab === 'Attendance' && (
              <AttendanceTracking students={students} onAttendanceEdit={handleAttendanceEdit} />
            )}

          </div>
        )}

      </main>

      {/* MODAL 1: EDITABLE PROFILE CONFIGURATION */}
      <AnimatePresence>
        {showProfileModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#231a10]/60 backdrop-blur-md">
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[2.2rem] max-w-md w-full p-6 sm:p-7 shadow-2xl relative border border-slate-200"
            >
              
              <div className="flex justify-between items-start pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <Sliders className="w-5 h-5 text-blue-600 animate-pulse" />
                  <div>
                    <h3 className="font-extrabold text-[#5c3e1e] uppercase tracking-wider">Configure Instructor Profile</h3>
                    <p className="text-[10px] text-slate-500/60 font-semibold">Changes reflect instantly over Edutrack nodes</p>
                  </div>
                </div>
                
                <button 
                  onClick={() => setShowProfileModal(false)}
                  className="p-1 rounded-full text-slate-500 hover:bg-blue-50/70 cursor-pointer text-xs"
                >
                  ✕
                </button>
              </div>

              {profileMsg && (
                <div className="mt-4 p-2 rounded-xl bg-emerald-500/10 text-emerald-800 text-[11px] font-bold flex items-center gap-1.5 animate-bounce">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>{profileMsg}</span>
                </div>
              )}

              {/* Edit form */}
              <form onSubmit={handleProfileSave} className="mt-5 space-y-4 text-xs">
                
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={profName || ''}
                    onChange={(e) => setProfName(e.target.value)}
                    className="w-full bg-[#fcf8f2] border border-slate-200 rounded-full py-2 px-4 font-semibold focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500"
                    placeholder="Instructor Full Name"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">Academy Email</label>
                  <input
                    type="email"
                    required
                    value={profEmail || ''}
                    onChange={(e) => setProfEmail(e.target.value)}
                    className="w-full bg-[#fcf8f2] border border-slate-200 rounded-full py-2 px-4 font-semibold focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500"
                    placeholder="name@edutrack.com"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 uppercase mb-1">Employee Staff ID</label>
                    <input
                      type="text"
                      required
                      value={profId || ''}
                      onChange={(e) => setProfId(e.target.value)}
                      className="w-full bg-[#fcf8f2] border border-slate-200 rounded-full py-2 px-4 font-semibold focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 font-mono"
                      placeholder="AK/STAFF/M102"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 uppercase mb-1">Division Subject</label>
                    <input
                      type="text"
                      required
                      value={profDept || ''}
                      onChange={(e) => setProfDept(e.target.value)}
                      className="w-full bg-[#fcf8f2] border border-slate-200 rounded-full py-2 px-4 font-semibold focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Change Avatar Click Action Row */}
                <div className="flex items-center gap-4 p-3 bg-blue-50/50 rounded-2xl border border-blue-400/10">
                  <div 
                    onClick={() => setIsAvatarModalOpen(true)}
                    className="relative w-14 h-14 rounded-full border-2 border-blue-500/30 hover:border-blue-500 overflow-hidden shrink-0 cursor-pointer group select-none transition-all"
                    title="Click to take photo with camera or upload image"
                  >
                    <img src={profAvatar} alt="Instructor Pic" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-black/45 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Camera className="w-4 h-4 text-white" />
                    </div>
                  </div>

                  <div className="flex-1">
                    <label className="block font-bold text-slate-700 uppercase mb-1 text-[11px]">Avatar Profile Picture</label>
                    <button
                      type="button"
                      onClick={() => setIsAvatarModalOpen(true)}
                      className="py-1.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-[10px] font-bold text-blue-600 flex items-center gap-1.5 cursor-pointer hover:underline transition-all"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      Capture Photo / Pick Image
                    </button>
                  </div>
                </div>

                {/* Teacher Avatar camera modal popup */}
                <AvatarCameraModal
                  isOpen={isAvatarModalOpen}
                  onClose={() => setIsAvatarModalOpen(false)}
                  onSave={(newPic) => {
                    setProfAvatar(newPic);
                    setIsAvatarModalOpen(false);
                  }}
                  currentAvatar={profAvatar}
                />

                {/* Submitting buttons */}
                <div className="flex justify-end gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowProfileModal(false)}
                    className="py-2.5 px-4.5 rounded-full border border-slate-200 hover:bg-slate-50 font-bold"
                  >
                    Discard Edits
                  </button>
                  <button
                    type="submit"
                    className="py-2.5 px-5.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold shadow shadow-blue-800/10 cursor-pointer"
                  >
                    Consolidate Ledger
                  </button>
                </div>

              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: ADD NOTE / VIEW PREVIOUS COMMENTS FOR STUDENT */}
      <AnimatePresence>
        {selectedStudentForNote && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#231a10]/60 backdrop-blur-md">
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[2rem] max-w-lg w-full p-6 shadow-2xl relative border border-slate-200"
            >
              
              <div className="flex justify-between items-start pb-4 border-b border-slate-200">
                <div className="flex items-center gap-3">
                  <img src={selectedStudentForNote.avatar} alt="Student" className="w-10 h-10 rounded-full object-cover border border-slate-200" referrerPolicy="no-referrer" />
                  <div>
                    <h3 className="font-extrabold text-[#5c3e1e]">{selectedStudentForNote.name}</h3>
                    <span className="text-[10px] text-blue-600 font-mono block mt-0.5">Advisory Case Notes: {selectedStudentForNote.studentId}</span>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedStudentForNote(null)}
                  className="p-1 rounded-full text-slate-500 hover:bg-blue-50/70 cursor-pointer text-xs"
                >
                  ✕
                </button>
              </div>

              {noteSuccess && (
                <div className="mt-4 p-2 rounded-xl bg-emerald-500/10 text-emerald-800 text-[11px] font-bold flex items-center gap-1 animate-pulse">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{noteSuccess}</span>
                </div>
              )}

              {/* Feed lists of previous comments */}
              <div className="mt-4 space-y-2.5 max-h-[160px] overflow-y-auto pr-1">
                <span className="text-[9px] font-black uppercase text-blue-700/60 block">Previous counselling notes log:</span>
                {(studentComments[selectedStudentForNote.id] || []).map((cmt, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-50/50 border border-slate-200/50 text-xs font-semibold leading-relaxed">
                    <p className="text-[#5c4021]">{cmt}</p>
                    <span className="text-[8.5px] text-[#aa7a41] block mt-1">Logged by {teacher.name} • Faculty Advisor</span>
                  </div>
                ))}
                {(!studentComments[selectedStudentForNote.id] || studentComments[selectedStudentForNote.id].length === 0) && (
                  <p className="text-center py-4 text-[#aa7a41]/50 text-xs font-semibold">No notes logged for this student yet.</p>
                )}
              </div>

              {/* Input for adding new notes */}
              <form onSubmit={handleAddNoteFeedback} className="mt-4 space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Add warning feedback or counseling note:</label>
                  <textarea
                    rows={2}
                    required
                    value={newCommentText}
                    onChange={(e) => setNewCommentText(e.target.value)}
                    placeholder="Provide recommendations or study notes..."
                    className="w-full bg-[#fcf8f2] border border-slate-200 rounded-xl p-3 text-xs font-semibold focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedStudentForNote(null)}
                    className="py-1.5 px-4 rounded-full border border-slate-200 text-xs font-bold hover:bg-slate-50"
                  >
                    Close Drawer
                  </button>
                  <button
                    type="submit"
                    className="py-1.5 px-4.5 rounded-full bg-blue-600 text-white text-xs font-extrabold hover:bg-blue-700 transition-all cursor-pointer shadow-sm shadow-blue-800/10"
                  >
                    Pin feedback
                  </button>
                </div>
              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 3: COMPREHENSIVE STUDENT ACADEMIC PROFILE & TRANSCRIPT EDIT SHEET */}
      <AnimatePresence>
        {selectedStudentProfile && (() => {
          const reactiveStudent = students.find(s => s.id === selectedStudentProfile.id) || selectedStudentProfile;
          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#18110b]/70 backdrop-blur-md overflow-y-auto">
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 15 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 15 }}
                className="bg-white rounded-[2.5rem] max-w-4xl w-full p-6 md:p-8 shadow-2xl relative border border-slate-200/80 my-8 overflow-hidden"
              >
                {/* Header background accents */}
                <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-r from-amber-500/10 via-amber-600/[0.03] to-[#e4eff9]/30 pointer-events-none" />

                {/* Dismiss X button */}
                <button 
                  onClick={() => setSelectedStudentProfile(null)}
                  className="absolute top-5 right-5 z-20 w-8 h-8 rounded-full bg-slate-100/80 hover:bg-red-50 hover:text-red-650 flex items-center justify-center text-slate-500 cursor-pointer font-bold text-xs transition-all shadow-sm border border-slate-200"
                >
                  ✕
                </button>

                {/* Modular Side-By-Side layout */}
                <div className="relative grid grid-cols-1 md:grid-cols-12 gap-8 pt-2">
                  
                  {/* LEFT PANEL: Student Bio Card (md:col-span-4) */}
                  <div className="md:col-span-4 space-y-6">
                    
                    <div className="text-center p-5 rounded-3xl bg-amber-50/40 border border-amber-200/30 shadow-sm relative overflow-hidden flex flex-col items-center">
                      <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full bg-amber-300/10 blur-xl" />
                      
                      {/* Avatar */}
                      <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-amber-200 shadow bg-white p-1 mb-3">
                        {reactiveStudent.avatar ? (
                          <img 
                            src={reactiveStudent.avatar} 
                            alt={reactiveStudent.name} 
                            className="w-full h-full object-cover rounded-full" 
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-full rounded-full bg-amber-500/10 text-[#7c4d1d] flex items-center justify-center text-3xl font-black font-display uppercase">
                            {reactiveStudent.name.substring(0, 1)}
                          </div>
                        )}
                      </div>

                      {/* Info */}
                      <h3 className="font-extrabold text-slate-800 text-lg tracking-tight leading-tight">{reactiveStudent.name}</h3>
                      <p className="text-xs font-mono font-bold text-slate-500 mt-1">{reactiveStudent.studentId}</p>

                      <div className="mt-4 flex flex-wrap gap-1.5 justify-center">
                        <span className="px-2.5 py-1 text-[9.5px] font-black uppercase tracking-wider bg-amber-500/10 text-[#a36214] rounded-lg border border-amber-300/25">
                          Grade {reactiveStudent.academicLevel}
                        </span>
                        <span className="px-2.5 py-1 text-[9.5px] font-black uppercase tracking-wider bg-blue-500/10 text-blue-700 rounded-lg border border-blue-300/25">
                          Semester {reactiveStudent.semester}
                        </span>
                      </div>
                    </div>

                    {/* Personal & Parent Contact details block */}
                    <div className="p-5 rounded-3xl bg-[#fdfaf5] border border-slate-205/60 space-y-3 shadow-sm">
                      <h4 className="text-[10px] font-black tracking-widest uppercase text-[#7c4d1d]">Guardian Relations</h4>
                      
                      <div className="space-y-2 text-xs font-semibold leading-relaxed">
                        <div>
                          <span className="text-[9.5px] text-slate-400 font-bold block uppercase">Parent / Guardian Name</span>
                          <span className="text-slate-800 font-extrabold">{reactiveStudent.parentName || "Nesru Abdulwahid"}</span>
                        </div>
                        
                        <div>
                          <span className="text-[9.5px] text-slate-400 font-bold block uppercase">Emergency Phone Contact</span>
                          <span className="text-slate-800 font-extrabold flex items-center gap-1.5 mt-0.5 font-mono">
                            📞 {reactiveStudent.parentContact || "+251-911-345-678"}
                          </span>
                        </div>

                        <div>
                          <span className="text-[9.5px] text-slate-400 font-bold block uppercase">Inbound Email Address</span>
                          <span className="text-slate-700 block truncate font-mono text-[11px]">{reactiveStudent.email}</span>
                        </div>

                        <div className="pt-2 border-t border-slate-100">
                          <span className="text-[9.5px] text-slate-400 font-bold block uppercase">Academic Admission Date</span>
                          <span className="text-slate-600 font-bold font-mono text-[11px]">{reactiveStudent.joinedDate || "Sept 12, 2024"}</span>
                        </div>
                      </div>
                    </div>

                    {/* Interactive Attendance tracker card */}
                    <div className="p-5 rounded-3xl bg-[#f5f9fc] border border-blue-200/50 space-y-3 shadow-sm">
                      <div className="flex justify-between items-center">
                        <h4 className="text-[10px] font-black tracking-widest uppercase text-blue-800">Attendance Register</h4>
                        <span className={`px-2 py-0.5 rounded text-[8.5px] font-black uppercase ${
                          (reactiveStudent.attendance ?? 95.0) >= 90 
                            ? 'bg-emerald-100 text-emerald-850' 
                            : (reactiveStudent.attendance ?? 95.0) >= 85 
                            ? 'bg-amber-100 text-[#8d5415]' 
                            : 'bg-red-105 bg-red-100 text-red-700'
                        }`}>
                          {(reactiveStudent.attendance ?? 95.0) >= 85 ? 'Satisfactory' : 'Warning'}
                        </span>
                      </div>

                      <div className="space-y-2.5">
                        <div className="flex justify-between items-end">
                          <span className="text-[9.5px] text-slate-500 font-bold uppercase">Live Ratio</span>
                          <span className="text-base font-black font-mono text-slate-800">
                            {(reactiveStudent.attendance ?? 95.0).toFixed(1)}%
                          </span>
                        </div>

                        {/* Attendance Progress bar inside modal */}
                        <div className="h-2 bg-slate-200/80 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-300 ${
                              (reactiveStudent.attendance ?? 95.0) >= 90 
                                ? 'bg-emerald-500' 
                                : (reactiveStudent.attendance ?? 95.0) >= 85 
                                ? 'bg-amber-500' 
                                : 'bg-red-500'
                            }`}
                            style={{ width: `${Math.min(100, reactiveStudent.attendance ?? 95.0)}%` }}
                          />
                        </div>

                        {/* Interactive edit input range slider */}
                        <div className="space-y-1 pt-1">
                          <label className="text-[9px] font-extrabold text-blue-750 flex justify-between uppercase">
                            <span>Adjust Attendance %</span>
                          </label>
                          <div className="flex items-center gap-3">
                            <input 
                              type="range"
                              min="0"
                              max="100"
                              step="0.5"
                              value={reactiveStudent.attendance ?? 95.0}
                              onChange={(e) => handleProfileAttendanceEdit(parseFloat(e.target.value) || 0)}
                              className="w-full accent-blue-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                            />
                            <input 
                              type="number"
                              min="0"
                              max="100"
                              step="0.1"
                              value={reactiveStudent.attendance ?? 95.0}
                              onChange={(e) => handleProfileAttendanceEdit(parseFloat(e.target.value) || 0)}
                              className="w-16 bg-white border border-slate-200 rounded-lg py-1 px-1.5 text-[11px] text-center font-bold tracking-wide focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* advisory warning notice */}
                    <div className="p-4 rounded-2xl bg-amber-50/30 border border-amber-200/20 text-[10.5px] font-bold text-[#8d5415] leading-relaxed">
                      💡 <strong>Grading Authority Limit:</strong> Changes modify active marks composition. Edits save in real-time, syncing immediately with the Student Dashboard.
                    </div>

                  </div>

                  {/* RIGHT PANEL: All Registered Subjects Transcript & Mark Sheet (md:col-span-8) */}
                  <div className="md:col-span-8 space-y-5">
                    
                    <div>
                      <h2 className="text-xs font-black tracking-widest text-[#7c4d1d] uppercase font-display">Academic Transcript Mark Sheet</h2>
                      <p className="text-[10.5px] text-slate-500 font-semibold">Review or update scores across different curriculum subjects.</p>
                    </div>

                    <div className="space-y-4 max-h-[440px] overflow-y-auto pr-2">
                      {Object.values(reactiveStudent.grades).map((grade: SubjectGrade) => {
                        const isTeacherCurrentSubject = grade.subjectCode === teacher.subjectCode;
                        
                        // Local score display representation
                        const displayAssignments = grade.assignments || 0; // 0-30 or 0-40
                        const displayQuizzes = grade.quizzes || 0; // 0-20
                        // Exams are stored 0-50 in DB but teacher uses 0-40
                        const displayExams = (isTeacherCurrentSubject 
                          ? Math.round((grade.exams / 50) * 40)
                          : grade.exams) || 0;

                        // Subject max limits config
                        const assignMax = isTeacherCurrentSubject ? 40 : 30;
                        const quizMax = 20;
                        const examMax = isTeacherCurrentSubject ? 40 : 50;

                        return (
                          <div 
                            key={grade.subjectCode} 
                            className={`p-5 rounded-3xl border transition-all ${
                              isTeacherCurrentSubject
                                ? 'bg-gradient-to-br from-amber-500/[0.02] to-amber-600/[0.04] border-amber-300/40 ring-1 ring-amber-400/10'
                                : 'bg-[#fafbfc] hover:bg-slate-50/50 border-slate-200/80 shadow-sm'
                            }`}
                          >
                            
                            {/* Subject Title Header */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                              <div className="flex items-center gap-2">
                                <span className={`px-2 py-1 rounded text-[10px] font-mono font-black ${
                                  isTeacherCurrentSubject 
                                    ? 'bg-amber-605 bg-amber-600 text-white' 
                                    : 'bg-slate-200 text-slate-700'
                                }`}>
                                  {grade.subjectCode}
                                </span>
                                <div>
                                  <h4 className="font-extrabold text-slate-800 text-xs md:text-sm">{grade.subjectName}</h4>
                                  <span className="text-[9.5px] text-slate-400 font-semibold">Instructor: {grade.instructorName}</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2">
                                {isTeacherCurrentSubject && (
                                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-[#a36214] font-black uppercase text-[8.5px] tracking-wider border border-amber-300/20">
                                    Your Curricular Subject
                                  </span>
                                )}
                                
                                <span className={`px-2 py-0.5 rounded text-xs font-black font-mono ${
                                  grade.gpaPoint >= 3.3 ? 'bg-emerald-50 text-emerald-800' : grade.gpaPoint >= 2.0 ? 'bg-blue-50 text-blue-800' : 'bg-red-50 text-red-750'
                                }`}>
                                  {grade.gpaPoint.toFixed(2)} GP • {grade.letterGrade}
                                </span>
                              </div>
                            </div>

                            {/* Scoring details / Editable Form Row */}
                            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
                              
                              {/* Assignment input */}
                              <div className="space-y-1">
                                <div className="flex justify-between items-center text-[10px] font-extrabold text-slate-500 tracking-tight">
                                  <span>ASSIGNMENT</span>
                                  <span>MAX {assignMax}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input 
                                    type="number"
                                    min="0"
                                    max={assignMax}
                                    value={displayAssignments}
                                    onChange={(e) => handleProfileScoreEdit(grade.subjectCode, 'assignments', parseFloat(e.target.value) || 0)}
                                    className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-xs text-center font-bold tracking-wide focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                  <span className="text-[11px] text-slate-400 font-medium font-mono">pts</span>
                                </div>
                              </div>

                              {/* Quiz Input */}
                              <div className="space-y-1">
                                <div className="flex justify-between items-center text-[10px] font-extrabold text-slate-500 tracking-tight">
                                  <span>QUIZ / TESTS</span>
                                  <span>MAX {quizMax}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input 
                                    type="number"
                                    min="0"
                                    max={quizMax}
                                    value={displayQuizzes}
                                    onChange={(e) => handleProfileScoreEdit(grade.subjectCode, 'quizzes', parseFloat(e.target.value) || 0)}
                                    className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-xs text-center font-bold tracking-wide focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                  <span className="text-[11px] text-slate-400 font-medium font-mono">pts</span>
                                </div>
                              </div>

                              {/* Exam input */}
                              <div className="space-y-1">
                                <div className="flex justify-between items-center text-[10px] font-extrabold text-[#7c4d1d] tracking-tight">
                                  <span>FINAL EXAM</span>
                                  <span>MAX {examMax}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <input 
                                    type="number"
                                    min="0"
                                    max={examMax}
                                    value={displayExams}
                                    onChange={(e) => handleProfileScoreEdit(grade.subjectCode, 'exams', parseFloat(e.target.value) || 0)}
                                    className="w-full bg-white border border-slate-200 rounded-xl py-1.5 px-2.5 text-xs text-center font-bold tracking-wide focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                  <span className="text-[11px] text-slate-400 font-medium font-mono">pts</span>
                                </div>
                              </div>

                            </div>

                            {/* Total and Progress stats indicator */}
                            <div className="mt-4.5 pt-3 border-t border-slate-100 flex items-center justify-between gap-4 text-xs font-bold font-mono">
                              <div className="flex items-center gap-1.5 text-slate-500 font-semibold text-[11px]">
                                <span>Total: {grade.totalMark}%</span>
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold leading-tight ${
                                  grade.status === 'Excellent' ? 'bg-emerald-50 text-emerald-700' : grade.status === 'Good' ? 'bg-blue-50 text-blue-700' : 'bg-red-50 text-red-700'
                                }`}>
                                  {grade.status}
                                </span>
                              </div>

                              <div className="flex items-center gap-2 text-slate-500 text-[10px] font-semibold">
                                <span className="uppercase">Progress:</span>
                                <span className="text-slate-800">{grade.progress}%</span>
                              </div>
                            </div>

                          </div>
                        );
                      })}
                    </div>

                  </div>

                </div>

                {/* Footer buttons */}
                <div className="mt-6 pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row justify-between items-center gap-3">
                  <div className="text-[10px] text-slate-500 font-extrabold flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Real-time persistence layer enabled. All active entries are saved automatically.</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedStudentProfile(null)}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-slate-800 hover:bg-slate-950 text-white text-xs font-extrabold transition-all cursor-pointer shadow-md"
                  >
                    Close Student File
                  </button>
                </div>

              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>

    </div>
  );
}
