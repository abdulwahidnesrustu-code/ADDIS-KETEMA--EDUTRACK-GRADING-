/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight } from 'lucide-react';
import crestLogo from '../assets/images/addis_ketema_logo_1780404658947.png';

interface SplashWelcomeProps {
  onComplete: () => void;
}

export default function SplashWelcome({ onComplete }: SplashWelcomeProps) {
  const text = "WELCOME TO ADDIS KETEMA EDUTRACK";
  const [typedIndex, setTypedIndex] = useState(0);

  // Auto-typing text effect
  useEffect(() => {
    if (typedIndex < text.length) {
      const timeout = setTimeout(() => {
        setTypedIndex(typedIndex + 1);
      }, 70);
      return () => clearTimeout(timeout);
    } else {
      // Auto redirect to login screen 5 seconds after text typing completes
      const timeout = setTimeout(() => {
        onComplete();
      }, 5000);
      return () => clearTimeout(timeout);
    }
  }, [typedIndex, onComplete]);

  // Floating particles list
  const particles = Array.from({ length: 24 }).map((_, i) => ({
    id: i,
    size: Math.random() * 6 + 2,
    x: Math.random() * 100 - 50,
    y: Math.random() * 100 - 50,
    delay: Math.random() * 2,
    duration: Math.random() * 3 + 2,
  }));

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-[#f9f3e8] via-[#fffaf0] to-[#fef7e0]">
      {/* Dynamic flowing decorative orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-gradient-to-br from-[#ffd89b] to-[#f9c45a] blur-[90px] opacity-25 animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[550px] h-[550px] rounded-full bg-gradient-to-br from-[#b6e2f5] to-[#a0cfee] blur-[90px] opacity-20" />

      {/* Centerpiece Container with entrance transition */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="relative flex flex-col items-center justify-center text-center z-10 px-4"
      >
        {/* Floating particles around logo */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          {particles.map((p) => (
            <motion.div
              key={p.id}
              className="absolute bg-gradient-to-br from-amber-400 to-yellow-600 rounded-full"
              style={{
                width: p.size,
                height: p.size,
              }}
              initial={{ opacity: 0, x: 0, y: 0 }}
              animate={{ 
                opacity: [0, 0.7, 0],
                x: p.x * 4,
                y: p.y * 4,
              }}
              transition={{
                duration: p.duration,
                repeat: Infinity,
                delay: p.delay,
                ease: 'easeInOut'
              }}
            />
          ))}
        </div>

        {/* Glow Halo Layer */}
        <div className="absolute top-[-20px] left-[-20px] w-[200px] h-[200px] rounded-full bg-amber-400/10 blur-[40px] animate-pulse pointer-events-none" />

        {/* Logo Container and Halo Ring */}
        <div className="relative w-48 h-48 flex items-center justify-center">
          {/* Rotating Golden Halo ring */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
            className="absolute inset-0 rounded-full border-2 border-dashed border-amber-500/30 p-1"
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 16, repeat: Infinity, ease: 'linear' }}
            className="absolute inset-[4px] rounded-full border border-double border-amber-300/40"
          />

          {/* Actual Crest Logo image inside - sized elegantly */}
          <motion.div 
            initial={{ scale: 0.5, rotate: -15 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.3, duration: 1, type: 'spring' }}
            className="w-36 h-36 rounded-full overflow-hidden bg-white shadow-lg border-2 border-[#f5ebd5] flex items-center justify-center relative group z-10"
          >
            <img 
              src={crestLogo} 
              alt="Addis Ketema EduTrack Crest" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // Fallback elegant SVG logo if image loading experiences issues
                const target = e.currentTarget;
                target.style.display = 'none';
                const parent = target.parentElement;
                if (parent) {
                  const fallback = document.createElement('div');
                  fallback.className = 'w-full h-full bg-gradient-to-br from-amber-500 to-amber-700 flex flex-col items-center justify-center text-white p-2 text-center font-bold font-display text-[11px] leading-tight';
                  fallback.innerHTML = `
                    <svg class="w-8 h-8 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
                      <path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"/>
                    </svg>
                    <span>AKPS</span>
                  `;
                  parent.appendChild(fallback);
                }
              }}
            />
          </motion.div>
        </div>

        {/* Sparkling Badge */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-6 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/10 to-amber-600/10 border border-amber-300/30 text-[11px] tracking-widest text-[#b37b2e] font-black uppercase font-display shadow-sm"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          Addis Ketema Prep School • EduTrack
        </motion.div>

        {/* Staggered Typing Heading */}
        <div className="mt-4 min-h-[44px]">
          <h1 className="text-2xl md:text-3xl font-black tracking-tight font-display bg-gradient-to-r from-amber-800 via-amber-950 to-[#5a3106] bg-clip-text text-transparent max-w-lg leading-snug">
            {text.slice(0, typedIndex)}
            {typedIndex < text.length && (
              <span className="inline-block w-2 h-6 ml-1 bg-amber-500 animate-pulse align-middle" />
            )}
          </h1>
        </div>

        {/* Dynamic loading progress bar to represent professional transitions */}
        <div className="w-48 h-1.5 bg-amber-200/30 rounded-full mt-6 overflow-hidden border border-amber-200/20 backdrop-blur-sm">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${(typedIndex / text.length) * 100}%` }}
            transition={{ ease: "easeInOut" }}
            className="h-full bg-gradient-to-r from-amber-500 to-amber-600 shadow-[0_0_8px_rgba(245,158,11,0.5)] rounded-full"
          />
        </div>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: typedIndex >= text.length ? 0.9 : 0.3 }}
          transition={{ duration: 0.5 }}
          className="mt-4 text-xs md:text-sm text-[#7e582e] font-semibold tracking-wide max-w-sm"
        >
          {typedIndex >= text.length 
            ? "Syncing institutional score systems..." 
            : "Initializing database assets..."}
        </motion.p>

        {/* Skip button for beautiful fluid developer and user-testing experience */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          onClick={onComplete}
          className="mt-10 group inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/70 hover:bg-amber-50/90 border border-amber-200/40 shadow-sm text-xs font-bold text-[#b97f3a] tracking-wide transition-all hover:scale-105 active:scale-95 cursor-pointer"
        >
          Enter Academy Track
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </motion.button>
      </motion.div>
    </div>
  );
}
