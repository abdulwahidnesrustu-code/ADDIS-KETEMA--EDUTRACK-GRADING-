/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  BookOpen, 
  GraduationCap, 
  Users, 
  History, 
  Settings, 
  FileSpreadsheet, 
  Bell, 
  Activity, 
  Search, 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Edit2, 
  Download, 
  Printer, 
  CheckCircle,
  AlertTriangle,
  UserCheck,
  TrendingUp,
  Cpu,
  Calendar,
  Layers,
  Sparkles,
  Lock,
  ChevronRight,
  LogOut,
  Clock,
  Laptop,
  CheckCircle2,
  X,
  Volume2,
  Sun,
  Moon,
  Camera
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Student, Teacher, SystemLog, CourseProgram, SubjectDefinition, Announcement, AppNotification, SubjectGrade } from '../types';
import AvatarCameraModal from './AvatarCameraModal';
import { 
  getStoredStudents, 
  saveStoredStudents, 
  getStoredTeachers, 
  saveStoredTeachers,
  getStoredLogs,
  addStoredLog,
  getStoredPrograms,
  saveStoredPrograms,
  getStoredSubjects,
  saveStoredSubjects,
  getStoredAnnouncements,
  saveStoredAnnouncements,
  getStoredNotifications,
  saveStoredNotifications,
  createDefaultGradesForAllSubjects,
  calculateGradeDetails
} from '../data/mockData';

import crestLogo from '../assets/images/addis_ketema_logo_1780404658947.png';

interface AdminDashboardProps {
  admin: any;
  onLogout: () => void;
  onProfileUpdate: (updatedAdmin: any) => void;
}

export default function AdminDashboard({ admin, onLogout, onProfileUpdate }: AdminDashboardProps) {
  const [isDarkTheme, setIsDarkTheme] = useState(() => localStorage.getItem('ak_theme_dark') === 'true');

  useEffect(() => {
    localStorage.setItem('ak_theme_dark', isDarkTheme ? 'true' : 'false');
  }, [isDarkTheme]);

  // Navigation Workspaces
  const [activeTab, setActiveTab] = useState<'Dashboard' | 'Courses' | 'Subjects' | 'Students' | 'Analytics' | 'Reports' | 'Settings' | 'Notifications'>('Dashboard');
  
  // Storage reactivity
  const [students, setStudents] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [programs, setPrograms] = useState<CourseProgram[]>([]);
  const [subjects, setSubjects] = useState<SubjectDefinition[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Dropdown / Filters
  const [deptFilter, setDeptFilter] = useState('All');
  const [academicYear, setAcademicYear] = useState('2025-2026');
  const [semester, setSemester] = useState('Semester II');

  // Admin Profile Settings states
  const [adminName, setAdminName] = useState(admin.name);
  const [adminEmail, setAdminEmail] = useState(admin.email);
  const [adminTitle, setAdminTitle] = useState(admin.title || 'Dean / Registrar System Principal');
  const [adminAvatar, setAdminAvatar] = useState(admin.avatar || 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200&h=200');
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);

  // Unified Modal state to optimize token usage
  const [modal, setModal] = useState<{
    isOpen: boolean;
    type: 'addCourse' | 'editCourse' | 'addSubject' | 'editSubject' | 'addStudent' | 'editStudent' | 'addTeacher' | 'editTeacher' | 'addAnnouncement' | 'resetPassword' | 'viewProfile';
    data?: any;
  }>({ isOpen: false, type: 'addCourse' });

  // Fields for forms (reusable modal states)
  const [formData, setFormData] = useState<any>({});
  const [alertMessage, setAlertMessage] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);

  // Load backend systems
  const loadSystemData = () => {
    setStudents(getStoredStudents());
    setTeachers(getStoredTeachers());
    setPrograms(getStoredPrograms());
    setSubjects(getStoredSubjects());
    setAnnouncements(getStoredAnnouncements());
    setSystemLogs(getStoredLogs());
    setNotifications(getStoredNotifications());
  };

  useEffect(() => {
    loadSystemData();
    const handleSync = () => {
      loadSystemData();
    };
    window.addEventListener('storage', handleSync);
    window.addEventListener('localDataUpdated', handleSync);
    window.addEventListener('ak_db_updated', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('localDataUpdated', handleSync);
      window.removeEventListener('ak_db_updated', handleSync);
    };
  }, []);

  // Display alert feedback
  const triggerAlert = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setAlertMessage({ type, text });
    setTimeout(() => setAlertMessage(null), 3000);
  };

  const handleAdminProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminName || !adminEmail) {
      triggerAlert("Please fill in Admin Name and Email.", "error");
      return;
    }
    const updated = {
      ...admin,
      name: adminName,
      email: adminEmail,
      title: adminTitle,
      avatar: adminAvatar
    };
    onProfileUpdate(updated);
    addStoredLog(adminName, "Modified secure administrator profile details", "SYSTEM");
    triggerAlert("Administrator credentials updated and locked successfully.", "success");
  };

  // -------------------------------------------------------------
  // CALCULATED METRICS
  // -------------------------------------------------------------
  const totalStudentsCount = students.length;
  const totalSubjectsCount = subjects.length;
  const totalProgramsCount = programs.length;
  const totalTeachersCount = teachers.length;

  // Compute overall institutional GPA & Pass Rate
  const allGrades = students.flatMap(s => Object.values(s.grades) as any[]);
  const institutionalAverageGPA = allGrades.length > 0 
    ? parseFloat((allGrades.reduce((sum, g) => sum + g.gpaPoint, 0) / allGrades.length).toFixed(2))
    : 0.0;

  const passedStudents = students.filter(s => {
    const studentGrades = Object.values(s.grades) as any[];
    if (studentGrades.length === 0) return true;
    const avgScore = studentGrades.reduce((sum, g) => sum + g.totalMark, 0) / studentGrades.length;
    return avgScore >= 50; // passing threshold
  });
  const institutionalPassRate = students.length > 0
    ? parseFloat(((passedStudents.length / students.length) * 100).toFixed(1))
    : 0.0;

  const totalDepartmentsCount = Array.from(new Set(programs.map(p => p.department))).length;
  
  // Graduation readiness threshold: Senior GPA >= 2.0
  const seniorAcademyStudents = students.filter(s => s.academicLevel.includes('Grade 12'));
  const readySeniorsCount = seniorAcademyStudents.filter(s => {
    const gradesVal = Object.values(s.grades) as any[];
    if (gradesVal.length === 0) return false;
    const gpa = gradesVal.reduce((sum, g) => sum + g.gpaPoint, 0) / gradesVal.length;
    return gpa >= 2.0;
  }).length;
  const graduationReadinessPercent = seniorAcademyStudents.length > 0
    ? Math.round((readySeniorsCount / seniorAcademyStudents.length) * 100)
    : 85;

  // Department Badges Styling helper according to Section 1
  const getDeptBadgeStyle = (dept: string) => {
    const d = dept.toLowerCase();
    if (d.includes('biology')) return 'bg-gray-100 text-gray-800 border-gray-300';
    if (d.includes('chemistry')) return 'bg-yellow-150 text-slate-700 border-amber-300';
    if (d.includes('physics')) return 'bg-blue-100 text-blue-800 border-blue-300';
    if (d.includes('agriculture')) return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    if (d.includes('math')) return 'bg-purple-100 text-purple-800 border-purple-300';
    if (d.includes('english')) return 'bg-red-100 text-red-800 border-red-300';
    if (d.includes('it') || d.includes('inform')) return 'bg-indigo-100 text-indigo-800 border-indigo-300';
    if (d.includes('web')) return 'bg-orange-100 text-slate-700 border-amber-300';
    return 'bg-amber-100 text-slate-600 border-slate-200';
  };

  const gpaRanges = [
    { name: '<2.0', count: 0 },
    { name: '2.0-2.5', count: 0 },
    { name: '2.5-3.0', count: 0 },
    { name: '3.0-3.5', count: 0 },
    { name: '3.5-4.0', count: 0 },
  ];
  students.forEach(s => {
    const grades = Object.values(s.grades) as any[];
    const gpa = grades.length > 0 ? grades.reduce((sum, g) => sum + g.gpaPoint, 0) / grades.length : 0.0;
    if (gpa < 2.0) gpaRanges[0].count++;
    else if (gpa < 2.5) gpaRanges[1].count++;
    else if (gpa < 3.0) gpaRanges[2].count++;
    else if (gpa < 3.5) gpaRanges[3].count++;
    else gpaRanges[4].count++;
  });

  // -------------------------------------------------------------
  // CORE FUNCTIONS: CRUD OPERATIONS
  // -------------------------------------------------------------
  const handleOpenModal = (type: typeof modal.type, initialData: any = {}) => {
    setFormData(initialData);
    setModal({ isOpen: true, type, data: initialData });
  };

  const handleCloseModal = () => {
    setModal({ isOpen: false, type: 'addCourse' });
    setFormData({});
  };

  const executeModalAction = (e: React.FormEvent) => {
    e.preventDefault();
    const actor = "Administrator (Dean Abraham)";

    switch (modal.type) {
      case 'addCourse':
      case 'editCourse': {
        const progsDb = getStoredPrograms();
        const freshId = modal.type === 'addCourse' ? 'prog-' + Date.now() : formData.id;
        const freshProg: CourseProgram = {
          id: freshId,
          name: formData.name || 'New Program Track',
          department: formData.department || 'General Science',
          subjectsCount: Number(formData.subjectsCount) || 1,
          totalCredits: Number(formData.totalCredits) || 3,
          description: formData.description || '',
          studentsCount: Number(formData.studentsCount) || 0,
          status: formData.status || 'Active'
        };

        let updated: CourseProgram[];
        if (modal.type === 'addCourse') {
          updated = [...progsDb, freshProg];
          addStoredLog(actor, `Registered academic course program: ${freshProg.name}`, freshProg.department);
          triggerAlert(`Course '${freshProg.name}' enrolled into curriculum!`);
        } else {
          updated = progsDb.map(p => p.id === freshProg.id ? freshProg : p);
          addStoredLog(actor, `Updated details for: ${freshProg.name}`, freshProg.department);
          triggerAlert(`Curriculum references updated.`);
        }
        setPrograms(updated);
        saveStoredPrograms(updated);
        break;
      }

      case 'addSubject':
      case 'editSubject': {
        const subsDb = getStoredSubjects();
        const freshCode = formData.code || 'SUB-X';
        const freshSub: SubjectDefinition = {
          id: modal.type === 'addSubject' ? 'sub-' + Date.now() : formData.id,
          name: formData.name || 'Subject Definition',
          code: freshCode.toUpperCase(),
          credits: Number(formData.credits) || 3,
          department: formData.department || 'General Science',
          semester: formData.semester || 'Semester 1',
          instructorName: formData.instructorName || 'TBD Staff',
          status: formData.status || 'Active'
        };

        let updated: SubjectDefinition[];
        if (modal.type === 'addSubject') {
          updated = [...subsDb, freshSub];
          addStoredLog(actor, `Created subject outline code: ${freshSub.code}`, freshSub.name);
          triggerAlert(`Subject outline registered successfully.`);
        } else {
          updated = subsDb.map(s => s.id === freshSub.id ? freshSub : s);
          addStoredLog(actor, `Modified outline definitions for: ${freshSub.code}`, freshSub.name);
          triggerAlert(`Subject outline edits consolidated.`);
        }
        setSubjects(updated);
        saveStoredSubjects(updated);
        
        // Dynamic stats update: Auto update subjectsCount and credits in referencing Course Program
        const currentProgs = getStoredPrograms();
        const matchedProgIdx = currentProgs.findIndex(p => p.department.toLowerCase() === freshSub.department.toLowerCase());
        if (matchedProgIdx !== -1) {
          const freshSubList = getStoredSubjects();
          const subCount = freshSubList.filter(s => s.department.toLowerCase() === freshSub.department.toLowerCase()).length;
          const creditsCount = freshSubList.filter(s => s.department.toLowerCase() === freshSub.department.toLowerCase()).reduce((sum, s) => sum + s.credits, 0);
          currentProgs[matchedProgIdx].subjectsCount = subCount;
          currentProgs[matchedProgIdx].totalCredits = creditsCount;
          setPrograms(currentProgs);
          saveStoredPrograms(currentProgs);
        }

        // Sync new subject into student records
        if (modal.type === 'addSubject') {
            const allStudents = getStoredStudents();
            const details = calculateGradeDetails(22, 15, 28, freshSub.credits);
            const updatedStudents = allStudents.map(student => ({
              ...student,
              grades: {
                ...student.grades,
                [freshSub.code]: {
                  subjectCode: freshSub.code,
                  subjectName: freshSub.name,
                  instructorName: freshSub.instructorName,
                  ...details,
                  progress: 0
                } as SubjectGrade
              }
            }));
            saveStoredStudents(updatedStudents);
        }
        break;
      }

      case 'addStudent':
      case 'editStudent': {
        const studDb = getStoredStudents();
        let freshStud: Student;
        if (modal.type === 'addStudent') {
          const freshId = 'student-' + Date.now();
          const rollId = String(Math.floor(1000 + Math.random() * 9000));
          freshStud = {
            id: freshId,
            name: formData.name || 'Unnamed Candidate',
            email: formData.email || 'student@edutrack.com',
            avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200&h=200',
            studentId: `AK/2026/0${rollId.slice(0, 3)}`,
            academicLevel: formData.academicLevel || 'Grade 12 - Senior Academy',
            semester: formData.semester || 'Grade 12, Semester 2',
            parentName: formData.parentName || 'Guardian Custodian',
            parentContact: formData.parentContact || '+251-911-00-00-00',
            joinedDate: 'May 2026',
            grades: createDefaultGradesForAllSubjects(),
            attendance: 95.0 // Default attendance % for new enrollments
          };
          const updated = [...studDb, freshStud];
          setStudents(updated);
          saveStoredStudents(updated);
          addStoredLog(actor, `Matriculated new student profile: ${freshStud.name}`, freshStud.studentId);
          triggerAlert(`Registered candidate ${freshStud.name} successfully.`);
        } else {
          const updated = studDb.map(s => s.id === formData.id ? { 
            ...s, 
            name: formData.name, 
            email: formData.email, 
            academicLevel: formData.academicLevel,
            parentName: formData.parentName,
            parentContact: formData.parentContact
          } : s);
          setStudents(updated);
          saveStoredStudents(updated);
          addStoredLog(actor, `Modified registry record file: ${formData.name}`, formData.studentId);
          triggerAlert(`Student records finalized.`);
        }
        break;
      }

      case 'addTeacher':
      case 'editTeacher': {
        const staffDb = getStoredTeachers();
        let freshStaff: Teacher;
        if (modal.type === 'addTeacher') {
          freshStaff = {
            id: 'teacher-' + Date.now(),
            name: formData.name || 'New Lecturer',
            email: formData.email || 'faculty@edutrack.com',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200',
            teacherId: `AK/STAFF/T${Math.floor(100 + Math.random() * 900)}`,
            subjectCode: formData.subjectCode || 'MAT-102',
            subjectName: formData.subjectName || 'Advanced Mathematics & Calculus',
            classes: ['Grade 12 - Senior Academy']
          };
          const updated = [...staffDb, freshStaff];
          setTeachers(updated);
          saveStoredTeachers(updated);
          addStoredLog(actor, `Hired new faculty instructor: ${freshStaff.name}`, freshStaff.subjectCode);
          triggerAlert(`Lecturer credentials consolidated.`);
        } else {
          const updated = staffDb.map(t => t.id === formData.id ? {
            ...t,
            name: formData.name,
            email: formData.email,
            subjectCode: formData.subjectCode,
            subjectName: formData.subjectName
          } : t);
          setTeachers(updated);
          saveStoredTeachers(updated);

          // Sync student grades with teacher updates
          const oldTeacher = staffDb.find(t => t.id === formData.id);
          if (oldTeacher && (oldTeacher.name !== formData.name || oldTeacher.subjectName !== formData.subjectName || oldTeacher.subjectCode !== formData.subjectCode)) {
            const allStudents = getStoredStudents();
            const updatedStudents = allStudents.map(student => {
              if (student.grades[oldTeacher.subjectCode]) {
                const newGrades = { ...student.grades };
                const gradeEntry = newGrades[oldTeacher.subjectCode];
                
                // If code changed, remove old and add new
                if (oldTeacher.subjectCode !== formData.subjectCode) {
                    delete newGrades[oldTeacher.subjectCode];
                    newGrades[formData.subjectCode] = {
                        ...gradeEntry,
                        subjectCode: formData.subjectCode,
                        subjectName: formData.subjectName,
                        instructorName: formData.name
                    };
                } else {
                    newGrades[oldTeacher.subjectCode] = {
                        ...gradeEntry,
                        subjectName: formData.subjectName,
                        instructorName: formData.name
                    };
                }
                return { ...student, grades: newGrades };
              }
              return student;
            });
            saveStoredStudents(updatedStudents);
            setStudents(updatedStudents);
          }

          addStoredLog(actor, `Altered credentials of staff file: ${formData.name}`, formData.subjectCode);
          triggerAlert(`Faculty database modernized.`);
        }
        break;
      }

      case 'addAnnouncement': {
        const list = getStoredAnnouncements();
        const freshAnn: Announcement = {
          id: 'ann-' + Date.now(),
          title: formData.title || 'System Notification',
          description: formData.description || '',
          publishDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          priority: formData.priority || 'General'
        };
        const updated = [freshAnn, ...list];
        setAnnouncements(updated);
        saveStoredAnnouncements(updated);

        // Disperse system unread notification to students and teachers
        const prevNotifs = getStoredNotifications();
        const dispNotif: AppNotification = {
          id: 'disp-' + Date.now(),
          title: `Announcement: ${freshAnn.title}`,
          message: freshAnn.description,
          type: 'announce',
          date: 'Just now',
          unread: true
        };
        saveStoredNotifications([dispNotif, ...prevNotifs]);
        addStoredLog(actor, `Published institution-wide memo: ${freshAnn.title}`, freshAnn.priority);
        triggerAlert(`Broadcasting announcement dispatch.`);
        break;
      }

      case 'resetPassword': {
        addStoredLog(actor, `Dispatched temporary authorization token for: ${formData.name}`, 'SECURITY');
        triggerAlert(`A temporary password reset link has been queued & emailed.`);
        break;
      }
    }

    loadSystemData();
    handleCloseModal();
  };

  const handleDeleteItem = (id: string, type: 'student' | 'teacher' | 'course' | 'subject' | 'announcement', title: string) => {
    if (!window.confirm(`Critical Confirmation: Are you sure you want to permanently erase: '${title}' ?`)) return;
    const actor = "Administrator (Dean Abraham)";

    if (type === 'student') {
      const updated = students.filter(s => s.id !== id);
      setStudents(updated);
      saveStoredStudents(updated);
      addStoredLog(actor, `Expelled/De-registered student record: ${title}`, 'REGISTRY');
    } else if (type === 'teacher') {
      const updated = teachers.filter(t => t.id !== id);
      setTeachers(updated);
      saveStoredTeachers(updated);
      addStoredLog(actor, `Erased teacher payroll file: ${title}`, 'FACULTY');
    } else if (type === 'course') {
      const updated = programs.filter(p => p.id !== id);
      setPrograms(updated);
      saveStoredPrograms(updated);
      addStoredLog(actor, `Extinguished program track option: ${title}`, 'CURRICULUM');
    } else if (type === 'subject') {
      const updated = subjects.filter(s => s.id !== id);
      setSubjects(updated);
      saveStoredSubjects(updated);
      addStoredLog(actor, `Retracted academic subject definition: ${title}`, 'CURRICULUM');
    } else if (type === 'announcement') {
      const updated = announcements.filter(a => a.id !== id);
      setAnnouncements(updated);
      saveStoredAnnouncements(updated);
      addStoredLog(actor, `De-archived database circular alert: ${title}`, 'ANNOUNCEMENT');
    }

    triggerAlert(`Resource safely excised from registries.`);
    loadSystemData();
  };

  // Student suspension controls
  const toggleStudentSuspension = (student: Student) => {
    const isSuspended = student.academicLevel.includes('[SUSPENDED]');
    const updatedLevel = isSuspended 
      ? student.academicLevel.replace(' [SUSPENDED]', '')
      : `${student.academicLevel} [SUSPENDED]`;
    
    const updatedDb = students.map(s => s.id === student.id ? { ...s, academicLevel: updatedLevel } : s);
    setStudents(updatedDb);
    saveStoredStudents(updatedDb);
    addStoredLog("Administrator (Dean Abraham)", `${isSuspended ? 'Reactivated' : 'Suspended'} student credentials: ${student.name}`, student.studentId);
    triggerAlert(`Student status amended.`);
    loadSystemData();
  };

  // CSV Exporter logic for Reports (Requirement #1)
  const handleExportCSV = (reportType: string) => {
    let header = "";
    let dataContent = "";
    
    if (reportType === 'gpa') {
      header = "Student Name,Student ID,Institutional Level,Semester,School GPA\n";
      dataContent = students.map(s => {
        const grades = Object.values(s.grades) as any[];
        const gpa = grades.length > 0 ? (grades.reduce((sum, g) => sum + g.gpaPoint, 0) / grades.length).toFixed(2) : "0.00";
        return `"${s.name}","${s.studentId}","${s.academicLevel}","${s.semester}",${gpa}`;
      }).join("\n");
    } else if (reportType === 'passrate') {
      header = "Subject Code,Subject Outline,Credits,Department,Inst. Semester\n";
      dataContent = subjects.map(s => `"${s.code}","${s.name}",${s.credits},"${s.department}","${s.semester}"`).join("\n");
    } else {
      header = "Primary Actor,Action Trigger,Associated Entity,Timestamp\n";
      dataContent = systemLogs.map(l => `"${l.actor}","${l.action}","${l.subject}","${l.timestamp}"`).join("\n");
    }

    const blob = new Blob([header + dataContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", `Administrative_Report_${reportType}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerAlert(`CSV compiled and downloaded!`);
  };

  // -------------------------------------------------------------
  // DYNAMIC COMPUTE FOR SUBJECT STATS
  // Calculates average GPA & Pass Rate for each subject outline dynamically
  // -------------------------------------------------------------
  const getSubjectStats = (subjectCode: string) => {
    const subjectGrades = students.flatMap(s => {
      const gr = s.grades[subjectCode];
      return gr ? [gr] : [];
    });
    
    if (subjectGrades.length === 0) return { avgGpa: 3.00, passRate: 100 };
    const avgGpa = subjectGrades.reduce((sum, g) => sum + g.gpaPoint, 0) / subjectGrades.length;
    const passed = subjectGrades.filter(g => g.totalMark >= 50).length;
    const passRate = (passed / subjectGrades.length) * 100;
    
    return {
      avgGpa: parseFloat(avgGpa.toFixed(2)),
      passRate: parseFloat(passRate.toFixed(1))
    };
  };

  // Filters candidates, courses, and subjects based on query
  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredPrograms = programs.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredSubjects = subjects.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.subjectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.subjectCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="admin-dashboard-terminal" className={`min-h-screen flex flex-col md:flex-row transition-all duration-300 ${isDarkTheme ? 'dark bg-[#0f172a] text-slate-100' : 'bg-[#f1f5f9] text-[#0f172a]'} font-sans antialiased`}>
      
      {/* LEFT SIDEBAR (Section 1) */}
      <aside className={`w-full md:w-64 shrink-0 ${isDarkTheme ? 'bg-[#1e293b]/90 border-slate-800 text-slate-200' : 'bg-white/85 border-slate-200/60 text-slate-800'} border-b md:border-b-0 md:border-r p-6 flex flex-col justify-between z-30 print:hidden md:min-h-screen md:sticky md:top-0 backdrop-blur-md`}>
        
        <div className="space-y-6">
          {/* Logo Brand Area */}
          <div className="flex flex-col items-center justify-center text-center gap-2.5 px-1 pb-5 border-b border-slate-200/40 dark:border-slate-800/80">
            <div className="w-24 h-24 rounded-2xl bg-white p-1 flex items-center justify-center border border-blue-100 shadow-md">
              <img src={crestLogo} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div>
              <h3 className="text-sm font-black text-[#2563eb] dark:text-blue-400 leading-none uppercase">ADDIS KETEMA</h3>
              <span className="text-[9px] font-extrabold text-slate-500 dark:text-slate-400 tracking-[0.2em] block mt-1 uppercase">ADMIN PORTAL</span>
            </div>
          </div>

          {/* Admin Profile Box (Interactive) */}
          <div className="relative overflow-hidden p-3.5 rounded-2xl bg-slate-50/60 border border-slate-200/60 shadow-sm space-y-3 group hover:border-blue-300 transition-all duration-300">
            <div className="flex items-center gap-3">
              <div className="relative shrink-0">
                <img 
                  src={admin.avatar || 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200&h=200'} 
                  alt={admin.name} 
                  className="w-11 h-11 rounded-full object-cover border-2 border-blue-500 shadow-md" 
                  referrerPolicy="no-referrer" 
                />
                <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-slate-800 truncate leading-tight uppercase">{admin.name}</h4>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className="text-[9px] bg-blue-600 text-white font-black px-1.5 py-0.5 rounded uppercase">ADMIN</span>
                  <span className="text-[9px] text-slate-500 font-mono font-bold tracking-widest uppercase">ID: 009</span>
                </div>
              </div>
            </div>

            <div className="absolute top-3 right-3 text-slate-400 group-hover:text-blue-600 transition-all">
              <Bell className="w-3.5 h-3.5 cursor-pointer hover:scale-110" onClick={() => setActiveTab('Notifications')} />
            </div>
          </div>

          {/* Nav Menu */}
          <nav className="space-y-1.5">
            <span className="text-[9px] uppercase tracking-widest font-black text-slate-400 block px-2">COMMAND CONSOLE</span>
            
            {[
              { id: 'Dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'Courses', label: 'Courses & Programs', icon: Layers },
              { id: 'Subjects', label: 'Subject Manager', icon: BookOpen },
              { id: 'Students', label: 'Students Directory', icon: GraduationCap },
              { id: 'Analytics', label: 'Analytics Center', icon: TrendingUp },
              { id: 'Reports', label: 'Reports & Audits', icon: FileSpreadsheet },
              { id: 'Notifications', label: 'System Alerts', icon: Bell },
              { id: 'Settings', label: 'Security & Profile', icon: Settings },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id as any); setSearchQuery(''); }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-extrabold tracking-wide transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-500/10 to-transparent border-l-4 border-blue-600 text-blue-700'
                      : 'text-slate-600 hover:bg-slate-100/60 hover:text-slate-900 cursor-pointer'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {item.id === 'Notifications' && notifications.filter(n => n.unread).length > 0 && (
                      <span className="bg-red-500 text-white font-black text-[9px] px-1.5 py-0.5 rounded-full select-none">
                        {notifications.filter(n => n.unread).length}
                      </span>
                    )}
                    <ChevronRight className={`w-3.5 h-3.5 transition-all ${isActive ? 'text-blue-600 opacity-100' : 'text-slate-400 opacity-45'}`} />
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer actions */}
        <div className="pt-6 border-t border-slate-200/60 space-y-4">
          <div className="text-[9px] text-slate-500/60 font-bold px-1 space-y-0.5">
            <span className="block font-mono">Academic Portal v2026.1</span>
            <span className="block">Secure Admin Command Panel</span>
          </div>

          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-black text-red-600 hover:bg-red-50 hover:text-red-700 border border-red-200 rounded-xl transition-all cursor-pointer hover:scale-[1.02]"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Terminal</span>
          </button>
        </div>
      </aside>

      {/* MAIN SCREEN */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto space-y-6 print:p-0 print:bg-white print:text-black">
        
        {/* TOP HEADER SECTION (Section 2) */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-5 pb-5 border-b border-slate-200 print:hidden relative">
          
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[9.5px] tracking-widest font-black uppercase text-slate-600">CENTRAL INTELLIGENCE COMMAND</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-slate-800 mt-1">Dean Portal: {activeTab}</h1>
            <p className="text-xs text-slate-600/80 font-bold">
              Academic Term: <span className="text-blue-600 font-black">{academicYear} ({semester})</span> • Last Auth: <span className="text-slate-800">Today 15:40 UTC</span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Dark Theme toggle */}
            <button
              onClick={() => setIsDarkTheme(!isDarkTheme)}
              className="p-1.5 rounded-full hover:bg-blue-500/10 cursor-pointer text-blue-600 dark:text-blue-450 bg-white/75 dark:bg-[#1e293b]/80 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-center w-9 h-9"
              title="Toggle Dark Mode"
            >
              {isDarkTheme ? <Sun className="w-4 h-4 text-amber-500 animate-spin-halo" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            {/* Global Search Bar */}
            <div className="relative w-full sm:w-60">
              <Search className="w-4 h-4 absolute left-3.5 top-2.5 text-slate-700/40" />
              <input
                type="text"
                placeholder="Search index registries..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl py-2 pl-9 pr-4 text-xs font-medium focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>

            {/* Quick selectors */}
            <select 
              value={semester} 
              onChange={(e) => setSemester(e.target.value)}
              className="bg-white border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-extrabold focus:outline-none"
            >
              <option value="Semester I">Semester I</option>
              <option value="Semester II">Semester II</option>
            </select>

            <div className="flex items-center justify-center p-2 rounded-xl bg-blue-50 text-slate-800 border border-slate-200 cursor-pointer hover:bg-slate-500/20 shadow-sm" title="System Operational">
              <Laptop className="w-4 h-4" />
              <span className="text-[9px] font-black px-1">LOCAL</span>
            </div>
          </div>

        </header>

        {/* FEEDBACK BANNER */}
        {alertMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }} 
            exit={{ opacity: 0 }} 
            className={`p-3.5 rounded-2xl flex items-center gap-3 border text-xs font-bold leading-none shadow-sm ${
              alertMessage.type === 'success' ? 'bg-emerald-50 border-emerald-250 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{alertMessage.text}</span>
          </motion.div>
        )}

        {/* =========================================================
            WORKSPACE WORKPLACES
            ========================================================= */}
        <AnimatePresence mode="wait">
          
          {/* TAB 1: EXECUTIVE DASHBOARD */}
          {activeTab === 'Dashboard' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              
              {/* PRIMARY KPI CARDS GRID (Section 1 + Section 2) */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                
                {/* 1. Total Enrolled Students (Dark slate gradient) */}
                <div className="p-5 rounded-[2rem] bg-gradient-to-tr from-slate-900 to-slate-800 text-white overflow-hidden shadow-md relative group hover:-translate-y-0.5 transition-all">
                  <div className="absolute top-4 right-4 text-blue-500/20 group-hover:scale-110 transition-transform">
                    <GraduationCap className="w-12 h-12" />
                  </div>
                  <span className="text-[10px] tracking-wider uppercase font-black text-amber-400">Total Enrolled</span>
                  <h3 className="text-3.5xl font-black mt-1 font-mono tracking-tight">{totalStudentsCount} Students</h3>
                  <p className="text-[10.5px] text-amber-100/60 mt-2">Active students in this term.</p>
                </div>

                {/* 2. Total active subjects (Blue gradient) */}
                <div className="p-5 rounded-[2rem] bg-gradient-to-tr from-sky-700 to-indigo-900 text-white overflow-hidden shadow-md relative group hover:-translate-y-0.5 transition-all">
                  <div className="absolute top-4 right-4 text-sky-300/20 group-hover:scale-110 transition-transform">
                    <BookOpen className="w-12 h-12" />
                  </div>
                  <span className="text-[10px] tracking-wider uppercase font-black text-sky-300">Total Subjects</span>
                  <h3 className="text-3.5xl font-black mt-1 font-mono tracking-tight">{totalSubjectsCount} Subjects</h3>
                  <p className="text-[10.5px] text-sky-100/60 mt-2">Active curriculum structures.</p>
                </div>

                {/* 3. GPA Rating (Peach gradient) */}
                <div className="p-5 rounded-[2rem] bg-gradient-to-tr from-amber-500 to-orange-500 text-[#fffbf2] overflow-hidden shadow-md relative group hover:-translate-y-0.5 transition-all">
                  <div className="absolute top-4 right-4 text-orange-200/20 group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-12 h-12" />
                  </div>
                  <span className="text-[10px] tracking-wider uppercase font-black text-amber-100">Average School GPA</span>
                  <h3 className="text-3.5xl font-black mt-1 font-mono tracking-tight">{institutionalAverageGPA} GP</h3>
                  <p className="text-[10.5px] text-orange-100/85 mt-2">Across overall student assessment files.</p>
                </div>

                {/* 4. Institutional Pass rate (Green gradient) */}
                <div className="p-5 rounded-[2rem] bg-gradient-to-tr from-emerald-600 to-teal-800 text-white overflow-hidden shadow-md relative group hover:-translate-y-0.5 transition-all">
                  <div className="absolute top-4 right-4 text-emerald-200/20 group-hover:scale-110 transition-transform">
                    <CheckCircle className="w-12 h-12" />
                  </div>
                  <span className="text-[10px] tracking-wider uppercase font-black text-emerald-250">Passing Rate</span>
                  <h3 className="text-3.5xl font-black mt-1 font-mono tracking-tight">{institutionalPassRate}%</h3>
                  <p className="text-[10.5px] text-emerald-200/80 mt-2">Passing rate over 50% threshold.</p>
                </div>

              </div>

              {/* AUXILIARY HISTOGRAM KPI CARDS (Section 2) */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pb-2">
                <div className="p-4 bg-white rounded-2xl border border-amber-900/5 shadow-sm text-center">
                  <span className="text-[9px] uppercase tracking-wide text-slate-600/60 font-black block">Curriculum Programs</span>
                  <span className="text-xl font-mono font-black text-slate-800 mt-1 block">{totalProgramsCount} Tracks</span>
                </div>
                <div className="p-4 bg-white rounded-2xl border border-amber-900/5 shadow-sm text-center">
                  <span className="text-[9px] uppercase tracking-wide text-slate-600/60 font-black block">Faculties Staff</span>
                  <span className="text-xl font-mono font-black text-slate-800 mt-1 block">{totalTeachersCount} Lecturers</span>
                </div>
                <div className="p-4 bg-white rounded-2xl border border-amber-900/5 shadow-sm text-center">
                  <span className="text-[9px] uppercase tracking-wide text-slate-600/60 font-black block">Departments</span>
                  <span className="text-xl font-mono font-black text-slate-800 mt-1 block">{totalDepartmentsCount} Branches</span>
                </div>
                <div className="p-4 bg-white rounded-2xl border border-amber-900/5 shadow-sm text-center">
                  <span className="text-[9px] uppercase tracking-wide text-[#b54a10]/80 font-black block">Senior Graduation Ready</span>
                  <span className="text-xl font-mono font-black text-emerald-700 mt-1 block">{graduationReadinessPercent}% Ready</span>
                </div>
              </div>

              {/* REAL-TIME SYSTEM HEALTH MONITORING ROW (Section 2) */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                
                <div className="flex justify-between items-center pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-600 animate-pulse" />
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">System Health Monitor Core</h4>
                      <p className="text-[10px] text-slate-600/60 font-bold">Virtual machines and datastore operational response status</p>
                    </div>
                  </div>
                  <span className="text-[10.5px] font-mono bg-emerald-50 text-emerald-800 border border-emerald-250 px-2.5 py-0.5 rounded-full font-black select-none">
                    98% Engine Score
                  </span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-semibold">
                  <div className="p-3 bg-slate-50/50 border border-amber-500/[0.04] rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-600 block font-bold uppercase">Active Sessions</span>
                    <p className="text-sm font-black font-mono text-slate-800">4 Active Sessions</p>
                  </div>
                  <div className="p-3 bg-slate-50/50 border border-amber-500/[0.04] rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-600 block font-bold uppercase">Online Students</span>
                    <p className="text-sm font-black font-mono text-emerald-700">2 Connected</p>
                  </div>
                  <div className="p-3 bg-slate-50/50 border border-amber-500/[0.04] rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-600 block font-bold uppercase">Online Instructors</span>
                    <p className="text-sm font-black font-mono text-indigo-700">2 Logged In</p>
                  </div>
                  <div className="p-3 bg-slate-50/50 border border-amber-500/[0.04] rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-600 block font-bold uppercase">Storage Capacity</span>
                    <p className="text-sm font-black font-mono text-slate-800">12.4 GB / 100 GB</p>
                  </div>
                </div>

              </div>

              {/* BENTO ROW: ANNOUNCEMENTS PUBLISHER AND SECURITY CONTEXT */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fadeIn">
                
                {/* Announcement Disperser */}
                <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-800">Announcement Broadcasting Center</h4>
                      <p className="text-[10px] text-slate-700/50 font-bold">Instantly routes announcements directly to student / teacher screens</p>
                    </div>
                    <button
                      onClick={() => handleOpenModal('addAnnouncement')}
                      className="p-1 px-2.5 rounded xl bg-blue-600 hover:bg-blue-700 text-white font-black text-[10.5px] cursor-pointer flex items-center gap-1 shadow-sm transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Post Memo</span>
                    </button>
                  </div>

                  <div className="space-y-3 max-h-[260px] overflow-y-auto pr-1">
                    {announcements.map((ann) => {
                      const priorityColor = ann.priority === 'Emergency' ? 'bg-red-100 text-red-800' : ann.priority === 'Academic' ? 'bg-[#ffeed5] text-slate-700 font-black' : 'bg-zinc-100 text-zinc-800';
                      return (
                        <div key={ann.id} className="p-3 bg-[#fbf9f4]/80 text-xs border border-slate-200 rounded-2xl relative space-y-1 hover:border-amber-400/50 transition-all">
                          <div className="flex items-center justify-between">
                            <span className={`px-1.5 py-0.5 rounded text-[8.5px] font-black uppercase ${priorityColor}`}>
                              {ann.priority}
                            </span>
                            <span className="text-[9.5px] text-slate-600/70 font-mono">{ann.publishDate}</span>
                          </div>
                          <h5 className="font-extrabold text-slate-800 pt-0.5">{ann.title}</h5>
                          <p className="text-[11px] text-[#554a3e]">{ann.description}</p>
                          <button
                            onClick={() => handleDeleteItem(ann.id, 'announcement', ann.title)}
                            className="absolute bottom-2.5 right-2 text-slate-600/40 hover:text-red-650 cursor-pointer text-red-600"
                            title="Deport Memo"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Audit transaction security log trail */}
                <div className="lg:col-span-7 bg-[#1c1209] text-amber-100 rounded-3xl border border-amber-950 p-6 shadow-xl space-y-4 font-mono select-none">
                  <div className="flex justify-between items-center pb-2 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-emerald-400 animate-pulse" />
                      <span className="text-xs font-black tracking-wide text-amber-300 uppercase">Interactive Security Audits Logs</span>
                    </div>
                    <span className="text-[9.5px] text-white/45">Registry Watch Enabled</span>
                  </div>

                  <div className="space-y-4 max-h-[260px] overflow-y-auto pr-1 text-[11px]">
                    {systemLogs.slice(0, 7).map((log) => (
                      <div key={log.id} className="p-3 bg-[#1e150b] rounded-xl border border-[#2d2218] flex flex-col md:flex-row justify-between gap-1 shadow-sm">
                        <p className="flex items-start gap-2">
                          <span className="text-[#be9e7a] font-mono shrink-0 font-bold">{log.timestamp.split(',')[1]}</span>
                          <span className="text-emerald-300 font-extrabold tracking-tight">{log.actor}</span>
                          <span className="text-slate-300 font-medium">{log.action}</span>
                          <span className="text-amber-450 font-black">{log.subject}</span>
                        </p>
                        <span className="text-slate-600 font-mono text-[9px] mt-1 md:mt-0 self-center">{log.id.slice(0, 10)}</span>
                      </div>
                    ))}
                    {systemLogs.length === 0 && (
                      <p className="text-center text-white/20 py-10 text-xs italic">No active system audit activity.</p>
                    )}
                  </div>
                </div>

              </div>

            </motion.div>
          )}

          {/* TAB 2: COURSES & PROGRAMS (Section 1) */}
          {activeTab === 'Courses' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-2 border-b border-slate-200">
                  <div>
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">Courses & Programs registry</h3>
                    <p className="text-xs text-slate-600 font-bold">{filteredPrograms.length} active programs defined</p>
                  </div>

                  <button
                    onClick={() => handleOpenModal('addCourse')}
                    className="p-2 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:brightness-110 text-white font-black text-xs cursor-pointer flex items-center gap-2 shadow-md transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Program Option</span>
                  </button>
                </div>

                {/* Programs Table */}
                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#fcfaf5] text-slate-700/70 border-b border-slate-200 font-black">
                        <th className="p-4">Course/Program Name</th>
                        <th className="p-4">Department Badge</th>
                        <th className="p-4">Subjects Count</th>
                        <th className="p-4">Total Credits Weight</th>
                        <th className="p-4 text-center">Curriculum Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-100/50 font-semibold text-slate-800">
                      {filteredPrograms.map((prog) => (
                        <tr key={prog.id} className="hover:bg-slate-500/[0.01] transition-all">
                          <td className="p-4">
                            <div className="font-extrabold text-[#3a2512]">{prog.name}</div>
                            <span className="text-[10px] text-blue-600/50 block font-normal max-w-sm truncate">{prog.description}</span>
                          </td>
                          <td className="p-4">
                            <span className={`px-2.5 py-1 text-[10px] font-black uppercase rounded-full border ${getDeptBadgeStyle(prog.department)}`}>
                              {prog.department}
                            </span>
                          </td>
                          <td className="p-4 font-mono font-black">{prog.subjectsCount} Subjects</td>
                          <td className="p-4 font-mono font-black">{prog.totalCredits} Credits</td>
                          <td className="p-4 flex justify-center items-center gap-2">
                            <button
                              onClick={() => handleOpenModal('editCourse', prog)}
                              className="p-1.5 bg-[#fdf8f2] text-slate-600 hover:bg-amber-200/50 rounded-xl border border-slate-200 cursor-pointer"
                              title="Alter Details"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteItem(prog.id, 'course', prog.name)}
                              className="p-1.5 bg-red-50 text-red-650 hover:bg-red-100 rounded-xl border border-red-100 cursor-pointer text-red-650 text-red-600"
                              title="Deport Program"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {filteredPrograms.length === 0 && (
                        <tr>
                          <td colSpan={5} className="p-10 text-center text-slate-600/40">
                            No program definitions matched searching queries.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 3: SUBJECT MANAGEMENT (Section 1) */}
          {activeTab === 'Subjects' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-2 border-b border-slate-200">
                  <div>
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">Subject Management registry</h3>
                    <p className="text-xs text-slate-600 font-bold">{filteredSubjects.length} subjects outlines active</p>
                  </div>

                  <button
                    onClick={() => handleOpenModal('addSubject')}
                    className="p-2 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:brightness-110 text-white font-black text-xs cursor-pointer flex items-center gap-2 shadow-md transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Establish New Subject outline</span>
                  </button>
                </div>

                {/* Subjects Table */}
                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#fcfaf5] text-slate-700/70 border-b border-slate-200 font-black">
                        <th className="p-4">Subject Name</th>
                        <th className="p-4">Academic Code</th>
                        <th className="p-4">Credits Badge</th>
                        <th className="p-4">Assigned Dept / Program</th>
                        <th className="p-4">Semester</th>
                        <th className="p-4">Subject KPI (GPA / Pass)</th>
                        <th className="p-4 text-center">Curriculum Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-100/50 font-semibold text-slate-800">
                      {filteredSubjects.map((sub) => {
                        const stats = getSubjectStats(sub.code);
                        return (
                          <tr key={sub.id} className="hover:bg-slate-500/[0.01] transition-all">
                            <td className="p-4">
                              <div className="font-extrabold text-[#3a2512]">{sub.name}</div>
                              <span className="text-[10px] text-blue-600/50 block font-normal">Instructor: {sub.instructorName}</span>
                            </td>
                            <td className="p-4">
                              <span className="px-2.5 py-1 text-[10.5px] font-black uppercase tracking-wider rounded bg-sky-50 text-sky-800 border border-sky-305 font-mono">
                                {sub.code}
                              </span>
                            </td>
                            <td className="p-4">
                              <span className="px-2 py-0.5 rounded bg-zinc-100 text-zinc-700 border border-zinc-250 font-bold font-mono">
                                {sub.credits} Credits
                              </span>
                            </td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getDeptBadgeStyle(sub.department)}`}>
                                {sub.department}
                              </span>
                            </td>
                            <td className="p-4 font-mono">{sub.semester}</td>
                            <td className="p-4">
                              <div className="space-y-0.5">
                                <p className="font-mono text-[11px] font-black">Avg GPA: <strong className="text-[#a46115]">{stats.avgGpa}</strong></p>
                                <p className="text-[9.5px] text-emerald-800 block">Pass Rate: {stats.passRate}%</p>
                              </div>
                            </td>
                            <td className="p-4 flex justify-center items-center gap-2 mt-1">
                              <button
                                onClick={() => handleOpenModal('editSubject', sub)}
                                className="p-1.5 bg-[#fdf8f2] text-slate-600 hover:bg-amber-200/50 rounded-xl border border-slate-200 cursor-pointer"
                                title="Define Settings"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteItem(sub.id, 'subject', sub.code)}
                                className="p-1.5 bg-red-50 text-red-650 hover:bg-red-100 rounded-xl border border-red-100 cursor-pointer text-red-650 text-red-600"
                                title="Excuse Subject"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                      {filteredSubjects.length === 0 && (
                        <tr>
                          <td colSpan={7} className="p-10 text-center text-slate-600/40">
                            No subject outlines match search.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 4: ENROLLED STUDENTS DIRECTORY (Section 1) */}
          {activeTab === 'Students' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-2 border-b border-slate-200">
                  <div>
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">Matriculated Students Directory</h3>
                    <p className="text-xs text-slate-600 font-bold">{filteredStudents.length} candidates registered</p>
                  </div>

                  <button
                    onClick={() => handleOpenModal('addStudent')}
                    className="p-2 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:brightness-110 text-white font-black text-xs cursor-pointer flex items-center gap-2 shadow-md transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Enroll new Student</span>
                  </button>
                </div>

                {/* Students Table */}
                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#fcfaf5] text-slate-700/70 border-b border-slate-200 font-black">
                        <th className="p-4">Candidate Full Name</th>
                        <th className="p-4">Academic Email</th>
                        <th className="p-4">Level Track</th>
                        <th className="p-4">Role Badge</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-center">Registrar controls</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-100/50 font-semibold text-slate-800">
                      {filteredStudents.map((st) => {
                        const isSusp = st.academicLevel.includes('[SUSPENDED]');
                        return (
                          <tr key={st.id} className="hover:bg-slate-500/[0.01] transition-all">
                            <td className="p-4">
                              <div className="flex items-center gap-3">
                                {/* Letter Avatar (Section 1) */}
                                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-200 to-amber-300 text-slate-800 font-black flex items-center justify-center text-sm shadow-inner uppercase">
                                  {st.name.charAt(0)}
                                </div>
                                <div>
                                  <h4 className="font-extrabold text-[#3a2512]">{st.name}</h4>
                                  <span className="text-[9.5px] font-mono text-blue-600 block mt-0.5">{st.studentId}</span>
                                </div>
                              </div>
                            </td>
                            <td className="p-4 font-mono select-all text-slate-600">{st.email}</td>
                            <td className="p-4">
                              <span className="font-extrabold block">{st.academicLevel}</span>
                              <span className="text-[10px] text-blue-600 font-normal">{st.semester}</span>
                            </td>
                            <td className="p-4">
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
                                Student
                              </span>
                            </td>
                            <td className="p-4">
                              <span className={`px-2.5 py-1 text-[10px] font-black rounded uppercase ${
                                isSusp 
                                  ? 'bg-rose-150 text-red-800 border border-red-300' 
                                  : 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                              }`}>
                                {isSusp ? 'Suspended' : 'Active'}
                              </span>
                            </td>
                            <td className="p-4 flex justify-center items-center gap-1.5 mt-1">
                              <button
                                onClick={() => handleOpenModal('editStudent', st)}
                                className="p-1.5 bg-[#fdf8f2] text-slate-600 hover:bg-amber-200/50 rounded-xl border border-slate-200 cursor-pointer"
                                title="Edit profile"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => toggleStudentSuspension(st)}
                                className={`p-1.5 text-xs font-bold rounded-xl border cursor-pointer ${
                                  isSusp ? 'bg-emerald-50 border-emerald-250 text-emerald-800' : 'bg-slate-50 border-slate-200 text-[#b54a10]'
                                }`}
                                title={isSusp ? 'Reactivate Profile' : 'Suspend Account'}
                              >
                                <Lock className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleOpenModal('resetPassword', st)}
                                className="p-1.5 bg-sky-50 text-sky-800 border-sky-305 hover:bg-sky-100 rounded-xl border cursor-pointer"
                                title="Reset Key Credentials"
                              >
                                <Lock className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteItem(st.id, 'student', st.name)}
                                className="p-1.5 bg-red-50 text-red-650 hover:bg-red-100 rounded-xl border border-red-100 cursor-pointer text-red-650 text-red-600"
                                title="Ergonomically Expel"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                      {filteredStudents.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-10 text-center text-slate-600/40">
                            No matching students discovered.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 5: ADVANCED ANALYTICS CENTER */}
          {activeTab === 'Analytics' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Visual Chart 1: Institutional GPA distribution (Section 2) */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                  <span className="text-[9.5px] text-slate-600/60 uppercase tracking-widest font-black block">GPA Grade Distribution</span>
                  <h4 className="text-sm font-black text-slate-800 font-display">Student Performance Plot</h4>
                  
                  <div className="h-60 relative flex items-end justify-between px-2 pt-6">
                    {/* SVG Line path background */}
                    <div className="absolute inset-0 flex flex-col justify-between text-[9px] text-slate-600/40 font-mono pointer-events-none pb-4 pt-10">
                      <div className="border-b border-amber-500/[0.04]">4.0 Excellent</div>
                      <div className="border-b border-amber-500/[0.04]">3.0 Satisfactory</div>
                      <div className="border-b border-amber-500/[0.04]">2.0 Passing</div>
                      <div className="border-b border-amber-500/[0.04]">0.0 Probation</div>
                    </div>

                    <div className="w-full h-40 z-10 flex items-end justify-around">
                      {students.map((st) => {
                        const grades = Object.values(st.grades) as any[];
                        const points = grades.length > 0 ? grades.reduce((sum, g) => sum + g.gpaPoint, 0) / grades.length : 0.0;
                        const height = (points / 4.0) * 100;
                        return (
                          <div key={st.id} className="w-8 relative flex flex-col items-center group">
                            {/* Hover info tooltip */}
                            <div className="absolute bottom-full mb-2 bg-[#2a1b10] text-[#ffeed3] text-[9.5px] p-2 rounded-xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-20 whitespace-nowrap">
                              <p className="font-extrabold">{st.name}</p>
                              <p className="font-mono text-amber-300">{points.toFixed(2)} GPA</p>
                            </div>
                            {/* Bar element */}
                            <div className="w-4 rounded-t-md bg-gradient-to-t from-amber-600 to-amber-450" style={{ height: `${height}%` }} />
                            <span className="text-[9px] font-black font-mono mt-1 text-slate-800 truncate max-w-full block">
                              {st.name.split(' ')[0]}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Visual Chart 2: Cumulative Pass Rate benchmark lines (SVG area) */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                  <span className="text-[9.5px] text-slate-600/60 uppercase tracking-widest font-black block">Curriculum performance metrics</span>
                  <h4 className="text-sm font-black text-slate-800 font-display">Pass Rate by Subject Outline</h4>

                  <div className="h-60 relative flex items-end justify-between px-2 pt-6">
                    <div className="absolute inset-0 flex flex-col justify-between text-[9px] text-slate-600/40 font-mono pointer-events-none pb-4 pt-10">
                      <div className="border-b border-amber-500/[0.04]">100% Complete passing</div>
                      <div className="border-b border-amber-500/[0.04]">75% Benchmark</div>
                      <div className="border-b border-amber-500/[0.04]">50% Warning Level</div>
                    </div>

                    <div className="w-full h-40 z-10 flex items-end justify-around">
                      {subjects.map((sub) => {
                        const score = getSubjectStats(sub.code);
                        const height = score.passRate;
                        return (
                          <div key={sub.id} className="w-10 relative flex flex-col items-center group">
                            <div className="absolute bottom-full mb-2 bg-[#2a1b10] text-[#ffeed3] text-[9.5px] p-2 rounded-xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-20 whitespace-nowrap">
                              <p className="font-extrabold">{sub.name}</p>
                              <p className="font-semibold">{score.passRate}% GPA Met</p>
                            </div>
                            {/* Bar styled with subject code gradient */}
                            <div className="w-4 rounded-t-md bg-gradient-to-t from-sky-600 to-sky-400" style={{ height: `${height}%` }} />
                            <span className="text-[9px] font-black font-mono mt-1 text-slate-800">
                              {sub.code}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Visual Chart 3: GPA Frequency Distribution */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4 lg:col-span-2">
                  <span className="text-[9.5px] text-slate-600/60 uppercase tracking-widest font-black block">GPA Frequency Distribution</span>
                  <h4 className="text-sm font-black text-slate-800 font-display">Student GPA Statistics</h4>
                  
                  <div className="h-60 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={gpaRanges}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip cursor={{fill: '#f1f5f9'}} contentStyle={{backgroundColor: '#fff', border: 'none', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)'}} />
                        <Bar dataKey="count" fill="#2563eb" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 6: REPORTS & EXPORTS CENTER */}
          {activeTab === 'Reports' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
                <div>
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">Institution Reports center</h3>
                  <p className="text-xs text-slate-600 font-bold">Generate, review, and print academic data ledger compilations offline</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Report Card 1: GPA Student rankings */}
                  <div className="p-5 bg-slate-50/50 border border-amber-500/[0.05] rounded-3xl space-y-3">
                    <div className="flex justify-between items-start">
                      <h4 className="text-xs font-black uppercase text-slate-800 leading-tight">Student GPA Compilation Report</h4>
                      <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                    </div>
                    <p className="text-xs text-[#554a3e]">Aggregated statistics reflecting cumulative GPA results inside active class registries.</p>
                    <div className="pt-2 flex gap-2">
                      <button 
                        onClick={() => handleExportCSV('gpa')}
                        className="py-1.5 px-3.5 bg-amber-655 hover:bg-blue-700 bg-blue-600 text-white font-extrabold rounded-lg text-xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download CSV</span>
                      </button>
                    </div>
                  </div>

                  {/* Report Card 2: Subject outline registries */}
                  <div className="p-5 bg-slate-50/50 border border-amber-500/[0.05] rounded-3xl space-y-3">
                    <div className="flex justify-between items-start">
                      <h4 className="text-xs font-black uppercase text-slate-800 leading-tight">Curriculum & Subjects Report</h4>
                      <Layers className="w-4 h-4 text-blue-600" />
                    </div>
                    <p className="text-xs text-[#554a3e]">Active courses, assigned credits, syllabus outlines, and designated semester schedules.</p>
                    <div className="pt-2 flex gap-2">
                      <button 
                        onClick={() => handleExportCSV('passrate')}
                        className="py-1.5 px-3.5 bg-amber-655 hover:bg-blue-700 bg-blue-600 text-white font-extrabold rounded-lg text-xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Excel</span>
                      </button>
                    </div>
                  </div>

                  {/* Report Card 3: Auditor safety transactions logs output */}
                  <div className="p-5 bg-slate-50/50 border border-amber-500/[0.05] rounded-3xl space-y-3">
                    <div className="flex justify-between items-start">
                      <h4 className="text-xs font-black uppercase text-slate-800 leading-tight">Security Auditor logs output</h4>
                      <History className="w-4 h-4 text-blue-600" />
                    </div>
                    <p className="text-xs text-[#554a3e]">Tracks system-wide logins, score changes, student registrations, and curricular creations.</p>
                    <div className="pt-2 flex gap-2">
                      <button 
                        onClick={() => handleExportCSV('logs')}
                        className="py-1.5 px-3.5 bg-amber-655 hover:bg-blue-700 bg-blue-600 text-white font-extrabold rounded-lg text-xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download CSV Logs</span>
                      </button>
                      <button 
                        onClick={() => window.print()}
                        className="py-1.5 px-3.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-extrabold rounded-lg text-xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Report</span>
                      </button>
                    </div>
                  </div>

                </div>
              </div>

            </motion.div>
          )}

          {/* TAB 7: SYSTEM ALERTS */}
          {activeTab === 'Notifications' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <div>
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">System Notifications Feed</h3>
                    <p className="text-xs text-slate-600 font-bold">Unread system alarms, teacher updates, and grading events</p>
                  </div>
                  <button 
                    onClick={() => {
                      const cleared = notifications.map(n => ({ ...n, unread: false }));
                      setNotifications(cleared);
                      saveStoredNotifications(cleared);
                      triggerAlert("All notification flags cleared.");
                    }}
                    className="p-1 px-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-[10.5px] cursor-pointer"
                  >
                    Mark All Unread Read
                  </button>
                </div>

                <div className="space-y-3">
                  {notifications.map((notif) => {
                    const iconColor = notif.type === 'alert' ? 'text-red-500 bg-red-50' : 'text-blue-600 bg-slate-50';
                    return (
                      <div key={notif.id} className={`p-4 rounded-2xl flex gap-3 border text-xs leading-normal ${notif.unread ? 'bg-slate-500/[0.03] border-slate-200' : 'bg-transparent border-amber-900/5'}`}>
                        <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center ${iconColor}`}>
                          <AlertTriangle className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-extrabold text-[#3a2512] flex items-center gap-2">
                            <span>{notif.title}</span>
                            {notif.unread && <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />}
                          </h4>
                          <p className="text-slate-600 text-[10px] uppercase block font-mono mt-0.5">{notif.date}</p>
                          <p className="text-slate-700/80 mt-1">{notif.message}</p>
                        </div>
                      </div>
                    );
                  })}
                  {notifications.length === 0 && (
                    <p className="text-center text-slate-600/40 py-10">No alerts/notifications reported in active stack.</p>
                  )}
                </div>

              </div>
            </motion.div>
          )}

          {/* TAB 8: PROFILE SECURITY */}
          {activeTab === 'Settings' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
                <div>
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">Administrative security settings</h3>
                  <p className="text-xs text-slate-600 font-bold">Manage administrative credentials, academic cycles, and security limits</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-semibold">
                  
                  {/* Sector Year Settings */}
                  <div className="space-y-3.5">
                    <h4 className="text-xs uppercase text-slate-800 tracking-wider font-extrabold">Active Academic Year Settings</h4>
                    
                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">Academic Year Cycle</label>
                      <select 
                        value={academicYear} 
                        onChange={(e) => setAcademicYear(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 border-slate-200 rounded-xl px-3.5 py-2 font-black"
                      >
                        <option value="2025-2026">2025 - 2026</option>
                        <option value="2026-2027">2026 - 2027</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">Database Backup Mode</label>
                      <div className="p-3 bg-emerald-50 border border-emerald-250 text-emerald-800 rounded-xl font-bold flex items-center justify-between">
                        <span>Automatic Backup: Hourly</span>
                        <span className="text-[10px] bg-emerald-600 text-white font-mono px-2 py-0.5 rounded uppercase">On</span>
                      </div>
                    </div>
                  </div>

                  {/* Operational Security constraints */}
                  <div className="space-y-3.5">
                    <h4 className="text-xs uppercase text-slate-800 tracking-wider font-extrabold">Administrative Authorization Account</h4>
                    
                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">Secure Login Audit Trail Status</label>
                      <div className="p-3 bg-indigo-50 border border-indigo-250 text-indigo-800 rounded-xl font-bold flex items-center justify-between">
                        <span>Administrative role checks (Admin, Teacher, Student)</span>
                        <span className="text-[10px] bg-indigo-650 bg-indigo-600 text-white font-mono px-2 py-0.5 rounded uppercase">Active</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">Curriculum Publication Locking</label>
                      <div className="p-3 bg-slate-50 border border-slate-200 text-slate-600 rounded-xl font-bold flex items-center justify-between">
                        <span>Grades Retractor security limits</span>
                        <span className="text-[10px] bg-blue-600 text-white font-mono px-2 py-0.5 rounded uppercase font-black">Authorized</span>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              {/* TAB 8 part 2: Admin Profile configurations */}
              <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                <div>
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">Manage Administrator Profile</h3>
                  <p className="text-xs text-slate-600 font-bold">Configure identity parameters and upload database-authenticated security photo</p>
                </div>

                <form onSubmit={handleAdminProfileSave} className="space-y-4 text-xs font-semibold">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs font-semibold">
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-slate-700 font-bold block">Administrator Full Name</label>
                        <input
                          type="text"
                          required
                          value={adminName}
                          onChange={(e) => setAdminName(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 font-medium focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-700 font-bold block">Secure Registrar Email</label>
                        <input
                          type="email"
                          required
                          value={adminEmail}
                          onChange={(e) => setAdminEmail(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 font-medium focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-700 font-bold block">Departmental Title Role</label>
                        <input
                          type="text"
                          required
                          value={adminTitle}
                          onChange={(e) => setAdminTitle(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 font-medium focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="flex flex-col justify-center items-center p-4 bg-slate-50/50 rounded-2xl border border-slate-200/50 gap-3.5">
                      <div 
                        onClick={() => setIsAvatarModalOpen(true)}
                        className="relative w-24 h-24 rounded-full border-4 border-blue-500/30 hover:border-blue-500 cursor-pointer overflow-hidden group select-none transition-all shadow-sm"
                        title="Click to take photo or pick image file"
                      >
                        <img src={adminAvatar} alt="Admin Pic" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <div className="absolute inset-0 bg-black/45 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Camera className="w-5 h-5 text-white" />
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setIsAvatarModalOpen(true)}
                        className="py-1.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-blue-600 flex items-center gap-1.5 cursor-pointer hover:underline transition-all shadow-sm"
                      >
                        <Camera className="w-3.5 h-3.5" />
                        Change Security Photo
                      </button>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="py-2.5 px-6 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-[11px] tracking-wide transition-all shadow cursor-pointer active:scale-95"
                    >
                      Lock Identity Ledger
                    </button>
                  </div>
                </form>

                {/* Secure Avatar Camera modal */}
                <AvatarCameraModal
                  isOpen={isAvatarModalOpen}
                  onClose={() => setIsAvatarModalOpen(false)}
                  onSave={(newPic) => {
                    setAdminAvatar(newPic);
                    setIsAvatarModalOpen(false);
                  }}
                  currentAvatar={adminAvatar}
                />
              </div>

            </motion.div>
          )}

        </AnimatePresence>

      </main>

      {/* =========================================================
          UNIFIED REGISTRATION / AUDIT MODAL (Section 2)
          ========================================================= */}
      <AnimatePresence>
        {modal.isOpen && (
          <div className="fixed inset-0 bg-[#2c2419]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white border border-slate-200 rounded-3xl shadow-2xl p-6 w-full max-w-lg overflow-y-auto max-h-[90vh] space-y-4"
            >
              <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest font-display">
                  {modal.type === 'addCourse' ? 'Register New Course Program' : 
                   modal.type === 'editCourse' ? 'Edit Course Program details' :
                   modal.type === 'addSubject' ? 'Establish Subject definition Outline' :
                   modal.type === 'editSubject' ? 'Edit Subject Outline parameters' :
                   modal.type === 'addStudent' ? 'Matriculate New Candidate Profile' :
                   modal.type === 'editStudent' ? 'Alter registry Candidate file' :
                   modal.type === 'addTeacher' ? 'Hire new Academic Faculty' :
                   modal.type === 'editTeacher' ? 'Alter teacher file' :
                   modal.type === 'addAnnouncement' ? 'Post Bulletin Announcement Memo' : 
                   'Reset user Password'}
                </h3>
                <button onClick={handleCloseModal} className="p-1.5 hover:bg-slate-50 rounded-full cursor-pointer text-slate-700">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={executeModalAction} className="space-y-4 text-xs font-semibold">
                
                {/* 1. COURSES FORM */}
                {(modal.type === 'addCourse' || modal.type === 'editCourse') && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Course Program Name</label>
                      <input 
                        type="text" 
                        required 
                        value={formData.name || ''} 
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Associate of Science in Bio-Genetics"
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-blue-500 text-slate-800 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Affiliated Department</label>
                      <select
                        value={formData.department || 'Biology'}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 cursor-pointer"
                      >
                        <option value="Biology">Biology</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Physics">Physics</option>
                        <option value="Agriculture">Agriculture</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="English">English</option>
                        <option value="Information Technology">Information Technology</option>
                        <option value="Web Development">Web Development</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Starting Subjects Count</label>
                        <input 
                          type="number" 
                          min={1} 
                          value={formData.subjectsCount || 1} 
                          onChange={(e) => setFormData({ ...formData, subjectsCount: e.target.value })}
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Total Credits weight</label>
                        <input 
                          type="number" 
                          min={1} 
                          value={formData.totalCredits || 3} 
                          onChange={(e) => setFormData({ ...formData, totalCredits: e.target.value })}
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Course overview</label>
                      <textarea 
                        rows={3} 
                        value={formData.description || ''} 
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Description of the curriculum pathway..."
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none"
                      />
                    </div>
                  </div>
                )}

                {/* 2. SUBJECTS FORM */}
                {(modal.type === 'addSubject' || modal.type === 'editSubject') && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Subject Title Name</label>
                        <input 
                          type="text" 
                          required 
                          value={formData.name || ''} 
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="General Plant Botanical Bio"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Academic Code</label>
                        <input 
                          type="text" 
                          required 
                          value={formData.code || ''} 
                          onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                          placeholder="BIO-104"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 font-mono"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Credits Assigned</label>
                        <input 
                          type="number" 
                          min={1} 
                          value={formData.credits || 3} 
                          onChange={(e) => setFormData({ ...formData, credits: e.target.value })}
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Designated Semester</label>
                        <select
                          value={formData.semester || 'Semester 1'}
                          onChange={(e) => setFormData({ ...formData, semester: e.target.value })}
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        >
                          <option value="Semester 1">Semester 1</option>
                          <option value="Semester 2">Semester 2</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Affiliated Department Program</label>
                      <select
                        value={formData.department || 'Biology'}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                      >
                        <option value="Biology">Biology</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Physics">Physics</option>
                        <option value="Agriculture">Agriculture</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="English">English</option>
                        <option value="Information Technology">Information Technology</option>
                        <option value="Web Development">Web Development</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Assigned Instructor Name</label>
                      <input 
                        type="text" 
                        value={formData.instructorName || ''} 
                        onChange={(e) => setFormData({ ...formData, instructorName: e.target.value })}
                        placeholder="Sister Helen Desta"
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                      />
                    </div>
                  </div>
                )}

                {/* 3. STUDENTS FORM */}
                {(modal.type === 'addStudent' || modal.type === 'editStudent') && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Student Full Name</label>
                        <input 
                          type="text" 
                          required 
                          value={formData.name || ''} 
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="Abebe Kebede"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Academic Email</label>
                        <input 
                          type="email" 
                          required 
                          value={formData.email || ''} 
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="abe@edutrack.com"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Classroom Academic Level</label>
                      <select
                        value={formData.academicLevel || 'Grade 12 - Senior Academy'}
                        onChange={(e) => setFormData({ ...formData, academicLevel: e.target.value })}
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                      >
                        <option value="Grade 12 - Senior Academy">Grade 12 - Senior Academy</option>
                        <option value="Grade 11 - Pre-University">Grade 11 - Pre-University</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Parent Guardian Name</label>
                        <input 
                          type="text" 
                          value={formData.parentName || ''} 
                          onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                          placeholder="Kebede Alazar"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Parent Contact Phone</label>
                        <input 
                          type="text" 
                          value={formData.parentContact || ''} 
                          onChange={(e) => setFormData({ ...formData, parentContact: e.target.value })}
                          placeholder="+251-911-23-45-67"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* 4. TEACHERS FORM */}
                {(modal.type === 'addTeacher' || modal.type === 'editTeacher') && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Teacher Full Name</label>
                      <input 
                        type="text" 
                        required 
                        value={formData.name || ''} 
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Prof. Alula Girma"
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Academic Email</label>
                      <input 
                        type="email" 
                        required 
                        value={formData.email || ''} 
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="alula@edutrack.com"
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Course Code Assigned</label>
                        <input 
                          type="text" 
                          required 
                          value={formData.subjectCode || ''} 
                          onChange={(e) => setFormData({ ...formData, subjectCode: e.target.value })}
                          placeholder="IT-107"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 file:text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 uppercase font-black mb-1">Subject Course Title</label>
                        <input 
                          type="text" 
                          required 
                          value={formData.subjectName || ''} 
                          onChange={(e) => setFormData({ ...formData, subjectName: e.target.value })}
                          placeholder="Information Technology"
                          className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* 5. ANNOUNCEMENTS FORM */}
                {modal.type === 'addAnnouncement' && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Announcement Bulletin Title</label>
                      <input 
                        type="text" 
                        required 
                        value={formData.title || ''} 
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="E.g. Computer Science registration deadlines"
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 pointer-events-auto"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Official Circular Message</label>
                      <textarea 
                        rows={4} 
                        required 
                        value={formData.description || ''} 
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Provide details about priorities or deadlines..."
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 uppercase font-black mb-1">Bulletins Type Severity scale</label>
                      <select
                        value={formData.priority || 'General'}
                        onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                        className="w-full bg-slate-50/50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 cursor-pointer"
                      >
                        <option value="General">General Notice</option>
                        <option value="Academic">Academic Schedule</option>
                        <option value="Examination">Examination Schedule</option>
                        <option value="Emergency">Urgent / Emergency Alert</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* 6. PASSWORD RESET CONFIRMATION */}
                {modal.type === 'resetPassword' && (
                  <div className="space-y-2 py-2">
                    <p className="text-slate-700">
                      You are about to generate a temporary security link token for:
                    </p>
                    <p className="font-extrabold text-[#3a2512] font-mono text-sm">
                      {formData.name} ({formData.studentId || formData.teacherId})
                    </p>
                    <p className="text-slate-600 text-[10.5px]">
                      The registrar credentials will reset to a temporary key: <strong className="text-slate-800 font-mono">Edutrack@2026</strong>.
                    </p>
                  </div>
                )}

                {/* Submits buttons */}
                <div className="pt-4 flex justify-end gap-2.5 border-t border-slate-200">
                  <button 
                    type="button" 
                    onClick={handleCloseModal}
                    className="py-2 px-4 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 cursor-pointer text-xs"
                  >
                    Cancel Action
                  </button>
                  <button 
                    type="submit" 
                    className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold cursor-pointer text-xs"
                  >
                    {modal.type === 'resetPassword' ? 'Reset Authorized Key' : 'Consolidate Records'}
                  </button>
                </div>

              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
