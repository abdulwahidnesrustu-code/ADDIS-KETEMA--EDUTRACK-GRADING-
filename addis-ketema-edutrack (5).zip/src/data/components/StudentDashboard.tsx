/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  FileSpreadsheet, 
  UserCog, 
  Bell, 
  Search, 
  Sun, 
  Moon, 
  LogOut, 
  TrendingUp, 
  Award, 
  BookOpen, 
  CheckCircle, 
  AlertCircle,
  GraduationCap,
  Calendar,
  Layers,
  ChevronRight,
  Mail,
  User,
  Smartphone,
  CheckCircle2,
  Download,
  QrCode,
  ShieldAlert,
  Edit2,
  Camera,
  Signature,
  X
} from 'lucide-react';
import AvatarCameraModal from './AvatarCameraModal';
import { Student, AppNotification, SubjectGrade, UserRole } from '../types';
import { calculateGPA, getStoredNotifications, saveStoredNotifications, calculateGradeDetails, getStoredStudents, saveStoredStudents } from '../data/mockData';

import crestLogo from '../assets/images/addis_ketema_logo_1780404658947.png';

interface StudentDashboardProps {
  student: Student;
  onLogout: () => void;
  onProfileUpdate: (updatedStudent: Student) => void;
}

type TabType = 'Overview' | 'Transcript' | 'Profile';

export default function StudentDashboard({ student, onLogout, onProfileUpdate }: StudentDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>('Overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDarkTheme, setIsDarkTheme] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  
  // Real-time notifications pulled from storage
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  
  // Profile settings editor
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [picUrl, setPicUrl] = useState(student.avatar);
  const [profileName, setProfileName] = useState(student.name || '');
  const [profileEmail, setProfileEmail] = useState(student.email || '');
  const [parentName, setParentName] = useState(student.parentName || '');
  const [parentContact, setParentContact] = useState(student.parentContact || '');
  const [profileSuccessMsg, setProfileSuccessMsg] = useState<string | null>(null);

  // Sync state values when student prop changes
  const [localStudent, setLocalStudent] = useState<Student>(student);

  useEffect(() => {
    setLocalStudent(student);
    setPicUrl(student.avatar);
    setProfileName(student.name || '');
    setProfileEmail(student.email || '');
    setParentName(student.parentName || '');
    setParentContact(student.parentContact || '');
  }, [student.id, student]);

  // Load notifications and keep list synchronized on updates
  useEffect(() => {
    setNotifications(getStoredNotifications());

    const handleSync = () => {
      console.log("StudentDashboard: Sync triggered, checking for updates");
      setNotifications(getStoredNotifications());
      const students = getStoredStudents();
      const updatedStudent = students.find(s => s.id === student.id);
      console.log("StudentDashboard: updatedStudent found?", !!updatedStudent);
      if (updatedStudent) {
        setLocalStudent(updatedStudent);
      }
    };
    window.addEventListener('ak_db_updated', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('ak_db_updated', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Recalculate GPA parameters on any grade changes
  const { gpa, rating, totalCredits, passedCredits, atRiskCount } = calculateGPA(localStudent.grades);

  // Quick stats lists for rendering
  const gradesArray: SubjectGrade[] = Object.values(localStudent.grades);
  const filteredGrades = gradesArray.filter(g => 
    g.subjectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.subjectCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const unreadNotifsCount = notifications.filter(n => n.unread).length;

  const markAllNotifsRead = () => {
    const updated = notifications.map(n => ({ ...n, unread: false }));
    setNotifications(updated);
    saveStoredNotifications(updated);
  };

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Student = {
      ...student,
      avatar: picUrl,
      name: profileName,
      email: profileEmail,
      parentName: parentName,
      parentContact: parentContact
    };
    
    // Update local storage
    const students = getStoredStudents();
    const updatedStudents = students.map(s => s.id === updated.id ? updated : s);
    saveStoredStudents(updatedStudents);
    
    onProfileUpdate(updated);
    setProfileSuccessMsg("Academy Record Saved Successfully.");
    setTimeout(() => {
      setProfileSuccessMsg(null);
    }, 3000);
  };

  // Automated Mock Transcript PDF Trigger using window.print() standard
  const handlePrintTranscript = () => {
    const originalTitle = document.title;
    document.title = `Official_Transcript_${student.name.replace(/\s+/g, '_')}_${student.studentId.replace(/\//g, '_')}`;
    window.print();
    document.title = originalTitle;
  };

  const getBase64Image = async (url: string): Promise<string> => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      console.error("Failed to get base64 logo", e);
      return url;
    }
  };

  const handleDownloadTranscriptFile = async () => {
    const logoBase64 = await getBase64Image(crestLogo);
    const gradesVal = Object.values(student.grades);
    const tableRows = gradesVal.map(g => `
      <tr>
        <td style="font-family: monospace; font-weight: bold; color: #1e40af; padding: 10px; border-bottom: 1px solid #e2e8f0;">${g.subjectCode}</td>
        <td style="font-weight: bold; color: #0f172a; padding: 10px; border-bottom: 1px solid #e2e8f0;">${g.subjectName}</td>
        <td style="text-align: center; padding: 10px; border-bottom: 1px solid #e2e8f0;">${(g.assignments + g.quizzes + g.exams).toFixed(0)}%</td>
        <td style="text-align: center; padding: 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold;">${g.gpaPoint.toFixed(1)}</td>
        <td style="text-align: right; font-weight: bold; font-size: 14px; padding: 10px; border-bottom: 1px solid #e2e8f0; color: ${g.totalMark >= 75 ? '#16a34a' : g.totalMark >= 50 ? '#d97706' : '#dc2626'}">${g.letterGrade}</td>
      </tr>
    `).join('');

    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Transcript & Graduation Certificate - ${student.name}</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f1f5f9;
            color: #0f172a;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
        }
        .container {
            background-color: #ffffff;
            border: 2px solid #cbd5e1;
            border-radius: 20px;
            width: 100%;
            max-width: 800px;
            padding: 50px;
            box-shadow: 0 15px 40px rgba(37, 99, 235, 0.05);
            position: relative;
            box-sizing: border-box;
        }
        .border-double {
            border: 4px double #3b82f6;
            position: absolute;
            top: 15px;
            bottom: 15px;
            left: 15px;
            right: 15px;
            border-radius: 15px;
            pointer-events: none;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 25px;
            margin-bottom: 30px;
        }
        .logo-box {
            text-align: center;
            margin-bottom: 15px;
        }
        .logo-box img {
            width: 150px;
            height: 150px;
            object-fit: contain;
        }
        .header h1 {
            font-size: 24px;
            margin: 10px 0 0 0;
            color: #1e3a8a;
            letter-spacing: 1px;
            font-weight: 800;
        }
        .header h2 {
            font-size: 13px;
            color: #2563eb;
            margin: 8px 0 0 0;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-weight: bold;
        }
        .header p {
            font-size: 10px;
            color: #64748b;
            margin: 5px 0 0 0;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            background-color: #f8fafc;
            padding: 20px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .info-item {
            font-size: 13px;
        }
        .info-item label {
            font-size: 9px;
            color: #64748b;
            display: block;
            font-weight: bold;
            margin-bottom: 4px;
            text-transform: uppercase;
        }
        .info-item span {
            font-weight: bold;
            color: #0f172a;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            margin-bottom: 40px;
        }
        th {
            border-bottom: 2px solid #cbd5e1;
            padding: 10px;
            color: #1e40af;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 10px;
            text-align: left;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
        .gpa-badge {
            font-weight: bold;
            color: #16a34a;
        }
        .signatures {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 50px;
            margin-top: 40px;
            border-top: 1px solid #e2e8f0;
            padding-top: 20px;
        }
        .signature-item {
            text-align: center;
        }
        .signature-line {
            font-style: italic;
            font-family: 'Georgia', serif;
            font-size: 18px;
            color: #1e3a8a;
            border-bottom: 1.5px dashed #34d399;
            padding-bottom: 5px;
            margin-bottom: 5px;
        }
        .signature-label {
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
            color: #2563eb;
        }
        .signature-title {
            font-size: 9px;
            color: #64748b;
        }
        .stamp {
            text-align: center;
            margin-top: 20px;
            color: #475569;
            font-family: monospace;
            font-size: 11px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="border-double"></div>
        <div class="header">
            <div class="logo-box">
                <img src="${logoBase64}" alt="Institution Logo" />
            </div>
            <h1>ADDIS KETEMA PREPARATORY SCHOOL</h1>
            <h2>OFFICIAL TRANSCRIPT OF ACADEMIC RECORDS</h2>
            <p>Under Ministry of Education, Federal Democratic Republic of Ethiopia</p>
        </div>
        <div class="info-grid">
            <div class="info-item">
                <label>Student Name</label>
                <span>${student.name}</span>
            </div>
            <div class="info-item">
                <label>Student ID</label>
                <span style="font-family: monospace;">${student.studentId}</span>
            </div>
            <div class="info-item">
                <label>Academic Level</label>
                <span>${student.academicLevel.split(' ')[0]} Entry</span>
            </div>
            <div class="info-item">
                <label>Academic Term</label>
                <span>2025/2026 Term 2</span>
            </div>
            <div class="info-item">
                <label>Cumulative GPA</label>
                <span class="gpa-badge">${gpa.toFixed(2)} / 4.00</span>
            </div>
            <div class="info-item">
                <label>Credits Achieved</label>
                <span>${totalCredits} credits</span>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th style="padding: 10px;">Subject Code</th>
                    <th style="padding: 10px;">Course Name</th>
                    <th class="text-center" style="padding: 10px;">Total Mark</th>
                    <th class="text-center" style="padding: 10px;">GPA Point</th>
                    <th class="text-right" style="padding: 10px;">Letter Grade</th>
                </tr>
            </thead>
            <tbody>
                ${tableRows}
            </tbody>
        </table>

        <div class="signatures">
            <div class="signature-item">
                <div class="signature-line">Martha Alazar</div>
                <div class="signature-label">Class Instructor</div>
                <div class="signature-title">Prof. Martha Alazar</div>
            </div>
            <div class="signature-item">
                <div class="signature-line">Abraham Hailu</div>
                <div class="signature-label">Academic Director</div>
                <div class="signature-title">Dean Abraham Hailu</div>
            </div>
        </div>

        <div class="stamp">
            Verification Key: MOE-4428-AABP | Registered Archive Node v2026
        </div>
    </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const u = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = u;
    a.download = `Official_Transcript_${(student.name || 'Student').replace(/\s+/g, '_')}_${(student.studentId || 'NoID').replace(/\//g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(u);
  };

  return (
    <div className={`min-h-screen flex flex-col md:flex-row transition-all duration-300 ${isDarkTheme ? 'bg-[#0f172a] text-slate-100' : 'bg-[#f1f5f9] text-[#0f172a]'}`}>
      
      {/* SIDEBAR NAVIGATION - FIXED & Glassmorphic */}
      <aside className={`w-full md:w-64 shrink-0 border-b md:border-b-0 md:border-r transition-all duration-300 ${
        isDarkTheme ? 'bg-[#1e293b]/90 border-slate-800' : 'bg-white/85 border-slate-200/60'
      } backdrop-blur-md px-4 py-6 flex flex-col justify-between z-20`}>
        
        <div>
          {/* Logo Brand area */}
          <div className="flex flex-col items-center justify-center text-center gap-2.5 mb-6 px-2 pt-2 pb-5 border-b border-slate-200/40 dark:border-slate-800/80">
            <div className="w-24 h-24 rounded-2xl bg-white p-1 flex items-center justify-center border border-blue-100 shadow-md">
              <img src={crestLogo} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div>
              <h3 className="text-sm font-black text-[#2563eb] dark:text-blue-400 leading-none uppercase">ADDIS KETEMA</h3>
              <span className="text-[9px] font-extrabold text-slate-500 dark:text-slate-400 tracking-[0.2em] block mt-1">EDUTRACK</span>
            </div>
          </div>

          {/* Quick Avatar Panel inside Sidebar */}
          <div className={`p-3.5 rounded-2xl mb-6 flex items-center gap-3 border ${
            isDarkTheme ? 'bg-[#1e293b]/60 border-slate-800' : 'bg-slate-50/60 border-slate-200/60'
          }`}>
            <div className="relative group shrink-0">
              <img 
                src={picUrl} 
                alt={student.name} 
                className="w-11 h-11 rounded-full object-cover border-2 border-blue-500 shadow-sm"
                referrerPolicy="no-referrer"
              />
              <button 
                onClick={() => setActiveTab('Profile')}
                className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer text-white"
              >
                <Edit2 className="w-3 h-3" />
              </button>
            </div>
            <div className="min-w-0">
              <h4 className="text-xs font-bold truncate text-slate-800 dark:text-slate-200 uppercase">{student.name}</h4>
              <p className="text-[10px] text-slate-500 font-semibold truncate mt-0.5">{student.studentId}</p>
            </div>
          </div>

          {/* Menu Options */}
          <nav className="space-y-1.5">
            <button
              onClick={() => setActiveTab('Overview')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-extrabold tracking-wide transition-all ${
                activeTab === 'Overview'
                  ? 'bg-gradient-to-r from-blue-500/10 to-transparent border-l-4 border-blue-600 text-blue-700 dark:text-blue-450'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <LayoutDashboard className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Dashboard (Overview)</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 opacity-40" />
            </button>

            <button
              onClick={() => setActiveTab('Transcript')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-extrabold tracking-wide transition-all ${
                activeTab === 'Transcript'
                  ? 'bg-gradient-to-r from-blue-500/10 to-transparent border-l-4 border-blue-600 text-blue-700 dark:text-blue-450'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>My Report (Transcript)</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 opacity-40" />
            </button>

            <button
              onClick={() => setActiveTab('Profile')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-extrabold tracking-wide transition-all ${
                activeTab === 'Profile'
                  ? 'bg-gradient-to-r from-blue-500/10 to-transparent border-l-4 border-blue-600 text-blue-700 dark:text-blue-450'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <UserCog className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>Profile Management</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 opacity-40" />
            </button>
          </nav>
        </div>

        {/* Sidebar Footer logout */}
        <div className="mt-8 pt-4 border-t border-slate-200/50 dark:border-slate-800">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-red-650 hover:bg-red-500/10 rounded-xl transition-all cursor-pointer text-red-650 dark:text-red-400"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Session</span>
          </button>
        </div>

      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 flex flex-col min-w-0 relative">
        
        {/* STICKY TOP HEADER */}
        <header className={`sticky top-0 z-10 border-b backdrop-blur-md transition-all duration-300 ${
          isDarkTheme ? 'bg-[#0f172a]/90 border-slate-800' : 'bg-[#f1f5f9]/90 border-slate-200/60'
        } px-6 py-4 flex flex-row items-center justify-between`}>
          
          {/* Inner Search block */}
          <div className="relative max-w-sm w-full hidden sm:block">
            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 pointer-events-none">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search subjects or instructors..."
              className="w-full bg-white/60 dark:bg-[#1e293b]/50 border border-slate-200 dark:border-slate-800 rounded-full py-1.5 pl-9 pr-4 text-xs font-medium focus:outline-none focus:bg-white focus:border-blue-500 transition-all text-slate-800 dark:text-slate-100"
            />
          </div>

          <div className="sm:hidden block">
            <h1 className="text-sm font-bold text-[#2563eb] dark:text-slate-100">AKPS Student Portal</h1>
          </div>

          {/* Right Header Navigation */}
          <div className="flex items-center gap-4">
            
            {/* Quick date display badge */}
            <div className={`hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold ${
              isDarkTheme ? 'bg-[#1e293b] text-blue-400' : 'bg-blue-100/40 text-blue-800'
            }`}>
              <Calendar className="w-3.5 h-3.5" />
              <span>Academic Year 2026 • Term 2</span>
            </div>

            {/* Dark Theme toggle */}
            <button
              onClick={() => setIsDarkTheme(!isDarkTheme)}
              className="p-1.5 rounded-full hover:bg-blue-500/10 cursor-pointer text-blue-600 dark:text-blue-400"
            >
              {isDarkTheme ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Notification bell and dropdown */}
            <div className="relative">
              <button
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  if (!showNotifications) markAllNotifsRead();
                }}
                className="relative p-1.5 rounded-full hover:bg-blue-500/10 cursor-pointer text-blue-600 dark:text-blue-400"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-[9px] font-extrabold text-white flex items-center justify-center animate-bounce">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              {/* Notifications Dropdown Drawer */}
              <AnimatePresence>
                {showNotifications && (
                  <>
                    <div className="fixed inset-0 z-30" onClick={() => setShowNotifications(false)} />
                    <motion.div
                      initial={{ opacity: 0, y: 15, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 15, scale: 0.95 }}
                      className={`absolute right-0 mt-2.5 w-80 rounded-2xl shadow-xl z-40 border overflow-hidden ${
                        isDarkTheme ? 'bg-[#1e293b] border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="p-3 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
                        <span className="text-xs font-extrabold text-blue-900 dark:text-slate-200">Terminal Notifications</span>
                        <button 
                          onClick={() => setNotifications([])}
                          className="text-[10px] text-blue-600 hover:underline font-bold"
                        >
                          Clear
                        </button>
                      </div>

                      <div className="max-h-64 overflow-y-auto divide-y divide-slate-150/10 dark:divide-slate-800">
                        {notifications.length === 0 ? (
                          <div className="p-4 text-center text-xs text-slate-400">
                            No active school notifications.
                          </div>
                        ) : (
                          notifications.map((notif) => (
                            <div key={notif.id} className={`p-3 text-xs flex gap-2 hover:bg-blue-500/5 ${notif.unread ? 'bg-blue-500/5' : ''}`}>
                              {notif.type === 'grade' ? (
                                <CheckCircle className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                              ) : notif.type === 'alert' ? (
                                <ShieldAlert className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                              ) : (
                                <Award className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                              )}
                              <div className="min-w-0">
                                <h5 className="font-extrabold text-blue-800 dark:text-slate-200 leading-tight">{notif.title}</h5>
                                <p className="text-slate-600 dark:text-slate-300 text-[10.5px] mt-0.5 leading-relaxed">{notif.message}</p>
                                <span className="text-[9px] text-slate-400 block mt-1">{notif.date}</span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Profile circular avatar dropdown */}
            <div className="flex items-center gap-1.5 cursor-pointer leading-tight" onClick={() => setActiveTab('Profile')}>
              <img 
                src={picUrl} 
                alt={student.name} 
                className="w-8.5 h-8.5 rounded-full object-cover border border-slate-300 dark:border-slate-700"
                referrerPolicy="no-referrer"
              />
              <div className="hidden lg:block text-left">
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200">{student.name}</p>
                <span className="text-[9px] text-slate-500 font-semibold">{student.academicLevel.split(' ')[0]} Student</span>
              </div>
            </div>

          </div>

        </header>

        {/* CONTAINER VIEWPORTS switcher */}
        <div className="flex-1 p-6 md:p-8 overflow-y-auto">

          {/* VIEWPORT 1: COMPREHENSIVE OVERVIEW */}
          {activeTab === 'Overview' && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Header Welcome Card banner */}
              <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-blue-500/10 via-blue-500/[0.03] to-white dark:from-slate-900 dark:via-slate-900/50 dark:to-slate-950 border border-blue-100 dark:border-slate-800 p-6 md:py-8 md:px-8 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
                <div className="absolute top-[-30%] right-[-10%] w-[330px] h-[330px] rounded-full bg-blue-500/10 blur-[80px]" />
                <div className="z-10 text-center md:text-left min-w-0">
                  <span className="text-[10px] tracking-widest font-extrabold uppercase text-blue-600 dark:text-blue-400 font-display">
                    MY ACADEMIC RECORD
                  </span>
                  <h1 className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight mt-1">
                    Welcome back, {student.name}!
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                    Here is your current second-semester academic standing.
                  </p>
                </div>

                <div className="z-10 shrink-0 flex items-center gap-4 bg-white/70 dark:bg-[#1e293b]/70 backdrop-blur px-5 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center text-blue-600">
                    <TrendingUp className="w-5.5 h-5.5" />
                  </div>
                  <div>
                    <span className="text-[9px] font-extrabold text-slate-500 dark:text-slate-450 uppercase">Cumulative Target</span>
                    <h3 className="text-xl font-black text-blue-600 dark:text-blue-450 leading-none mt-0.5">4.0 GPA</h3>
                  </div>
                </div>
              </div>

              {/* SEARCH BOX FOR MOBILE AND TABLETS */}
              <div className="block sm:hidden relative">
                <span className="absolute inset-y-0 left-3.5 flex items-center text-slate-400 pointer-events-none">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter subjects..."
                  className="w-full bg-white dark:bg-[#1e293b]/40 border border-slate-200 dark:border-slate-800 rounded-full py-2 pl-10 pr-4 text-xs font-medium focus:outline-none focus:border-blue-500 text-slate-800 dark:text-slate-100"
                />
              </div>

              {/* DYNAMIC COURSES GRADES ARENA */}
              <div>
                <h2 className="text-xs font-black tracking-widest font-display text-blue-800 dark:text-blue-400 uppercase mb-4 pl-1">
                  COURSES GRADES (PRE-ESTABLISHED SUBJECT STATS)
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {filteredGrades.map((g) => (
                    <motion.div
                      key={g.subjectCode}
                      layoutId={`card-${g.subjectCode}`}
                      onClick={() => {}}
                      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[1.8rem] shadow-sm hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-all duration-300 overflow-hidden flex flex-col justify-between min-h-[280px] group/card hover:scale-[1.01] active:scale-95"
                    >
                      {/* Rich Gradient Top Banner for High Contrast Visuals */}
                      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 p-4 shrink-0 flex flex-col gap-1.5 shadow-sm">
                        <div className="flex justify-between items-center">
                          <span className="font-mono text-[9px] bg-white/20 text-white border border-white/25 px-2 py-0.5 rounded font-extrabold tracking-wide">
                            {g.subjectCode}
                          </span>
                          
                          <span className={`inline-flex items-center gap-1 text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                            g.status === 'Excellent' 
                              ? 'bg-emerald-500/20 text-emerald-100' 
                              : g.status === 'Good' 
                                ? 'bg-blue-500/20 text-blue-100' 
                                : g.status === 'Average' 
                                  ? 'bg-orange-500/20 text-orange-100' 
                                  : 'bg-red-500/20 text-red-100'
                          }`}>
                            <span className={`h-1.5 w-1.5 rounded-full ${
                              g.status === 'Excellent' ? 'bg-[#10B981]' : g.status === 'Good' ? 'bg-[#3B82F6]' : g.status === 'Average' ? 'bg-[#F59E0B]' : 'bg-[#EF4444]'
                            }`} />
                            {g.status}
                          </span>
                        </div>

                        <h3 className="font-extrabold text-[13px] sm:text-sm text-white tracking-tight leading-snug line-clamp-2 select-all">
                          {g.subjectName}
                        </h3>
                      </div>

                      {/* White Body content below */}
                      <div className="p-4 flex flex-col justify-between flex-grow gap-2.5 bg-white dark:bg-slate-900">
                        <div>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 font-bold flex items-center gap-1.5">
                            <span>Instructor:</span>
                            <span className="text-slate-800 dark:text-slate-200 font-black">{g.instructorName}</span>
                          </p>

                          {/* Grade values card inside */}
                          <div className="mt-3 p-3 bg-blue-500/[0.03] dark:bg-slate-800/40 rounded-2xl border border-blue-500/[0.05] dark:border-slate-800">
                            <div className="grid grid-cols-3 gap-1 text-center font-sans">
                              <div>
                                <span className="text-[8px] text-slate-400 dark:text-slate-500 uppercase font-bold block">Mark</span>
                                <span className="text-xs font-black text-slate-850 dark:text-slate-200">{g.totalMark}%</span>
                              </div>
                              <div>
                                <span className="text-[8px] text-slate-400 dark:text-slate-500 uppercase font-bold block">Grade</span>
                                <span className="text-xs font-black text-blue-650 dark:text-blue-400">{g.letterGrade}</span>
                              </div>
                              <div>
                                <span className="text-[8px] text-slate-400 dark:text-slate-500 uppercase font-bold block">GPA Pt</span>
                                <span className="text-xs font-black text-slate-850 dark:text-slate-200">{g.gpaPoint.toFixed(1)}</span>
                              </div>
                            </div>

                            {/* Progression slider representation */}
                            <div className="mt-3 font-sans">
                              <div className="flex justify-between items-center text-[8px] font-bold text-slate-400 dark:text-slate-500 mb-1">
                                <span>Syllabus Completion</span>
                                <span>{g.progress}%</span>
                              </div>
                              <div className="h-1 w-full bg-slate-200/50 dark:bg-slate-800 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-gradient-to-r from-blue-500 to-indigo-650 rounded-full" 
                                  style={{ width: `${g.progress}%` }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Card feet info credits */}
                        <div className="mt-1 flex justify-between items-center text-[9px] font-bold text-slate-400 select-none pb-2.5">
                          <span>Credits: {g.creditHours} hours</span>
                          <span>Pass Limit: &ge;50%</span>
                        </div>

                        {/* Grade result display (read-only) */}
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800/50">
                          <button
                            type="button"
                            className="w-full py-2 px-3 bg-slate-50 text-slate-400 font-extrabold text-[10px] rounded-xl flex items-center justify-center gap-1.5 border border-slate-100"
                            disabled
                          >
                            <span>Read-only Record</span>
                          </button>
                        </div>
                      </div>

                    </motion.div>
                  ))}
                  {filteredGrades.length === 0 && (
                    <div className="col-span-full p-8 text-center text-xs text-slate-500 bg-white/20 rounded-2xl border border-slate-200/20">
                      No courses found matching that criteria.
                    </div>
                  )}
                </div>
              </div>

              {/* FOUR INFORMATIVE STATS SUMMARY CARDS - RE-CALCULATING */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 pt-2">
                
                {/* Credits Card */}
                <div className="glass-panel hover:translate-y-0 rounded-[2rem] p-5 border border-emerald-400/20 bg-emerald-500/[0.04]">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[9px] font-black uppercase text-emerald-800 tracking-wider">Total Credit Hours</span>
                      <h4 className="text-3xl font-black text-emerald-900 mt-1">{totalCredits}</h4>
                      <p className="text-[10px] text-emerald-700 font-semibold mt-1">Required curriculum standard met.</p>
                    </div>
                    <div className="h-10 w-10 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-600">
                      <Layers className="w-5.5 h-5.5" />
                    </div>
                  </div>
                </div>

                {/* Passed Subjects Card */}
                <div className="glass-panel hover:translate-y-0 rounded-[2rem] p-5 border border-sky-400/20 bg-sky-500/[0.04]">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[9px] font-black uppercase text-sky-800 tracking-wider">Subject Courses Passed</span>
                      <h4 className="text-3xl font-black text-sky-900 mt-1">{passedCredits} Hrs</h4>
                      <p className="text-[10px] text-sky-700 font-semibold mt-1">
                        Passed {gradesArray.filter(g => g.totalMark >= 50).length} out of {gradesArray.length} classes.
                      </p>
                    </div>
                    <div className="h-10 w-10 rounded-2xl bg-sky-500/10 flex items-center justify-center text-sky-600">
                      <CheckCircle2 className="w-5.5 h-5.5" />
                    </div>
                  </div>
                </div>

                {/* At Academic Risk Card */}
                <div className="glass-panel hover:translate-y-0 rounded-[2rem] p-5 border border-red-400/20 bg-red-500/[0.04]">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[9px] font-black uppercase text-red-800 tracking-wider">Academic Risk Alerts</span>
                      <h4 className="text-3xl font-black text-red-900 mt-1">{atRiskCount}</h4>
                      <p className="text-[10px] text-red-700 font-semibold mt-1">
                        {atRiskCount > 0 ? "Urgent attention required in Physics." : "Splendid academic standing progress!"}
                      </p>
                    </div>
                    <div className={`h-10 w-10 rounded-2xl flex items-center justify-center ${atRiskCount > 0 ? 'bg-red-500/20 text-red-650' : 'bg-red-500/10 text-red-500'}`}>
                      <AlertCircle className="w-5.5 h-5.5" />
                    </div>
                  </div>
                </div>

                {/* Institutional Attendance Card with Progress Bar */}
                <div className="glass-panel hover:translate-y-0 rounded-[2rem] p-5 border border-indigo-400/20 bg-indigo-500/[0.04] flex flex-col justify-between">
                  <div className="flex justify-between items-start w-full gap-2">
                    <div className="space-y-1.5 w-full">
                      <span className="text-[9px] font-black uppercase text-indigo-800 tracking-wider block">Overall Attendance</span>
                      <div className="flex items-baseline gap-1.5 flex-wrap">
                        <h4 className="text-2xl sm:text-3xl font-black text-indigo-900">{(student.attendance ?? 95.0).toFixed(1)}%</h4>
                        <span className={`text-[9px] font-black uppercase ${(student.attendance ?? 95.0) >= 85 ? 'text-emerald-600' : 'text-red-500'}`}>
                          {(student.attendance ?? 95.0) >= 85 ? '✓ Good' : '⚠️ Warning'}
                        </span>
                      </div>
                      
                      {/* Attendance progress bar inside the card */}
                      <div className="pt-1 select-none">
                        <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              (student.attendance ?? 95.0) >= 90 
                                ? 'bg-emerald-500' 
                                : (student.attendance ?? 95.0) >= 85 
                                ? 'bg-indigo-500' 
                                : 'bg-red-500 animate-pulse'
                            }`}
                            style={{ width: `${Math.min(100, student.attendance ?? 95.0)}%` }}
                          />
                        </div>
                      </div>
                      
                      <p className="text-[9px] text-indigo-700 font-semibold pt-0.5 leading-snug">
                        Academy limit: &ge;85.0%
                      </p>
                    </div>
                    <div className="h-10 w-10 shrink-0 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-600">
                      <Calendar className="w-5.5 h-5.5" />
                    </div>
                  </div>
                </div>

              </div>

              {/* SECTIONS: CUMULATIVE GPA PROGRESS WITH DIAL + TREND GRAPHICS */}
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 pt-2">
                
                {/* Left Section: Circular GPA Progress dial */}
                <div className="lg:col-span-2 glass-panel rounded-[2rem] p-6 text-center flex flex-col justify-between relative overflow-hidden">
                  <div className="absolute top-[-30%] left-[-20%] w-60 h-60 rounded-full bg-blue-500/5 blur-[50px]" />
                  
                  <div>
                    <span className="text-[10px] tracking-widest font-extrabold uppercase text-blue-600 dark:text-blue-400 font-display block">
                      GPA PERFORMANCE INDEX
                    </span>
                    <h3 className="text-base font-black text-slate-800 dark:text-slate-200 tracking-tight mt-1">Cumulative GPA standing</h3>
                  </div>

                  {/* Circular Dial Representation */}
                  <div className="relative w-40 h-40 mx-auto my-6 flex items-center justify-center">
                    
                    {/* SVG Progress Circle wrapper */}
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      <circle 
                        className="text-blue-100/30 dark:text-slate-800/30" 
                        strokeWidth="8" 
                        stroke="currentColor" 
                        fill="transparent" 
                        r="36" 
                        cx="50" 
                        cy="50" 
                      />
                      <motion.circle 
                        className="text-blue-600 dark:text-blue-450" 
                        strokeWidth="8" 
                        strokeDasharray={`${2.2619 * 100}`}
                        initial={{ strokeDashoffset: 2.2619 * 100 }}
                        animate={{ strokeDashoffset: 2.2619 * (100 - (gpa / 4.0) * 100) }}
                        transition={{ duration: 1.5, ease: 'easeOut' }}
                        strokeLinecap="round" 
                        stroke="currentColor" 
                        fill="transparent" 
                        r="36" 
                        cx="50" 
                        cy="50" 
                      />
                    </svg>

                    {/* Centered Dial text */}
                    <div className="absolute text-center flex flex-col justify-center select-none leading-none">
                      <span className="text-4xl font-black text-slate-800 dark:text-slate-100">{gpa.toFixed(2)}</span>
                      <span className="text-[9px] uppercase font-bold text-slate-400 dark:text-slate-500 mt-1 tracking-wider">Out of 4.0</span>
                    </div>

                  </div>

                  {/* High standing academic badge */}
                  <div className="space-y-2">
                    <span className="inline-flex items-center gap-1 px-4.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-300/30 text-[11px] font-black tracking-wide text-blue-700 dark:text-blue-400 uppercase font-display mx-auto">
                      <Award className="w-4 h-4 text-blue-500 animate-pulse" />
                      {rating}
                    </span>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold px-2">
                      Your high GPA of {gpa} marks you ready for preparatory university entrance qualifiers. Continue the high academic rigor!
                    </p>
                  </div>

                </div>

                {/* Right Section: Core Vector Trend Graphic */}
                <div className="lg:col-span-3 glass-panel rounded-[2rem] p-6 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] tracking-widest font-extrabold uppercase text-blue-600 dark:text-blue-400 font-display block">
                      SEMESTER PERFORMANCE TRENDS
                    </span>
                    <h3 className="text-base font-black text-slate-800 dark:text-slate-200 tracking-tight mt-1">SVG Academic Distribution Chart</h3>
                  </div>

                  {/* Native SVG responsive chart container */}
                  <div className="relative h-44 w-full flex items-end pt-4 select-none px-2.5">
                    
                    {/* SVG Area chart */}
                    <svg className="absolute inset-0 h-full w-full pointer-events-none" viewBox="0 0 400 150">
                      {/* Grid background lines */}
                      <path d="M0,30 L400,30" stroke="rgba(148, 163, 184, 0.15)" strokeWidth="1" strokeDasharray="4,4" />
                      <path d="M0,75 L400,75" stroke="rgba(148, 163, 184, 0.15)" strokeWidth="1" strokeDasharray="4,4" />
                      <path d="M0,120 L400,120" stroke="rgba(148, 163, 184, 0.15)" strokeWidth="1" strokeDasharray="4,4" />
                      
                      {/* Gold fill gradient area chart */}
                      <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#2563eb" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="#2563eb" stopOpacity="0.0" />
                      </linearGradient>
                      
                      <path 
                        d="M 10 130 Q 80 40 150 95 T 300 25 T 390 10 L 390 150 L 10 150 Z" 
                        fill="url(#chartGradient)" 
                        stroke="none" 
                      />
                      
                      {/* Glowing Line string path */}
                      <path 
                        d="M 10 130 Q 80 40 150 95 T 300 25 T 390 10" 
                        fill="none" 
                        stroke="#2563eb" 
                        strokeWidth="3.5" 
                        strokeLinecap="round"
                      />
                      
                      {/* Floating glowing circle pointers */}
                      <circle cx="10" cy="130" r="4.5" fill="#2563eb" stroke="white" strokeWidth="2" />
                      <circle cx="85" cy="45" r="4.5" fill="#2563eb" stroke="white" strokeWidth="2" />
                      <circle cx="150" cy="95" r="4.5" fill="#2563eb" stroke="white" strokeWidth="2" />
                      <circle cx="300" cy="25" r="4.5" fill="#38bdf8" stroke="white" strokeWidth="2" />
                      <circle cx="390" cy="10" r="5" fill="#2563eb" stroke="white" strokeWidth="2.5" />
                    </svg>

                    {/* Chart axis keys layout */}
                    <div className="absolute inset-x-0 bottom-0 flex justify-between text-[8.5px] font-bold text-slate-500 uppercase pointer-events-none px-1">
                      <span>Term 1 Entry</span>
                      <span>Midterms</span>
                      <span>Term 1 Finals</span>
                      <span>Term 2 Mid</span>
                      <span>Current Stan.</span>
                    </div>

                  </div>

                  {/* Bottom descriptive indicators */}
                  <div className="border-t border-slate-200 dark:border-slate-800 xl:flex justify-between items-center pt-3 text-[10.5px] font-semibold text-slate-500 dark:text-slate-400 space-y-1 xl:space-y-0">
                    <p>Highest Class Score Achieved: <span className="font-extrabold text-blue-600 dark:text-blue-400">97% (Web Development)</span></p>
                    <div className="flex gap-3 text-[9.5px]">
                      <span className="flex items-center gap-1">
                        <span className="h-2 w-2 rounded-full bg-blue-500" /> Current Term
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="h-2 w-2 rounded-full bg-emerald-500" /> Target GPA
                      </span>
                    </div>
                  </div>

                </div>

              </div>

            </motion.div>
          )}

          {/* VIEWPORT 2: MY REPORT (PRINTABLE HIGH QUALITY TRANSCRIPT) */}
          {activeTab === 'Transcript' && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Instructions Callout bar */}
              <div className="no-print bg-blue-50/60 border border-blue-200/30 p-4.5 rounded-[1.8rem] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs font-semibold leading-relaxed">
                <div>
                  <span className="font-extrabold text-blue-900">Certificate Verification Platform</span>
                  <p className="text-slate-600 text-[10.5px] mt-0.5 font-medium">To prepare this record for formal academic submissions, click print to load standard ISO A4 margins formatting.</p>
                </div>
                <div className="flex flex-wrap gap-2 shrink-0">
                  <button
                    onClick={handleDownloadTranscriptFile}
                    className="flex items-center gap-1.5 py-2.5 px-5 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-750 hover:to-blue-800 active:scale-95 transition-all text-white font-extrabold rounded-full shadow shadow-blue-800/20 cursor-pointer text-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Certificate (HTML File)</span>
                  </button>
                  <button
                    onClick={handlePrintTranscript}
                    className="flex items-center gap-1.5 py-2.5 px-5 bg-blue-500 hover:bg-blue-600 active:scale-95 transition-all text-white font-extrabold rounded-full shadow shadow-blue-850/10 border border-blue-400 cursor-pointer text-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Print PDF Copy</span>
                  </button>
                </div>
              </div>

              {/* TRANSCRIPT PAGE PANEL (A4 PROPORTIONAL CARD) */}
              <div className="print-page max-w-3xl mx-auto bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl p-6 sm:p-11 relative overflow-hidden text-neutral-800 font-sans">
                
                {/* Visual Watermarked Crest Logo Background explicitly requested */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-[0.035] select-none">
                  <img src={crestLogo} alt="Watermark" className="w-[450px] h-[450px] object-cover" referrerPolicy="no-referrer" />
                </div>

                {/* Outer Traditional Certificate Borderlines */}
                <div className="absolute inset-4 border border-blue-100/60 rounded-[2rem] pointer-events-none" />
                <div className="absolute inset-5 border-2 border-double border-blue-200/40 rounded-[1.8rem] pointer-events-none" />

                {/* TRANSCRIPT HEADER */}
                <div className="relative flex flex-col md:flex-row justify-between items-center md:items-start gap-4 pb-6 border-b-2 border-slate-200/60 z-10">
                  
                  <div className="flex items-center gap-4 text-center md:text-left flex-col md:flex-row">
                    <div className="w-20 h-20 rounded-2xl bg-white p-1.5 ml-0.5 shadow-sm border border-blue-200/50">
                      <img src={crestLogo} alt="Institutional Crest" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div>
                      <h1 className="text-xl font-extrabold text-[#1e40af] tracking-tight leading-none">ADDIS KETEMA PREPARATORY SCHOOL</h1>
                      <span className="text-[10px] tracking-widest font-bold text-blue-700/80 uppercase block mt-1">Academic Transcript of Records</span>
                      <p className="text-[9px] text-slate-500 mt-0.5">Under Ministry of Education, Federal Democratic Republic of Ethiopia</p>
                    </div>
                  </div>

                  <div className="text-center md:text-right text-[10.5px] font-semibold text-slate-500">
                    <p>Transcript ID: <span className="font-mono font-bold text-slate-800">AK-2026-TR842</span></p>
                    <p className="mt-0.5">Verification Key: <span className="font-mono text-xs font-bold text-slate-800">MOE-4428-AABP</span></p>
                    <p className="mt-0.5 text-[9px] text-slate-400">Issue Date: May 30, 2026</p>
                  </div>

                </div>

                {/* STUDENT INFO MATRICULATION BLOCK */}
                <div className="relative mt-5 grid grid-cols-2 md:grid-cols-4 gap-4 p-4.5 bg-slate-50 rounded-2xl border border-slate-200/60 text-[11px] font-medium text-slate-700 leading-relaxed z-10 select-none">
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">FULL NAME</span>
                    <span className="font-extrabold text-slate-800">{student.name}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">STUDENT ID</span>
                    <span className="font-mono font-extrabold text-slate-800">{student.studentId}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">EMAIL CONTACT</span>
                    <span className="font-extrabold text-slate-800 truncate block">{student.email}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">ACADEMIC LEVEL</span>
                    <span className="font-extrabold text-slate-800">{student.academicLevel.split(' ')[0]} Entry</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">ACADEMIC TERM</span>
                    <span className="font-extrabold text-slate-800">2025/2026 Term 2</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">CUMULATIVE GPA</span>
                    <span className="font-black text-blue-700">{gpa.toFixed(2)} / 4.00</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">CREDITS ACHIEVED</span>
                    <span className="font-extrabold text-slate-800">{totalCredits} credits</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-400 uppercase font-black block">STATUS STATEMENT</span>
                    <span className="font-extrabold px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-850 text-[9.5px]">Excellent Passed</span>
                  </div>
                </div>

                {/* CERTIFICATE TABLE */}
                <div className="relative overflow-x-auto mt-6 z-10 select-none">
                  
                  <table className="w-full text-left border-collapse text-[10.5px] font-medium text-slate-700">
                    <thead>
                      <tr className="border-b border-slate-200 text-blue-700 text-[10px] uppercase font-black">
                        <th className="py-2.5 px-3">Subject Code</th>
                        <th className="py-2.5 px-2">Course Name</th>
                        <th className="py-2.5 px-2 text-center">Assignments</th>
                        <th className="py-2.5 px-1 text-center">Quizzes</th>
                        <th className="py-2.5 px-2 text-center">Exams</th>
                        <th className="py-2.5 px-2 text-center">Total Mark</th>
                        <th className="py-2.5 px-2 text-center">GPA Point</th>
                        <th className="py-2.5 px-3 text-right">Letter Grade</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {gradesArray.map((g) => (
                        <tr key={g.subjectCode} className="hover:bg-blue-500/5 transition-colors">
                          <td className="py-3 px-3 font-mono font-bold text-blue-700">{g.subjectCode}</td>
                          <td className="py-3 px-2 font-black text-slate-800">{g.subjectName}</td>
                          <td className="py-3 px-2 text-center text-slate-500">{g.assignments} / 30</td>
                          <td className="py-3 px-1 text-center text-slate-500">{g.quizzes} / 20</td>
                          <td className="py-3 px-2 text-center text-slate-500">{g.exams} / 50</td>
                          <td className="py-3 px-2 text-center font-bold text-slate-800">{g.totalMark}%</td>
                          <td className="py-3 px-2 text-center font-bold text-slate-800">{g.gpaPoint.toFixed(1)}</td>
                          <td className="py-3 px-3 text-right">
                            <span className={`inline-block font-extrabold text-sm ${g.totalMark >= 75 ? 'text-green-600' : g.totalMark >= 50 ? 'text-slate-600' : 'text-red-500'}`}>
                              {g.letterGrade}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                </div>

                {/* GRADE LEGEND KEY */}
                <div className="relative mt-6 pt-5 border-t border-slate-200 z-10 select-none">
                  <span className="text-[8.5px] tracking-wider font-extrabold text-blue-800 uppercase block mb-2">
                    Official Grading Key Scale Legend
                  </span>
                  
                  <div className="flex justify-between flex-wrap gap-2 text-[9.5px] text-slate-500 leading-relaxed font-semibold">
                    <span><strong className="text-slate-800 font-extrabold">A+ / A:</strong> 80%-100% (4.0 Pt / Excellent)</span>
                    <span><strong className="text-slate-800 font-extrabold">B+ / B:</strong> 65%-79.9% (3.0-3.5 Pt / Good)</span>
                    <span><strong className="text-slate-800 font-extrabold">C+ / C:</strong> 50%-64.9% (2.0-2.5 Pt / Average)</span>
                    <span><strong className="text-slate-800 font-extrabold">D:</strong> 40%-49.9% (1.0 Pt / Below Progress)</span>
                    <span><strong className="text-slate-800 font-extrabold">F:</strong> &lt;40% (0.0 Pt / Failing Grade)</span>
                  </div>
                </div>

                {/* DIGITAL SIGNATURES AND SEALS AREA */}
                <div className="relative mt-8 grid grid-cols-2 sm:grid-cols-3 gap-6 items-end z-10 select-none border-t border-slate-200/20 pt-4">
                  
                  {/* Instructor Signature wrap */}
                  <div className="text-center">
                    <div className="h-10 flex items-center justify-center font-display italic text-base font-bold text-slate-850 border-b border-dashed border-slate-300">
                      <Signature className="w-5 h-5 text-blue-600 inline mr-1 opacity-60" />
                      M. Alazar
                    </div>
                    <span className="text-[8.5px] font-black uppercase text-slate-500 block mt-1.5">Class Instructor Sign</span>
                    <p className="text-[7.5px] text-slate-400">Prof. Martha Alazar</p>
                  </div>

                  {/* Director's Signature wrap */}
                  <div className="text-center">
                    <div className="h-10 flex items-center justify-center font-display italic text-base font-bold text-slate-850 border-b border-dashed border-slate-300">
                      <Signature className="w-5 h-5 text-blue-600 inline mr-1 opacity-60" />
                      A. Hailu
                    </div>
                    <span className="text-[8.5px] font-black uppercase text-slate-500 block mt-1.5">Academic Director Sign</span>
                    <p className="text-[7.5px] text-slate-400">Dean Abraham Hailu</p>
                  </div>

                  {/* QR code verification seal */}
                  <div className="col-span-2 sm:col-span-1 flex flex-col items-center justify-center">
                    <div className="p-1.5 border-2 border-blue-200 rounded-xl bg-blue-50/20 flex flex-col items-center justify-center shadow-inner text-blue-850">
                      <QrCode className="w-12 h-12" />
                      <span className="text-[7px] font-extrabold uppercase tracking-wide mt-1 select-none">Verify on blockchain</span>
                    </div>
                    <span className="text-[7.5px] font-black uppercase text-slate-500 mt-1">Official Academy Stamp</span>
                  </div>

                </div>

              </div>
            </motion.div>
          )}

          {/* VIEWPORT 3: PROFILE SETTINGS EDITOR - SAVING TO DATABASE SIMULATION */}
          {activeTab === 'Profile' && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-2xl mx-auto space-y-6"
            >
              <div className="glass-panel rounded-[2rem] p-6 text-slate-850 dark:text-slate-100">
                <div className="flex justify-between items-center pb-5 border-b border-slate-200 dark:border-slate-850">
                  <div>
                    <h2 className="text-xl font-black text-slate-850 dark:text-slate-100">Personal Academy Registration</h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Manage details stored inside terminal databases.</p>
                  </div>
                  <UserCog className="w-6 h-6 text-blue-600" />
                </div>

                {profileSuccessMsg && (
                  <div className="mt-4 p-3 rounded-2xl bg-emerald-500/10 text-emerald-800 text-xs font-bold flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>{profileSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleProfileSave} className="mt-6 space-y-5">
                  
                  {/* Photo Edit Row */}
                  <div className="flex items-center gap-5">
                    <div 
                      onClick={() => setIsAvatarModalOpen(true)}
                      className="relative group overflow-hidden rounded-full w-20 h-20 border-4 border-blue-500/30 hover:border-blue-500/60 shrink-0 select-none cursor-pointer group transition-all"
                      title="Click to take photo with camera or upload image"
                    >
                      <img src={picUrl} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-black/45 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Camera className="w-5 h-5 text-white" />
                      </div>
                    </div>

                    <div className="flex-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 uppercase mb-1">
                        Profile Avatar Picture
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsAvatarModalOpen(true)}
                        className="text-left w-full bg-white dark:bg-[#1e293b]/50 hover:bg-slate-50 dark:hover:bg-[#1e293b]/80 border border-slate-200 dark:border-slate-800 rounded-full py-2 px-4 text-xs font-semibold focus:outline-none focus:border-blue-500 text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Camera className="w-3.5 h-3.5" />
                        Take Photo with Camera / Select Image File
                      </button>
                    </div>
                  </div>

                  {/* Reusable Camera Modal */}
                  <AvatarCameraModal
                    isOpen={isAvatarModalOpen}
                    onClose={() => setIsAvatarModalOpen(false)}
                    onSave={(newPic) => {
                      setPicUrl(newPic);
                      setIsAvatarModalOpen(false);
                    }}
                    currentAvatar={picUrl}
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Name */}
                    <div>
                      <label className="block text-xs font-bold text-slate-705 dark:text-slate-200 uppercase mb-1 pl-1">
                        Full Name Statement
                      </label>
                      <input
                        id="name-input"
                        type="text"
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        className="w-full bg-white dark:bg-[#1e293b]/50 border border-slate-200 dark:border-slate-800 rounded-full py-2 px-4 text-xs font-medium focus:outline-none focus:border-blue-500 text-slate-800 dark:text-slate-100"
                        required
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block text-xs font-bold text-slate-705 dark:text-slate-200 uppercase mb-1 pl-1">
                        Academy Registration Email
                      </label>
                      <input
                        id="email-input"
                        type="email"
                        value={profileEmail}
                        onChange={(e) => setProfileEmail(e.target.value)}
                        className="w-full bg-white dark:bg-[#1e293b]/50 border border-slate-200 dark:border-slate-800 rounded-full py-2 px-4 text-xs font-medium focus:outline-none focus:border-blue-500 text-slate-800 dark:text-slate-100"
                        required
                      />
                    </div>

                    {/* Class term constant */}
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1 pl-1 select-none">
                        Student Matriculation ID (Immutable)
                      </label>
                      <input
                        type="text"
                        value={student.studentId}
                        disabled
                        className="w-full bg-slate-100/30 dark:bg-slate-900/30 border border-slate-200/30 rounded-full py-2 px-4 text-xs font-medium font-mono text-slate-500 cursor-not-allowed"
                      />
                    </div>

                    {/* Level term constant */}
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-1 pl-1 select-none">
                        Academic Standing Placement (Immutable)
                      </label>
                      <input
                        type="text"
                        value={student.academicLevel}
                        disabled
                        className="w-full bg-slate-100/30 dark:bg-slate-900/30 border border-slate-200/30 rounded-full py-2 px-4 text-xs font-medium text-slate-500 cursor-not-allowed"
                      />
                    </div>

                  </div>

                  {/* Parent Details */}
                  <div className="p-4 rounded-3xl bg-blue-500/5 border border-blue-300/20 space-y-3">
                    <span className="text-[10px] tracking-wider font-extrabold text-blue-800 dark:text-blue-400 uppercase block">
                      Emergency Parent Relations Data
                    </span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 uppercase mb-1 pl-1">
                          Parent / Guardian Name
                        </label>
                        <input
                          id="parent-name-input"
                          type="text"
                          value={parentName}
                          onChange={(e) => setParentName(e.target.value)}
                          className="w-full bg-white dark:bg-[#1e293b]/50 border border-slate-200 dark:border-slate-800 rounded-full py-2 px-4 text-xs font-medium focus:outline-none focus:border-blue-500 text-slate-800 dark:text-slate-100"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 dark:text-slate-200 uppercase mb-1 pl-1">
                          Emergency Contact Number
                        </label>
                        <input
                          id="parent-contact-input"
                          type="text"
                          value={parentContact}
                          onChange={(e) => setParentContact(e.target.value)}
                          className="w-full bg-white dark:bg-[#1e293b]/50 border border-slate-200 dark:border-slate-800 rounded-full py-2 px-4 text-xs font-medium focus:outline-none focus:border-blue-500 text-slate-800 dark:text-slate-100"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Submit buttons */}
                  <div className="flex justify-end pt-3">
                    <button
                      type="submit"
                      className="py-2.5 px-6 rounded-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-extrabold text-xs tracking-wide hover:from-blue-700 hover:to-blue-850 active:scale-95 transition-all shadow shadow-blue-800/10 cursor-pointer"
                    >
                      Save Profile Changes
                    </button>
                  </div>

                </form>
                <AvatarCameraModal 
                  isOpen={isAvatarModalOpen}
                  onClose={() => setIsAvatarModalOpen(false)}
                  onSave={(newPic) => {
                    setPicUrl(newPic);
                    setIsAvatarModalOpen(false);
                  }}
                  currentAvatar={picUrl}
                />

              </div>
            </motion.div>
          )}

        </div>

      </main>

    </div>
  );
}
