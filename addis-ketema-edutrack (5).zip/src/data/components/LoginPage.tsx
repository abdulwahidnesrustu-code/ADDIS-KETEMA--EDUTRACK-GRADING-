/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserSquare, ShieldCheck, GraduationCap, BookOpen, Lock, Mail, Eye, EyeOff, ArrowRight, Info, CheckCircle2, Gem, Activity, AlertTriangle } from 'lucide-react';
import { UserRole, Teacher } from '../types';
import crestLogo from '../assets/images/addis_ketema_logo_1780404658947.png';
import { loginDemo, getStoredStudents, saveStoredStudents, getStoredTeachers, saveStoredTeachers, createDefaultGradesForAllSubjects } from '../data/mockData';


interface LoginPageProps {
  onLoginSuccess: (user: any, role: UserRole) => void;
}

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  // Role selector state
  const [selectedRole, setSelectedRole] = useState<UserRole>('Student');
  
  // Credentials
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  // Registration States
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [fullName, setFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('Student');
  const [academicLevel, setAcademicLevel] = useState('Grade 12 - Senior Academy');
  const [subjectCode, setSubjectCode] = useState('CHE-103');
  const [adminTitle, setAdminTitle] = useState('Academic Coordinator');

  // UX UI UI Effects
  const [isLoading, setIsLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0); // 0 to 4
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('info');
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  // Initialize demo accounts based on selected role to make testing extremely easy!
  useEffect(() => {
    if (selectedRole === 'Student') {
      setEmail('student@gmail.com');
      setPassword('password123');
    } else if (selectedRole === 'Teacher') {
      setEmail('teacher@gmail.com');
      setPassword('password123');
    } else {
      setEmail('admin@gmail.com');
      setPassword('password123');
    }
    setErrors({});
  }, [selectedRole]);

  // Handle password strength estimation
  useEffect(() => {
    let score = 0;
    if (password.length > 0) {
      if (password.length >= 6) score += 1;
      if (/[A-Z]/.test(password)) score += 1;
      if (/[0-9]/.test(password)) score += 1;
      if (/[^A-Za-z0-9]/.test(password)) score += 1;
    }
    setPasswordStrength(score);
  }, [password]);

  const triggerToast = (msg: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password) {
      triggerToast("Email and password are required.", "error");
      return;
    }

    setIsLoading(true);

    // Mock login bypass for demo credentials
    const students = getStoredStudents();
    const teachers = getStoredTeachers();

    const isDemo = ['student@gmail.com', 'teacher@gmail.com', 'admin@gmail.com'].includes(email.toLowerCase());
    const isRegisteredStudent = students.find(s => s.email.toLowerCase() === email.toLowerCase());
    const isRegisteredTeacher = teachers.find(t => t.email.toLowerCase() === email.toLowerCase());
    
    if ((isDemo && password === 'password123') || isRegisteredStudent || isRegisteredTeacher) {
       console.log("LoginPage: Using mock login for user", email);
       let role: UserRole = 'Student';
       if (isRegisteredTeacher) role = 'Teacher';
       else if (isDemo && email.toLowerCase() === 'teacher@gmail.com') role = 'Teacher';
       else if (isDemo && email.toLowerCase() === 'admin@gmail.com') role = 'Admin';
       else role = 'Student';

       const mockUser = {
           id: `demo-${email}`,
           email: email,
           user_metadata: { role }
       };
       onLoginSuccess(mockUser, role);
       setIsLoading(false);
       return;
    }

    /*
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    setIsLoading(false);

    if (error) {
      console.error("Supabase Auth Error:", error);
      triggerToast(error.message, "error");
    } else {
      triggerToast(`Authenticated successfully! Redirecting...`, 'success');
      
      const { data: profile } = await supabase
         .from('profiles')
         .select('*')
         .eq('id', data.user.id)
         .single();
         
      const role = profile?.role || data.user.user_metadata.role || 'Student';

      if (rememberMe) {
        localStorage.setItem('ak_remember_user', JSON.stringify({ email, role }));
      } else {
        localStorage.removeItem('ak_remember_user');
      }
        
      setTimeout(() => {
        onLoginSuccess(profile || data.user, role);
      }, 1000);
    }
    */
    setIsLoading(false);
    triggerToast("In demo mode, please use provided credentials.", "error");

  };



  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !regEmail || !regPassword) {
      triggerToast("Please fill all fields.", "error");
      return;
    }

    setIsLoading(true);
    
    if (regRole === 'Student') {
        const newStudent = {
          id: `student-${Date.now()}`,
          name: fullName,
          email: regEmail,
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200&h=200',
          studentId: `AK/${new Date().getFullYear()}/${Math.floor(1000 + Math.random() * 9000)}`,
          academicLevel: academicLevel,
          semester: 'Sem 2',
          parentName: 'Not Provided',
          parentContact: 'Not Provided',
          joinedDate: new Date().toISOString(),
          grades: createDefaultGradesForAllSubjects(),
          attendance: 90
        };

        const students = getStoredStudents();
        saveStoredStudents([...students, newStudent]);
    } else if (regRole === 'Teacher') {
        const newTeacher: Teacher = {
            id: `teacher-${Date.now()}`,
            name: fullName,
            email: regEmail,
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200',
            teacherId: `AK/STAFF/${subjectCode}-${Math.floor(100 + Math.random() * 900)}`,
            subjectCode: subjectCode,
            subjectName: subjectCode === 'CHE-103' ? 'General Chemistry' : subjectCode === 'MAT-102' ? 'Advanced Mathematics' : 'English Literature',
            classes: ['Grade 12 - Senior Academy']
        };
        const teachers = getStoredTeachers();
        saveStoredTeachers([...teachers, newTeacher]);
    }

    setIsLoading(false);
    triggerToast(`Account created successfully for ${fullName}!`, "success");
    setIsRegisterMode(false);
    setRegEmail('');
    setRegPassword('');
    setFullName('');
  };

  const handleQuickRoles = (role: UserRole) => {
    setSelectedRole(role);
    triggerToast(`Switched login focus to ${role} Role`, 'info');
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center py-12 px-4 md:px-6 overflow-hidden bg-gradient-to-br from-[#f9f3e8] via-[#fff5e9] to-[#fef7e0]">
      
      {/* radial background visual blobs requested explicitly */}
      {/* Orb 1 (Top Left) */}
      <div 
        className="absolute rounded-full pointer-events-none filter blur-[70px] bg-gradient-to-r from-[#ffd89b] to-[#f9c45a]"
        style={{
          width: '500px',
          height: '500px',
          top: '-180px',
          left: '-150px',
          opacity: 0.4
        }}
      />
      
      {/* Orb 2 (Bottom Right) */}
      <div 
        className="absolute rounded-full pointer-events-none filter blur-[70px] bg-gradient-to-r from-[#b6e2f5] to-[#a0cfee]"
        style={{
          width: '550px',
          height: '550px',
          bottom: '-200px',
          right: '-150px',
          opacity: 0.35
        }}
      />

      {/* Orb 3 (Mid Right) */}
      <div 
        className="absolute rounded-full pointer-events-none filter blur-[90px] bg-[#ffe2b5]"
        style={{
          width: '300px',
          height: '300px',
          top: '30%',
          right: '5%',
          opacity: 0.5
        }}
      />

      <div className="w-full max-w-[560px] z-10 flex flex-col items-center">
        
        {/* Main Card */}
        <div id="login-main-card" className="glass-panel w-full rounded-[3rem] px-5 py-8 sm:p-[2.5rem_2.5rem_3rem] relative shadow-[0_20px_60px_-15px_rgba(0,0,0,0.25)] ring-1 ring-white/70">
          
          {/* Logo & Header Section */}
          <div className="flex flex-col items-center text-center">
            
            {/* Crest Container */}
            <div className="w-40 h-40 rounded-[2.5rem] bg-gradient-to-br from-white to-[#fff9f0] shadow-md border border-amber-200/50 flex items-center justify-center p-1 mb-3 group-hover:scale-105 transition-all">
              <img 
                src={crestLogo} 
                alt="Academy Crest Logo" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.currentTarget;
                  target.style.display = 'none';
                  const parent = target.parentElement;
                  if (parent) {
                    const fallback = document.createElement('div');
                    fallback.className = 'w-full h-full rounded-[20px] bg-gradient-to-br from-amber-600 to-amber-700 flex items-center justify-center text-white';
                    fallback.innerHTML = `
                      <svg class="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
                        <path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"/>
                      </svg>
                    `;
                    parent.appendChild(fallback);
                  }
                }}
              />
            </div>

            {/* School Name Text */}
            <h2 className="text-2xl sm:text-[1.9rem] font-extrabold tracking-tight leading-none text-center font-display mt-1">
              <span className="text-academy-clip block">ADDIS KETEMA</span>
              <span className="text-amber-700/80 tracking-[0.25em] text-xs font-bold block mt-1">EDUTRACK</span>
            </h2>

            {/* Subtitle Badge and Metadata Row */}
            <div className="flex flex-col items-center gap-1.5 mt-3">
              <span className="inline-flex items-center px-3 py-0.5 rounded-full bg-[#fff1e0] text-[#b37b2e] text-[10px] font-extrabold tracking-wide uppercase border border-amber-200/30">
                AKPS • TRACK EXCELLENCE
              </span>
              
              <div className="flex items-center gap-1.5 text-[#aa7b4a] text-[11px] font-semibold mt-1">
                <BookOpen className="w-3.5 h-3.5 text-amber-500" />
                <span>Knowledge is Power</span>
                <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
                <Activity className="w-3.5 h-3.5 text-amber-500" />
                <span>Addis Ketema Academy</span>
              </div>
            </div>

            {/* Welcome message styling */}
            <div className="mt-6 flex flex-col items-center">
              <div className="inline-flex items-center gap-1.5 text-gold-clip font-bold text-base sm:text-[1.65rem] capitalize font-display">
                <Gem className="w-4 h-4 text-amber-500 inline" />
                welcome to portal
              </div>
              <p className="text-xs font-medium text-[#976b3c] mt-1 tracking-wide">
                Sign in with your role — redirect to your dashboard
              </p>
            </div>
          </div>

          {/* Role selector layout */}
          <div className="mt-6">
            <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-2.5 text-center">
              Choose System Role Access
            </label>
            <div className="flex flex-row gap-2.5 justify-center flex-wrap sm:flex-nowrap">
              
              {/* Role Card Student */}
              <button
                type="button"
                onClick={() => handleQuickRoles('Student')}
                className={`flex-1 min-w-[100px] sm:min-w-[115px] p-3 rounded-2xl flex flex-col items-center text-center transition-all duration-300 border cursor-pointer ${
                  selectedRole === 'Student'
                    ? 'bg-orange-50 border-amber-500 shadow-md ring-1 ring-amber-400 translate-y-[-3px]'
                    : 'bg-[#fffdfa]/70 hover:bg-orange-50/40 border-amber-200/40 hover:border-amber-300'
                }`}
              >
                <div className={`p-2 rounded-xl mb-1.5 ${selectedRole === 'Student' ? 'bg-amber-100 text-amber-600' : 'bg-amber-50/50 text-[#b97f3a]'}`}>
                  <GraduationCap className="w-7 h-7" />
                </div>
                <span className="font-bold text-[13px] sm:text-[1.1rem] text-[#734b1f]">Student</span>
                <span className="text-[10px] text-[#7e582e] mt-0.5 font-medium">Learning</span>
              </button>

              {/* Role Card Teacher */}
              <button
                type="button"
                onClick={() => handleQuickRoles('Teacher')}
                className={`flex-1 min-w-[100px] sm:min-w-[115px] p-3 rounded-2xl flex flex-col items-center text-center transition-all duration-300 border cursor-pointer ${
                  selectedRole === 'Teacher'
                    ? 'bg-orange-50 border-amber-500 shadow-md ring-1 ring-amber-400 translate-y-[-3px]'
                    : 'bg-[#fffdfa]/70 hover:bg-orange-50/40 border-amber-200/40 hover:border-amber-300'
                }`}
              >
                <div className={`p-2 rounded-xl mb-1.5 ${selectedRole === 'Teacher' ? 'bg-amber-100 text-amber-600' : 'bg-amber-50/50 text-[#b97f3a]'}`}>
                  <UserSquare className="w-7 h-7" />
                </div>
                <span className="font-bold text-[13px] sm:text-[1.1rem] text-[#734b1f]">Teacher</span>
                <span className="text-[10px] text-[#7e582e] mt-0.5 font-medium">Academics</span>
              </button>

              {/* Role Card Admin */}
              <button
                type="button"
                onClick={() => handleQuickRoles('Admin')}
                className={`flex-1 min-w-[100px] sm:min-w-[115px] p-3 rounded-2xl flex flex-col items-center text-center transition-all duration-300 border cursor-pointer ${
                  selectedRole === 'Admin'
                    ? 'bg-orange-50 border-amber-500 shadow-md ring-1 ring-amber-400 translate-y-[-3px]'
                    : 'bg-[#fffdfa]/70 hover:bg-orange-50/40 border-amber-200/40 hover:border-amber-300'
                }`}
              >
                <div className={`p-2 rounded-xl mb-1.5 ${selectedRole === 'Admin' ? 'bg-amber-100 text-amber-600' : 'bg-amber-50/50 text-[#b97f3a]'}`}>
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <span className="font-bold text-[13px] sm:text-[1.1rem] text-[#734b1f]">Admin</span>
                <span className="text-[10px] text-[#7e582e] mt-0.5 font-medium">Management</span>
              </button>

            </div>
          </div>

          {/* Tab Selector Sign In vs Register */}
          <div className="flex bg-[#fffdfa]/60 p-1 rounded-2xl border border-amber-200/40 select-none mb-5">
            <button
              type="button"
              onClick={() => {
                setIsRegisterMode(false);
                setErrors({});
              }}
              className={`flex-1 py-2 text-center text-xs font-extrabold rounded-xl transition-all cursor-pointer ${
                !isRegisterMode 
                  ? 'bg-gradient-to-r from-[#e6a143] to-[#ce842c] text-white shadow-md'
                  : 'text-[#976b3c] hover:bg-amber-100/30 font-bold'
              }`}
            >
              Sign In Session
            </button>
            <button
              type="button"
              onClick={() => {
                setIsRegisterMode(true);
                setErrors({});
              }}
              className={`flex-1 py-2 text-center text-xs font-extrabold rounded-xl transition-all cursor-pointer ${
                isRegisterMode 
                  ? 'bg-gradient-to-r from-[#e6a143] to-[#ce842c] text-white shadow-md'
                  : 'text-[#976b3c] hover:bg-amber-100/30 font-bold'
              }`}
            >
              Register Account
            </button>
          </div>

          {!isRegisterMode ? (
            /* Login Credentials Form */
            <form onSubmit={handleFormSubmit} className="space-y-4">
              
              {/* Email Field */}
              <div className="relative">
                <label htmlFor="email-input" className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1">
                  Academic Email Address
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-700/60">
                    <Mail className="w-[1.1rem] h-[1.1rem]" />
                  </span>
                  <input
                    id="email-input"
                    type="email"
                    value={email ?? ''}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@edutrack.com"
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2.5 pl-11 pr-4 text-sm font-medium text-[#2c241a] placeholder:text-amber-700/40 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all font-sans"
                  />
                </div>
                {errors.email && (
                  <p className="text-[11px] font-bold text-red-600 mt-1 pl-3 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 inline" />
                    {errors.email}
                  </p>
                )}
              </div>

              {/* Password Field */}
              <div className="relative">
                <div className="flex justify-between items-center mb-1 px-1">
                  <label htmlFor="password-input" className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider">
                    Security Pass-phrase
                  </label>
                  
                  {/* Visual strength meter */}
                  {password.length > 0 && (
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-[#976b3c] font-bold">Strength:</span>
                      <div className="flex gap-0.5">
                        {[0, 1, 2, 3].map((idx) => (
                          <div 
                            key={idx}
                            className={`h-1.5 w-3 rounded ${
                              idx < passwordStrength 
                                ? passwordStrength <= 1 
                                  ? 'bg-red-500' 
                                  : passwordStrength <= 2 
                                    ? 'bg-amber-500' 
                                    : 'bg-green-500' 
                                : 'bg-amber-200/30'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-700/60">
                    <Lock className="w-[1.1rem] h-[1.1rem]" />
                  </span>
                  <input
                    id="password-input"
                    type={showPassword ? "text" : "password"}
                    value={password ?? ''}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2.5 pl-11 pr-11 text-sm font-medium text-[#2c241a] placeholder:text-amber-700/40 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-amber-700/50 hover:text-amber-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-[11px] font-bold text-red-600 mt-1 pl-3 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    {errors.password}
                  </p>
                )}
              </div>

              {/* Checkbox / Remember Option */}
              <div className="flex items-center justify-between px-1 text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-[#7e582e] font-semibold">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="accent-amber-500 w-4.5 h-4.5 rounded border-amber-200 focus:ring-0 cursor-pointer"
                  />
                  Remember my terminal session
                </label>
                
                <button 
                  type="button" 
                  onClick={() => triggerToast("Password recovery is deactivated in mock preview mode.", "info")}
                  className="text-amber-700 font-bold hover:underline"
                >
                  Forgot Password?
                </button>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full relative py-3 px-5 rounded-[3rem] bg-gradient-to-r from-[#e6a143] to-[#ce842c] hover:from-[#f5b155] hover:to-[#da943c] text-white font-extrabold text-sm tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-amber-700/25 active:scale-95 hover:scale-[1.01] transition-all cursor-pointer disabled:opacity-75 disabled:cursor-wait"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth={4} />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Authenticating Server Node...</span>
                    </div>
                  ) : (
                    <>
                      <span>Sign in as {selectedRole}</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                    </>
                  )}
                </button>
              </div>

            </form>
          ) : (
            /* Register Account Form with Real-Time Domain Verification */
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              
              {/* Full Name */}
              <div className="relative">
                <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1">
                  Full Name Statement
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-700/60">
                    <UserSquare className="w-[1.1rem] h-[1.1rem]" />
                  </span>
                  <input
                    type="text"
                    value={fullName || ''}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Abebe Kebede"
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2.5 pl-11 pr-4 text-sm font-medium text-[#2c241a] placeholder:text-amber-700/40 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all font-sans"
                    required
                  />
                </div>
              </div>

              {/* Registering Role Chip Selectors */}
              <div>
                <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-2 px-1 text-center">
                  Registering Profile Capacity
                </label>
                <div className="flex bg-amber-50/50 p-1 rounded-xl border border-amber-200/40 gap-1">
                  {(['Student', 'Teacher', 'Admin'] as UserRole[]).map((role) => (
                    <button
                      key={role}
                      type="button"
                      onClick={() => setRegRole(role)}
                      className={`flex-grow py-1.5 text-center text-[11px] font-black rounded-lg transition-all cursor-pointer ${
                        regRole === role
                          ? 'bg-[#ce842c] text-white shadow'
                          : 'text-[#8f6333] hover:bg-amber-100/30'
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              {/* Email Address with Real-Time Validation */}
              <div className="relative">
                <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1">
                  School-Specific Email Address
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-700/60">
                    <Mail className="w-[1.1rem] h-[1.1rem]" />
                  </span>
                  <input
                    type="email"
                    value={regEmail || ''}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2.5 pl-11 pr-4 text-sm font-medium text-[#2c241a] placeholder:text-amber-700/40 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all font-sans"
                    required
                  />
                </div>

              </div>

              {/* Password */}
              <div className="relative">
                <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1">
                  Academic Security Pass-phrase
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-700/60">
                    <Lock className="w-[1.1rem] h-[1.1rem]" />
                  </span>
                  <input
                    type={showPassword ? "text" : "password"}
                    value={regPassword || ''}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2.5 pl-11 pr-11 text-sm font-medium text-[#2c241a] placeholder:text-amber-700/40 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-amber-700/50 hover:text-amber-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Custom field depending on selected capacity */}
              {regRole === 'Student' && (
                <div>
                  <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1 font-sans">
                    Academic Grade / Seniority Level
                  </label>
                  <select
                    value={academicLevel}
                    onChange={(e) => setAcademicLevel(e.target.value)}
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2 px-3.5 text-xs font-extrabold text-[#734b1f] focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all cursor-pointer font-sans"
                  >
                    <option value="Grade 12 - Senior Academy">Grade 12 - Senior Academy</option>
                    <option value="Grade 11 - Junior Academy">Grade 11 - Junior Academy</option>
                    <option value="Grade 10 - Middle Academy">Grade 10 - Middle Academy</option>
                  </select>
                </div>
              )}

              {regRole === 'Teacher' && (
                <div>
                  <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1 font-sans">
                    Core Classroom Subject Assignation
                  </label>
                  <select
                    value={subjectCode}
                    onChange={(e) => setSubjectCode(e.target.value)}
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2 px-3.5 text-xs font-extrabold text-[#734b1f] focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all cursor-pointer font-sans"
                  >
                    <option value="CHE-103">CHE-103 - General Chemistry</option>
                    <option value="MAT-102">MAT-102 - Advanced Mathematics</option>
                    <option value="ENG-101">ENG-101 - English Literature</option>
                  </select>
                </div>
              )}

              {regRole === 'Admin' && (
                <div>
                  <label className="block text-xs font-bold text-[#734b1f] uppercase tracking-wider mb-1 px-1 font-sans">
                    Administrative Coordinator Title
                  </label>
                  <input
                    type="text"
                    value={adminTitle || ''}
                    onChange={(e) => setAdminTitle(e.target.value)}
                    placeholder="e.g. Principal Deputy / Registrar"
                    className="w-full bg-white/80 border border-amber-200 rounded-[2rem] py-2.5 px-4 text-xs font-extrabold text-[#734b1f] focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/20 transition-all font-sans"
                    required
                  />
                </div>
              )}

              {/* Submit Registration button */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full relative py-3 px-5 rounded-[3rem] bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold text-sm tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-emerald-700/25 active:scale-95 hover:scale-[1.01] transition-all cursor-pointer"
                >
                  <span>Build {regRole} Institution Account</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </form>
          )}

          {/* Updated Test Credentials Block */}
          <div className="mt-5 p-4 rounded-2xl bg-amber-50 border border-amber-200/50 flex flex-col gap-3">
            <span className="font-extrabold text-[#734b1f] text-sm tracking-tight italic">Quick Login Helper</span>
            <div className="text-[11px] font-medium text-[#7e582e] space-y-1">
                <p>Student: <span className="font-mono bg-white px-1.5 py-0.5 rounded">student@gmail.com</span></p>
                <p>Teacher: <span className="font-mono bg-white px-1.5 py-0.5 rounded">teacher@gmail.com</span></p>
                <p>Admin: <span className="font-mono bg-white px-1.5 py-0.5 rounded">admin@gmail.com</span></p>
                <p>Password: <span className="font-mono bg-white px-1.5 py-0.5 rounded">password123</span></p>
            </div>
          </div>
          
          {/* Demographic Hint Block */}
          <div className="mt-5 p-3 rounded-2xl bg-[#fff2e4]/80 border border-amber-200/30 flex items-start gap-2 text-[#a77c48] text-[11px] font-medium leading-relaxed">
            <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-extrabold text-amber-800">Evaluator Access Panel:</span>
              <p className="mt-0.5 text-[#8f6333]">
                Email + Password requires a minimum of 3 characters. Switching the role cards above will automatically seed standard demo user credentials!
              </p>
            </div>
          </div>

        </div>

        {/* Footer Credit lines */}
        <p className="text-[11px] text-[#aa7b4a]/75 font-semibold mt-6 tracking-wide select-none text-center">
          © 2026 Addis Ketema Academy Prep School System • Secured Terminal
        </p>

      </div>

      {/* Elegant Toast notifications rendering */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.9 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#2e241c]/95 backdrop-blur-xl shadow-2xl border-l-4 border-amber-500 font-sans text-xs text-[#fae6c3] font-medium max-w-[90%] md:max-w-md"
          >
            {toastType === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
            ) : toastType === 'error' ? (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
