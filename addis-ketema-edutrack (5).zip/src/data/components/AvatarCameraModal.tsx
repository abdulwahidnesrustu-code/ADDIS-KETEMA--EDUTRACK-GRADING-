import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, X, Check, RefreshCw, Image as ImageIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AvatarCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (imgDataUrl: string) => void;
  currentAvatar: string;
}

export default function AvatarCameraModal({ isOpen, onClose, onSave, currentAvatar }: AvatarCameraModalProps) {
  const [activeTab, setActiveTab] = useState<'camera' | 'upload'>('upload');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [previewImg, setPreviewImg] = useState<string>(currentAvatar);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    // Reset state on open/close
    if (isOpen) {
      setPreviewImg(currentAvatar);
      setCameraError(null);
      setIsCameraActive(false);
    } else {
      stopCamera();
    }
  }, [isOpen, currentAvatar]);

  // Clean up camera stream when modal is closed or tab is changed
  useEffect(() => {
    if (activeTab !== 'camera') {
      stopCamera();
    }
  }, [activeTab]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (stream) {
        stopCamera();
      }
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 350, height: 350, facingMode: 'user' },
        audio: false
      });
      setStream(mediaStream);
      setIsCameraActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError(
        "Could not access your camera. Please ensure permissions are granted and that your camera isn't currently in use by another app."
      );
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 350;
      canvas.height = video.videoHeight || 350;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Draw the video frame to the canvas
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setPreviewImg(dataUrl);
        stopCamera();
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert("Please select a valid image file from your gallery.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setPreviewImg(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    onSave(previewImg);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-[#0f172a]/65 backdrop-blur-sm flex items-center justify-center p-4 z-50 select-none">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden relative"
      >
        {/* Header bar */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-5 text-white flex justify-between items-center">
          <div>
            <h3 className="font-black text-sm uppercase tracking-wider font-display">Update Profile Picture</h3>
            <p className="text-[10px] text-blue-100 font-bold">Snap a new photo or select from device gallery</p>
          </div>
          <button 
            type="button"
            onClick={onClose} 
            className="p-1.5 bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Swappers */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-semibold text-xs text-slate-500">
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`flex-1 py-3 text-center flex items-center justify-center gap-1.5 transition-all border-b-2 cursor-pointer ${
              activeTab === 'upload' 
                ? 'border-blue-600 text-blue-600 bg-white dark:bg-slate-900 font-black' 
                : 'border-transparent hover:bg-slate-100/50 hover:text-slate-700'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Gallery Pick</span>
          </button>
          
          <button
            type="button"
            onClick={() => setActiveTab('camera')}
            className={`flex-1 py-3 text-center flex items-center justify-center gap-1.5 transition-all border-b-2 cursor-pointer ${
              activeTab === 'camera' 
                ? 'border-blue-600 text-blue-600 bg-white dark:bg-slate-900 font-black' 
                : 'border-transparent hover:bg-slate-100/50 hover:text-slate-700'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Camera Booth</span>
          </button>
        </div>

        {/* Dynamic Display area */}
        <div className="p-5 flex flex-col items-center justify-center min-h-[280px]">
          {activeTab === 'camera' ? (
            <div className="w-full relative flex flex-col items-center">
              {isCameraActive ? (
                <div className="w-56 h-56 rounded-full border-4 border-blue-500 overflow-hidden relative bg-slate-950 shadow-inner">
                  <video 
                    ref={videoRef}
                    autoPlay 
                    playsInline 
                    className="w-full h-full object-cover scale-x-[-1]"
                  />
                  <div className="absolute inset-0 border-8 border-transparent rounded-full shadow-[0_0_0_99px_rgba(15,23,42,0.4)] pointer-events-none" />
                </div>
              ) : (
                <div className="w-56 h-56 rounded-full border-4 border-slate-200 dark:border-slate-800 p-2 flex flex-col items-center justify-center bg-slate-55 bg-slate-50 relative group">
                  <img 
                    src={previewImg} 
                    alt="Snapshot Preview" 
                    className="w-full h-full object-cover rounded-full shadow-md"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/30 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-[10px] text-white font-bold bg-[#0f172a]/80 px-2.5 py-1 rounded-full flex items-center gap-1 uppercase">
                      <Camera className="w-3 h-3" /> Ready
                    </span>
                  </div>
                </div>
              )}

              {cameraError && (
                <p className="mt-4 text-[10px] text-red-600 dark:text-red-400 font-black text-center bg-red-50 dark:bg-red-950/20 p-3 rounded-2xl border border-red-150 border-red-200">
                  {cameraError}
                </p>
              )}

              <div className="mt-5 flex gap-2 w-full justify-center">
                {!isCameraActive ? (
                  <button
                    type="button"
                    onClick={startCamera}
                    className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-[11px] uppercase flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Start Camera Feed
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] uppercase flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                  >
                    <Camera className="w-3.5 h-3.5 animate-pulse" /> Capture Snap
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="w-full flex flex-col items-center">
              <div className="w-56 h-56 rounded-full border-4 border-slate-200 dark:border-slate-800 p-1 bg-slate-50 dark:bg-slate-950 shadow-md relative overflow-hidden group">
                <img 
                  src={previewImg} 
                  alt="Gallery Preview" 
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                />
                
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-[#0f172a]/50 rounded-full flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer border-none"
                >
                  <Upload className="w-6 h-6 text-white mb-1" />
                  <span className="text-[10px] font-black uppercase text-white tracking-wider">Browse File</span>
                </button>
              </div>

              <input 
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="mt-5 px-5 py-2 rounded-full border-2 border-dashed border-blue-200 hover:border-blue-500 hover:bg-blue-50/50 dark:hover:bg-blue-950/20 text-blue-600 font-extrabold text-[11.5px] uppercase transition-all cursor-pointer flex items-center gap-1.5"
              >
                <ImageIcon className="w-4 h-4" />
                Select Photo from Device
              </button>
            </div>
          )}
        </div>

        {/* Footer controls */}
        <div className="bg-slate-50 dark:bg-slate-950 px-5 py-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-4 rounded-full border border-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-350 font-bold text-xs cursor-pointer"
          >
            Cancel
          </button>
          
          <button
            type="button"
            onClick={handleSave}
            disabled={previewImg === currentAvatar}
            className="py-2.5 px-5.5 rounded-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:dark:bg-slate-850 disabled:text-slate-400 disabled:cursor-not-allowed text-white font-extrabold text-xs flex items-center gap-1.5 transition-all shadow cursor-pointer"
          >
            <Check className="w-4 h-4" />
            Apply Profile Photo
          </button>
        </div>
      </motion.div>
    </div>
  );
}
