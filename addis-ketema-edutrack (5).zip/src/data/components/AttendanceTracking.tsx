import React from 'react';
import { Student } from '../types';

interface AttendanceTrackingProps {
  students: Student[];
  onAttendanceEdit: (studentId: string, value: number) => void;
}

export default function AttendanceTracking({ students, onAttendanceEdit }: AttendanceTrackingProps) {
  return (
    <div className="bg-white rounded-[2rem] border border-slate-200 p-6 shadow-sm space-y-4">
      <h3 className="text-sm font-black text-slate-800">Attendance Tracking</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="py-2 px-3">Student</th>
              <th className="py-2 px-3">Attendance (%)</th>
              <th className="py-2 px-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <tr key={student.id} className="border-b border-slate-100">
                <td className="py-2 px-3">{student.name}</td>
                <td className="py-2 px-3 font-mono">{student.attendance?.toFixed(1) || '0.0'}%</td>
                <td className="py-2 px-3">
                  <input 
                    type="number" 
                    min="0"
                    max="100"
                    value={student.attendance || 0}
                    onChange={(e) => onAttendanceEdit(student.id, parseFloat(e.target.value))}
                    className="border rounded p-1 w-20 font-bold"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
