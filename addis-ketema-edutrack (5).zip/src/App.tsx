import React, { useState, useEffect } from 'react';
import SplashWelcome from './components/SplashWelcome';
import LoginPage from './components/LoginPage';
import StudentDashboard from './components/StudentDashboard';
import TeacherDashboard from './components/TeacherDashboard';
import AdminDashboard from './components/AdminDashboard';
import { AppRoute, UserRole, Student, Teacher } from './types';
import { supabase } from './lib/supabase';
import { createDefaultGradesForAllSubjects, updateTeacherAndSync, getStoredStudents } from './data/mockData';

export default function App() {
  const [route, setRoute] = useState<AppRoute>('Splash');
  const [targetRoute, setTargetRoute] = useState<AppRoute | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [activeStudent, setActiveStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [splashFinished, setSplashFinished] = useState(false);

  // Transition to target route once splash and auth are ready
  useEffect(() => {
    if (splashFinished && targetRoute) {
      setRoute(targetRoute);
    }
  }, [splashFinished, targetRoute]);

  const setDashboardRoute = (profile: any, role: UserRole) => {
    console.log("App: setDashboardRoute called", { profile, role });
    const normalizedRole = role.charAt(0).toUpperCase() + role.slice(1).toLowerCase() as UserRole;
    
    if (normalizedRole === 'Student') {
      const studentData = {
        ...profile,
        avatar: profile.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200&h=200',
        studentId: profile.studentId || `AK/2026/0${Math.floor(100 + Math.random() * 900)}`,
        academicLevel: profile.academicLevel || 'Grade 12 - Senior Academy',
        semester: profile.semester || 'Grade 12, Semester 2',
        parentName: profile.parentName || 'Guardian Custodian',
        parentContact: profile.parentContact || '+251-911-00-00-00',
        joinedDate: profile.joinedDate || 'June 2026',
        grades: profile.grades || createDefaultGradesForAllSubjects(),
        attendance: profile.attendance || 95.0
      } as Student;
      setActiveStudent(studentData);
      setCurrentUser(studentData);
      setTargetRoute('StudentDashboard');
    } else if (normalizedRole === 'Teacher') {
      const teacherData = {
        ...profile,
        avatar: profile.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200',
        teacherId: profile.teacherId || `AK/STAFF/T${Math.floor(100 + Math.random() * 900)}`,
        subjectCode: profile.subjectCode || 'CHE-103',
        subjectName: profile.subjectName || 'General Chemistry',
        classes: profile.classes || ['Grade 12 - Senior Academy']
      };
      setCurrentUser(teacherData);
      setTargetRoute('TeacherDashboard');
    } else if (normalizedRole === 'Admin') {
      const adminData = {
        ...profile,
        avatar: profile.avatar || 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200&h=200',
        title: profile.title || 'Academic Coordinator',
        role: 'Admin'
      };
      setCurrentUser(adminData);
      setTargetRoute('AdminDashboard');
    }
  };

  // Sync state with Supabase session 
  useEffect(() => {
    const handleDbUpdate = () => {
      console.log("App: DbUpdate event received");
      const students = getStoredStudents();
      setActiveStudent(prev => {
        const st = students.find(s => s.id === prev?.id);
        return st || prev;
      });
    };
    window.addEventListener('ak_db_updated', handleDbUpdate);
    window.addEventListener('localDataUpdated', handleDbUpdate);
    
    async function loadSession() {
      console.log("App: loadSession started");
      setIsLoading(true);
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (session) {
        console.log("App: Session found for user", session.user.id);
        try {
          const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();

          if (error || !profile) {
              console.error("App: error loading profile", error, "or profile not found");
              setTargetRoute('Login');
          } else {
            console.log("App: loadSession found profile", profile);
            setDashboardRoute(profile, profile.role || 'Student');
          }
        } catch (e) {
            console.error("App: Fatal error loading profile", e);
            setTargetRoute('Login');
        }
      } else {
        console.log("App: No session found, redirecting to Login");
        setTargetRoute('Login');
      }
      setIsLoading(false);
      console.log("App: loadSession finished, loading=false");
    }
    loadSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      loadSession();
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLoginSuccess = async (user: any, role: UserRole) => {
    setIsLoading(true);
    console.log("App: handleLoginSuccess started for", user.id);
    
    try {
      const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
          
      const userData = profile || user;
      const finalRole = userData.role || (userData.user_metadata?.role) || role || 'Student';
      
      console.log("App: handleLoginSuccess profile fetch result", { profile, error, userData, finalRole });

      if (error && !profile) {
          console.error("App: error fetching profile in handleLoginSuccess", error);
      }
      
      setDashboardRoute(userData, finalRole);
    } catch (e) {
      console.error("App: Error in handleLoginSuccess", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCurrentUser(null);
    setActiveStudent(null);
    setRoute('Login');
  };

  const handleStudentProfileUpdate = async (updatedStudent: Student) => {
    const { error } = await supabase
      .from('profiles')
      .update(updatedStudent)
      .eq('id', updatedStudent.id);
      
    if (!error) {
        setActiveStudent(updatedStudent);
    }
  };

  const handleTeacherProfileUpdate = async (updatedTeacher: Teacher) => {
    const { error } = await supabase
        .from('profiles')
        .update(updatedTeacher)
        .eq('id', updatedTeacher.id);
        
    if (!error) {
        setCurrentUser(updatedTeacher);
        updateTeacherAndSync(updatedTeacher);
    }
  };

  const handleAdminProfileUpdate = async (updatedAdmin: any) => {
    const { error } = await supabase
        .from('profiles')
        .update(updatedAdmin)
        .eq('id', updatedAdmin.id);
        
    if (!error) {
        setCurrentUser(updatedAdmin);
    }
  };

  const renderRouteView = () => {
    console.log("App: renderRouteView called. route:", route, "isLoading:", isLoading);
    if (isLoading) {
      return (
        <div className="flex h-screen w-full items-center justify-center bg-[#fcf8f2] text-amber-800 font-bold text-xl">
          Loading Application...
        </div>
      );
    }
    switch (route) {
      case 'Splash':
        return <SplashWelcome onComplete={() => setSplashFinished(true)} />;
      
      case 'Login':
        return <LoginPage onLoginSuccess={handleLoginSuccess} />;
      
      case 'StudentDashboard':
        return activeStudent ? (
          <StudentDashboard 
            student={activeStudent} 
            onLogout={handleLogout} 
            onProfileUpdate={handleStudentProfileUpdate}
          />
        ) : (
          <div className="flex h-screen w-full items-center justify-center bg-[#fcf8f2] text-amber-800 font-bold">
            Student profile not found. Please relogin.
          </div>
        );
      
      case 'TeacherDashboard':
        return currentUser ? (
          <TeacherDashboard 
            teacher={currentUser} 
            onLogout={handleLogout} 
            onProfileUpdate={handleTeacherProfileUpdate} 
            onUpdateStudent={handleStudentProfileUpdate}
          />
        ) : (
          <div className="flex h-screen w-full items-center justify-center bg-[#fcf8f2] text-amber-800 font-bold">
            Faculty profile not found. Please relogin.
          </div>
        );
      
      case 'AdminDashboard':
        return currentUser ? (
          <AdminDashboard 
            admin={currentUser} 
            onLogout={handleLogout} 
            onProfileUpdate={handleAdminProfileUpdate}
          />
        ) : (
          <div className="flex h-screen w-full items-center justify-center bg-[#fcf8f2] text-amber-800 font-bold">
            Admin profile not found. Please relogin.
          </div>
        );

      default:
        return <LoginPage onLoginSuccess={handleLoginSuccess} />;
    }
  };

  return (
    <div className="min-h-screen font-sans antialiased selection:bg-amber-500/20 selection:text-amber-900 selection:font-semibold">
      {renderRouteView()}
    </div>
  );
}
