/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'Admin' | 'Teacher' | 'Student';

export type AppRoute = 'Splash' | 'Login' | 'StudentDashboard' | 'TeacherDashboard' | 'AdminDashboard';

export interface SubjectGrade {
  subjectCode: string;
  subjectName: string;
  instructorName: string;
  assignments: number; // out of 30
  quizzes: number;      // out of 20
  exams: number;        // out of 50
  totalMark: number;    // out of 100
  creditHours: number;
  gpaPoint: number;
  letterGrade: string;
  status: 'Excellent' | 'Good' | 'Average' | 'At Risk';
  progress: number;     // academic completion / attendance %
}

export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  studentId: string;    // AK/2026/0842
  academicLevel: string;
  semester: string;
  parentName: string;
  parentContact: string;
  joinedDate: string;
  grades: Record<string, SubjectGrade>;
  attendance: number; // overall attendance %
}

export interface Teacher {
  id: string;
  name: string;
  email: string;
  avatar: string;
  teacherId: string;
  subjectCode: string;
  subjectName: string;
  classes: string[];
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'grade' | 'announce' | 'alert';
  date: string;
  unread: boolean;
}

export interface SystemLog {
  id: string;
  actor: string;
  action: string;
  subject: string;
  timestamp: string;
}

export interface CourseProgram {
  id: string;
  name: string;
  department: string;
  subjectsCount: number;
  totalCredits: number;
  description: string;
  studentsCount: number;
  status: 'Active' | 'Archived';
}

export interface SubjectDefinition {
  id: string;
  name: string;
  code: string;
  credits: number;
  department: string;
  semester: string;
  instructorName: string;
  status: 'Active' | 'Archived';
}

export interface Announcement {
  id: string;
  title: string;
  description: string;
  publishDate: string;
  priority: 'General' | 'Academic' | 'Examination' | 'Emergency';
}

