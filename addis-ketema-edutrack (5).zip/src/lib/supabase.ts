import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLIC_KEY || '';

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing Supabase configuration");
} else {
  console.info("Supabase client initialized with URL:", supabaseUrl);
}

export const supabase = createClient(supabaseUrl, supabaseKey);
